function [x] = MbbVoidsDomainB(Demand,Arg,Co)
  BdBox = [0 4 0 2];
  switch(Demand)
    case('Dist');  x = DistFnc(Arg,BdBox);
    case('BdBox'); x = BdBox;
    case('PFix');  x = FixedPoints(BdBox);
  end
%----------------------------------------------- COMPUTE DISTANCE FUNCTIONS
function Dist = DistFnc(P,BdBox)
    d1 = dRectangle(P,BdBox(1),BdBox(2),BdBox(3),BdBox(4));
    d2 = dCircle(P,0.25,0.5,0.18); 
    d3 = dCircle(P,0.8,0.7,0.17);
    d4 = dCircle(P,1.6,0.4,0.2);
    d5 = dCircle(P,2.5,0.3,0.24);
    d6 = dCircle(P,3.6,0.35,0.23);
    d7 = dCircle(P,3.1,1.1,0.22);
    d8 = dCircle(P,2,1.6,0.2);
    d9 = dCircle(P,2.2,1.,0.24);
    d10 = dCircle(P,1.3,1.5,0.22);
    d11 = dCircle(P,0.3,1.6,0.23);
    d12 = dCircle(P,3.7,1.35,0.22);
    Dist = dDiff(dDiff(dDiff(dDiff(dDiff(dDiff(dDiff(dDiff(dDiff(dDiff(dDiff(d1,d2),d3),d4),d5),...
        d6),d7),d8),d9),d10),d11),d12);

%----------------------------------------------------- SPECIFY FIXED POINTS
function [PFix] = FixedPoints(BdBox)
  PFix = [];
%-------------------------------------------------------------------------%