function [Coor,Elem] = PolyAdaptor2D(ecoord)

nnel = length(ecoord);
C =  sum(ecoord,1)./nnel;
subCon = [[1:nnel]',[2:nnel,1]',(nnel+1)*ones(nnel,1)];
for i = 1:nnel
    if i < nnel
        sidenode = sum(ecoord(i:i+1,:),1)./2;
    else sidenode = sum(ecoord(1:nnel-1:nnel,:),1)./2;
    end
    ecoord = [ecoord;sidenode];
end
for i = 1:nnel
    Ci = (ecoord(nnel+i,:)-C)./2.2+C;
    ecoord = [ecoord;Ci];
end
eleTemp = {2*nnel+1:length(ecoord)};
for i = 1:nnel
    if i == 1
        elei = {[i i+nnel i+2*nnel 3*nnel i+2*nnel-1]};
    else 
        elei = {[i i+nnel i+2*nnel i+2*nnel-1 i+nnel-1]};
    end
    eleTemp = [eleTemp,elei];
end
Coor = ecoord;
Elem = eleTemp;