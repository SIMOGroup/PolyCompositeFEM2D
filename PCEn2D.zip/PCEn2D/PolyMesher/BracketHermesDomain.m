%-------------------------------------------------------------------------%
function [x] = BracketHermesDomain(Demand,Arg,Co)
L = 0.7;
T = 0.1;
BdBox = [0 - 1e-3, L + T + 1e-3, 0 - 1e-3, L + T + 1e-3];
switch(Demand)
    case('Dist');  x = DistFnc(Arg,BdBox);
    case('BC');    x = BndryCnds(Arg{:},BdBox);
    case('BdBox'); x = BdBox;
    case('PFix');  x = FixedPoints(BdBox);
end
%----------------------------------------------- COMPUTE DISTANCE FUNCTIONS
    function Dist = DistFnc(P,BdBox)
        d1 = dRectangle(P, T, L + T, T, L + T);
        d2 = dCircle(P, T, T, L - T);%dCircle(P,xc,yc,r)
        d3 = dCircle(P, T, L + T, T);
        d4 = dRectangle(P, 0, T, L, L + T);
        d5 = dIntersect(d3, d4);
        d6 = dCircle(P, L + T, T, T);
        d7 = dRectangle(P, L, L + T, 0, T);
        d8 = dIntersect(d6, d7);
        d9 = dCircle(P, T, T, L);
        d10 = dRectangle(P, T, L, T, L);
        d11 = dIntersect(d10, -d9);
        d14 = dUnion(dUnion(dIntersect(d1, -d2), d5), d8);
        Dist = dIntersect(d14, -d11);
    end
%----------------------------------------------------- SPECIFY FIXED POINTS
    function [PFix] = FixedPoints(BdBox)
        PFix = [L, T + sqrt(2*L*T - T*T); L, L; T + sqrt(2*L*T - T*T), L];
    end
%-------------------------------------------------------------------------%
end