function [x] = CurvedBeamDomain(Demand,Arg,Co)
BdBox = [0 30 0 20];
switch(Demand)
    case('Dist');  x = DistFnc(Arg,BdBox);
    case('BdBox'); x = BdBox;
    case('PFix');  x = FixedPoints(BdBox);
end
%----------------------------------------------- COMPUTE DISTANCE FUNCTIONS
function Dist = DistFnc(P,BdBox)
d1 =dRectangle(P,BdBox(1),BdBox(2),BdBox(3),BdBox(4));
d2 = dCircle(P,30,-40,55);
Dist =dDiff(d1,d2);

%----------------------------------------------------- SPECIFY FIXED POINTS
function [PFix] = FixedPoints(BdBox)
PFix = [30,17.5];
%-------------------------------------------------------------------------%