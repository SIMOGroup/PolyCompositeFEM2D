function [x] = CookDomain(Demand,Arg,Co)
  BdBox = [0, 48, 0, 60];
  switch(Demand)
    case('Dist');  x = DistFnc(Arg);
    case('BC');    x = BndryCnds(Arg{:},BdBox);
    case('BdBox'); x = BdBox;
    case('PFix');  x = FixedPoints(BdBox);
  end
%----------------------------------------------- COMPUTE DISTANCE FUNCTIONS
function Dist = DistFnc(P)
  l1 = dLine(P,0,40,0,0);%dLine(P,x1,y1,x2,y2)  
  l2 = dLine(P,0,0,48,44);
  l3 = dLine(P,48,44,48,60);
  l4 = dLine(P,48,60,0,44);
  Dist = dIntersect(l3,dIntersect(l4,dIntersect(l1,l2)));
%   Dist = dIntersect(d,l1);
%   Dist = dUnion(dUnion(dUnion(l1,l2),l3),l4);
  %---------------------------------------------- SPECIFY BOUNDARY CONDITIONS
function [x] = BndryCnds(Node,Element,BdBox)
  eps = 0.1*sqrt((BdBox(2)-BdBox(1))*(BdBox(4)-BdBox(3))/size(Node,1));
  UpperHalfCircleNodes = find(abs(max(sqrt(Node(:,1).^2+(Node(:,2)...
                                -80.6226).^2)-10,-Node(:,2)+80.6226))<eps);
  Supp = ones(size(UpperHalfCircleNodes,1),3);
  Supp(:,1) = UpperHalfCircleNodes;
  LowerHalfCircleNodes = ...
      find(abs(max(sqrt(Node(:,1).^2+Node(:,2).^2)-19,Node(:,2)))<eps);
  Load = -0.1*ones(size(LowerHalfCircleNodes,1),3);
  Load(:,1) = LowerHalfCircleNodes; Load(:,2) = 0;
  x = {Supp,Load};
%----------------------------------------------------- SPECIFY FIXED POINTS
function [PFix] = FixedPoints(BdBox)
  PFix = [48, 52];
%-------------------------------------------------------------------------%