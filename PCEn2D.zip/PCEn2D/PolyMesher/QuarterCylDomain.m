%-------------------------------------------------------------------------%
function [x] = QuarterCylDomain(Demand,Arg,Co)
BdBox = [-2 2 -2 2];
switch(Demand)
    case('Dist');  x = DistFnc(Arg,BdBox);
    case('BC');    x = BndryCnds(Arg{:},BdBox);
    case('BdBox'); x = BdBox;
    case('PFix');  x = FixedPoints(BdBox);
end
%----------------------------------------------- COMPUTE DISTANCE FUNCTIONS
    function Dist = DistFnc(P,BdBox)
        d1 = dRectangle(P,0,2,0,2);
        d2 = dCircle(P,0,0,1);%dCircle(P,xc,yc,r)
        d3 = dCircle(P,0,0,2);
        Dist = dIntersect(d3,dIntersect(d1,-d2));
    end
%----------------------------------------------------- SPECIFY FIXED POINTS
    function [PFix] = FixedPoints(BdBox)
        PFix = [];
        %         PFix = zeros(2, 2);
        %         PFix(1, 1) = 1.5;
        %         PFix(2, 2) = 1.5;
    end
%-------------------------------------------------------------------------%
end