function [x] = BracketDomain(Demand,Arg,Co)
  BdBox = [-5 25 -5 5];
switch(Demand)
    case('Dist');  x = DistFnc(Arg,BdBox);
    case('BdBox'); x = BdBox;
    case('PFix');  x = FixedPoints(BdBox);
end
%----------------------------------------------- COMPUTE DISTANCE FUNCTIONS
function Dist = DistFnc(P,BdBox)
  d1 = dLine(P,0,3,0,-3); d2 = dLine(P,0,-5,20,-5); d3 = dLine(P,20,-5,20,5);
  d4 = dLine(P,20,5,0,5); d5 = dCircle(P,0,0,5); d6 = dCircle(P,20,0,5);
  douter = dUnion(d6,dUnion(d5,dIntersect(d4,dIntersect(d3,dIntersect(d2,d1)))));
  d7 = dCircle(P,0,0,3); d8 = dCircle(P,20,0,3); din = dUnion(d8,d7);
  Dist = dDiff(douter,din);

%----------------------------------------------------- SPECIFY FIXED POINTS
function [PFix] = FixedPoints(BdBox)
PFix = [20 3;20 -3];
%-------------------------------------------------------------------------%