function [x] = LshapeDomain(Demand, Arg, Co)
BdBox = [0, 100, 0, 100];
switch (Demand)
    case ('Dist');
        x = DistFnc(Arg, BdBox);
    case ('BdBox');
        x = BdBox;
    case ('PFix');
        x = FixedPoints(BdBox);
end
%----------------------------------------------- COMPUTE DISTANCE FUNCTIONS
    function Dist = DistFnc(P, BdBox)
        d1 = dRectangle(P, BdBox(1), BdBox(2), BdBox(3), BdBox(4));
        d2 = dRectangle(P, 50, 110, 50, 110);
        Dist = dDiff(d1, d2);
    end
%----------------------------------------------------- SPECIFY FIXED POINTS
    function [PFix] = FixedPoints(BdBox)
        PFix = [50, 50; 100, 25];
    end
%-------------------------------------------------------------------------%
end