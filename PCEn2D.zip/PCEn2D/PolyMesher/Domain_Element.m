%-------------------------------------------------------------------------%
function [x] = Domain_Element(Demand,Arg,Co)
BdBox=[min(Co(:,1)), max(Co(:,1)), min(Co(:,2)), max(Co(:,2))];
switch(Demand)
    case('Dist');  x = DistFnc(Arg,BdBox,Co);
    case('BdBox'); x = BdBox;
    case('PFix');  x = FixedPoints(BdBox);
end 
%----------------------------------------------- COMPUTE DISTANCE FUNCTIONS
function Dist = DistFnc(P,BdBox,Co)
nnel=size(Co,1); TRI=[[1:nnel]',[2:nnel,1]']; d=zeros(size(P,1),2,nnel);
for i=1:nnel
    d(:,:,i)=dLine(P,Co(TRI(i,1),1),Co(TRI(i,1),2),Co(TRI(i,2),1),Co(TRI(i,2),2));
end
Dist=dIntersect(d(:,:,2),d(:,:,1));
for i=3:nnel,Dist =dIntersect(d(:,:,i),Dist); end

%----------------------------------------------------- SPECIFY FIXED POINTS
function [PFix] = FixedPoints(BdBox)
PFix = [];
%-------------------------------------------------------------------------%