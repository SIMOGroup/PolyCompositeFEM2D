clear
close all;
clc

format long
global node element thickness;
% ******************************************************************************
% ***                             I N P U T                                  ***
% ******************************************************************************
tic;
disp('************************************************')
disp('***          S T A R T I N G    R U N        ***')
disp('************************************************')

disp([num2str(toc), '   START'])

% MATERIAL PROPERTIES
E0 = 21e3; % Young's modulus
nu0 = 0.3;  % Poisson's ratio
% nu0 = 0.4999999;

% % % PLATE PROPERTIES
a = 1; % a=1in internal radius
b = 2; % b=5in external radius
P = 8; % p=3*10^4 psi(Pa/in^2).
thickness = 1;
%  a=1;                   % a=1in internal radius
%  b=5;                   % b=5in external radius
%  E0=3*10^7; %21000;               % E=3*10^7 Young's modulus
%  nu0=0.25;                 % v=0.3 Poisson's ratio
%  p=3*10^4;                   % p=3*10^4 psi(Pa/in^2).

% nume = 45;                 % chia theo huong goc
% numr = 21;                 % chia theo huong ban kinh

nume = 12; % chia theo huong goc
numr = 6; % chia theo huong ban kinh

% nume=37;                 % chia theo huong goc
% numr=19;                 % chia theo huong ban kinh

% MESH PROPERTIES
elemType = 'Poly';
% elemType = 'CQ4';

MethodLAB = 'PCEn';
% MethodLAB = 'Classic';

basisLAB = 'T3';
% basisLAB = 'Wachspress';
% basisLAB = 'CorrectedWachspress';

cenDOF = 'yes';

plotMesh = 1;

MaxIt = 50;

% STRESS ASSUMPTION
% stressState = 'PLANE_STRAIN'; % set to either 'PLANE_STRAIN' or "PLANE_STRESS'
stressState = 'PLANE_STRESS';

warning(['Running under ', stressState, ' condition with ', 'nu = ', num2str(nu0, 16), ' and ', MethodLAB, ' approach with ', basisLAB, ' basis functions.'])

% ******************************************************************************
% ***                    P R E - P R O C E S S I N G                         ***
% ******************************************************************************
% COMPUTE ELASTICITY MATRIX
[Dm, gamma] = Dmaterial(E0, nu0, stressState);
%
%               GENERATE FINITE ELEMENT MESH

disp([num2str(toc), '   GENERATING MESH'])

switch elemType
    case 'CQ4'% here we generate the mesh of Q4 elements
        for i = 1:numr
            for j = 1:nume
                node(j + nume * (i - 1), 1) = (a + (b - a) / (numr - 1) * (i - 1)) * cos(pi * (j - 1) / (2 * (nume - 1)));
                node(j + nume * (i - 1), 2) = (a + (b - a) / (numr - 1) * (i - 1)) * sin(pi * (j - 1) / (2 * (nume - 1)));
            end
        end
        
        element = [];
        for i = 1:(numr - 1)
            for j = 1:(nume - 1)
                element = [element; j + nume * (i - 1), j + nume * i, j + nume * i + 1, j + nume * (i - 1) + 1; ];
            end
        end
        
        AdaptiveMesh.Nodes = node;
        element = mat2cell(element, ones(size(element, 1), 1));
        AdaptiveMesh.Elements = element;
        edgeElemType = 'L2';
    case 'Poly'
        %         Nelem = 1225;
        %         [node, element] = PolyMesher(@QuarterCylDomain, Nelem, 4000);
        %         save(strcat('MeshCylinderNEW', num2str(Nelem)), 'node', 'element');
        im = 1;
        if im == 1
            load('MeshCylinder128', 'node', 'element')
        elseif im == 2
            load('MeshCylinder288', 'node', 'element')
        elseif im == 3
            load('MeshCylinder648', 'node', 'element')
        elseif im == 4
            load('MeshCylinder1225', 'node', 'element')
        elseif im == 5
            load('MeshCylinder2048', 'node', 'element')
        else
            error("Not implemented yet!")
        end
        
        AdaptiveMesh.Nodes = node;
        AdaptiveMesh.Elements = element;
        edgeElemType = 'L2';
end

sqrt(pi*(b^2 - a^2) / 4 /numel(element))

numnode = size(node, 1); % number of nodes
numelem = numel(element); % number of elements
ndof = 2;

if plotMesh% if plotMesh==1 we will plot the mesh
    clf
    Plot_PolyMesh(node, element, 0);
    pause(1e-2)
    hold on;
end
% ---------------------------------------------------------------------
RightBC = find(AdaptiveMesh.Nodes(:, 2) > 0 - 1e-3 & AdaptiveMesh.Nodes(:, 2) < 0 + 1e-3);

for i = 1:length(RightBC) - 1
    for j = i + 1:length(RightBC)
        if AdaptiveMesh.Nodes(RightBC(i), 1) > AdaptiveMesh.Nodes(RightBC(j), 1)
            tmp = RightBC(i);
            RightBC(i) = RightBC(j);
            RightBC(j) = tmp;
        end
    end
end

RightEdge = [RightBC(1:end - 1), RightBC(2:end)];
LeftBC = find(AdaptiveMesh.Nodes(:, 1) > 0 - 1e-3 & AdaptiveMesh.Nodes(:, 1) < 0 + 1e-3);

for i = 1:length(LeftBC) - 1
    for j = i + 1:length(LeftBC)
        if AdaptiveMesh.Nodes(LeftBC(i), 2) > AdaptiveMesh.Nodes(LeftBC(j), 2)
            tmp = LeftBC(i);
            LeftBC(i) = LeftBC(j);
            LeftBC(j) = tmp;
        end
    end
end

LeftEdge = [LeftBC(1:end - 1), LeftBC(2:end)];

% GET NODES ON DISPLACEMENT BOUNDARY
fixedNodeX = unique(LeftEdge);
fixedNodeY = unique(RightEdge);

bcdof = [fixedNodeX * 2 - 1; fixedNodeY * 2];
bcval = zeros(size(bcdof));

disp(['Num DOFs = ', num2str(ndof * numnode - numel(bcdof))])

disp([num2str(toc), '   INITIALIZING DATA STRUCTURES'])
F = zeros(2 * (numnode), 1); % external load vector
% ******************************************************************************
% ***                          P R O C E S S I N G                           ***
% ******************************************************************************

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% COMPUTE EXTERNAL FORCES
%   integrate the tractions on the left and right edges
disp([num2str(toc), '   COMPUTING EXTERNAL LOADS'])
% COMPUTE EXTERNAL FORCES
[W, Q] = quadrature(2, 'GAUSS', 1); % three point quadrature
%
% left EDGE for force conditions
%

hold on
inEdge = [];

for iel = 1:numel(AdaptiveMesh.Elements)
    str = AdaptiveMesh.Elements{iel};
    Rx2 = AdaptiveMesh.Nodes(str, 1).^2;
    Ry2 = AdaptiveMesh.Nodes(str, 2).^2;
    R = sqrt(Rx2 + Ry2);
    nodeF = find(abs(R - a) < 1e-2);
    if numel(nodeF) > 1
        if isempty(nodeF) == 0
            if AdaptiveMesh.Nodes(str(nodeF(1)), 2) < AdaptiveMesh.Nodes(str(nodeF(2)), 2)
                inEdge = [inEdge; [str(nodeF(1)), str(nodeF(2))]];
            else
                inEdge = [inEdge; [str(nodeF(2)), str(nodeF(1))]];
            end
            plot(AdaptiveMesh.Nodes(str(nodeF), 1), AdaptiveMesh.Nodes(str(nodeF), 2), '*r');
        end
    end
end

for e = 1:size(inEdge, 1)% loop over the elements in the right edge
    sctr = inEdge(e, :); % scatter vector for the element
    sctrx = 2 .* sctr - 1; % x scatter vector
    sctry = 2 .* sctr; % y scatter vector
    x = node(sctr, 1);
    y = node(sctr, 2);
    
    % compute normal vector
    dist = sqrt((x(2) - x(1))^2 + (y(2) - y(1))^2);
    n(1) = (y(2) - y(1)) / dist; % x direction normal of ie th side
    n(2) = -(x(2) - x(1)) / dist; % y direction normal of ie th side
    
    for q = 1:size(W, 1)% quadrature loop
        pt = Q(q, :); % quadrature point
        wt = W(q); % quadrature weight
        [N, dNdxi] = lagrange_basis(edgeElemType, pt); % element shape functions
        J0 = dNdxi' * node(sctr, :); % element Jacobian
        detJ0 = norm(J0); % determiniat of jacobian
        
        x = N' * node(sctr, 1); % x coordinate at quadrature point
        y = N' * node(sctr, 2); % y coordinate at quadrature point
        
        % quiver(x, y, n(1)*0.1, n(2)*0.1, 'k');
        
        px = P * n(1);
        py = P * n(2);
        
        F(sctrx) = F(sctrx) + N * px * detJ0 * wt;
        F(sctry) = F(sctry) + N * py * detJ0 * wt;
    end % of quadrature loop
    
end % of element loop

%%%%%%%%%%%%%%%%%%%%% COMPUTE STIFFNESS MATRIX %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
disp([num2str(toc), '   COMPUTING STIFFNESS MATRIX'])

Material.Dm = Dm;
Material.nu = nu0;
Material.E = E0;
K = computePCEnStiffnessMatrix(stressState, Material, gamma, ndof, basisLAB, MethodLAB, cenDOF);

%%%%%%%%%%%%%%%%%%% END OF STIFFNESS MATRIX COMPUTATION %%%%%%%%%%%%%%%%%%%%%%

% APPLY ESSENTIAL BOUNDARY CONDITIONS
% SOLVE SYSTEM
disp([num2str(toc), '   SOLVING SYSTEM'])
freedof = setdiff((1:2 * (numnode))', bcdof);
U = zeros(ndof * numnode, 1);
U(bcdof) = bcval;
F(freedof) = F(freedof) - K(freedof, bcdof) * bcval;

% solving system of equations for free dofs
U(freedof) = K(freedof, freedof) \ F(freedof);

problem.LAB = 'CYLINDER';
problem.E = E0;
problem.nu = nu0;
problem.a = a;
problem.b = b;
problem.P = P;
problem.Dm = Dm;
problem.gamma = gamma;
if strcmp(MethodLAB, 'Classic')
    [dnorm1, enorm1] = errorNormClassicPFEM(problem, stressState, U, basisLAB);
    disp(['Displacement Norm = ', num2str(dnorm1, 20)]);
    disp(['Energy Norm = ', num2str(enorm1, 20)]);
elseif strcmp(MethodLAB, 'SBFEM')
    sdStrnMode = SElementStrainMode2NodeEle(sdSln);
    sdIntgConst = SElementIntgConst(U, sdSln);
    %[dnorm1, enorm1] = errorNormSBFEM(problem,sdSln, sdStrnMode, sdIntgConst);
    %disp(['Displacement Norm = ', num2str(dnorm1, 20)]);
    %disp(['Energy Norm = ', num2str(enorm1, 20)]);
elseif strcmp(MethodLAB, 'PCEn')
    [dnorm2, enorm2, pnorm2] = evalErrorNormPCEn(problem, stressState, U, basisLAB, cenDOF);
    disp(['Displacement Norm = ', num2str(dnorm2, 20)]);
    disp(['Energy Norm = ', num2str(enorm2, 20)]);
    disp(['Pressure Norm = ', num2str(pnorm2, 20)]);
elseif strcmp(MethodLAB, 'LSS')
    [dnorm3, enorm3] = errorNormLSSPFEM(problem, U);
    disp(['Displacement Norm = ', num2str(dnorm3, 20)]);
    disp(['Energy Norm = ', num2str(enorm3, 20)]);
else
    error('Not implemented yet!')
end

%******************************************************************************
%***                     P O S T  -  P R O C E S S I N G                    ***
%**************************************************************************
[W, Q] = quadrature(2, 'GAUSS', 2); % 2x2 Gaussian quadrature

if strcmp(MethodLAB, 'Classic')
    stressNode = computeStressNodeClassic(numnode, numelem, element, node, Dm, U, basisLAB);
elseif strcmp(MethodLAB, 'PCEn')
    if (strcmp(stressState, 'PLANE_STRAIN'))
        %[stressNode, stressElem, pressureNode, pressureElem] = stressNodeCFEMPoly(stressState, numnode, numelem, element, node, Dm, gamma, U, basisLAB, E0, nu0);
        [stressNode, stressElem, pressureNode, pressureElem] = computeStressNodePCEn(stressState, numnode, numelem, element, node, Dm, gamma, U, basisLAB, E0, nu0);
    elseif (strcmp(stressState, 'PLANE_STRESS'))
        %[stressNode, stressElem] = stressNodeCFEMPoly(stressState, numnode, numelem, element, node, Dm, gamma, U, basisLAB, E0, nu0);
        [stressNode, stressElem] = computeStressNodePCEn(stressState, numnode, numelem, element, node, Dm, gamma, U, basisLAB, E0, nu0, cenDOF);
    end
end
%
%     %func = @(x) sqrt((1 / 2 * ((x(1) - x(2)) .^ 2 + (x(2)) .^ 2 + (x(1)) .^ 2)) + 3 * (x(3) .^ 2));
%     %vonMisesElem = cellfun(func, stressElem);
stress = zeros([6, numnode]);
stress([1, 2, 4], :) = stressNode;

exportCFEMDisplToVTU(AdaptiveMesh, U, strcat('PCEn_CylinderHollowPlate_Displ_', stressState, '_', elemType))
exportCFEMStressToVTU(AdaptiveMesh, stress, stressState, strcat('PCEn_CylinderHollowPlate_Stress_', stressState, '_', elemType));

%     pressure = zeros(numnode, 1);
%     for ivo = 1:numnode
%         pressure(ivo) = (1 + nu0) * (stressNode(1, ivo) + stressNode(2, ivo)) / 3;
%     end

%     abs(pressureNode - pressure)
%     exportCFEMToVTU(AdaptiveMesh, pressure, strcat('CylinderHollowPlate_CPEn_Pressure_', stressState, '_', elemType, '_'))