function triangulation_triangle_neighors (nodes3, triangles3 )

%% MAIN is the main program for TRIANGULATION_TRIANGLE_NEIGHBORS.
%
%  Discussion:
%
%    TRIANGULATION_TRIANGLE_NEIGHBORS determines the neighbor triangles 
%    of each triangle in a triangulation.
%
%    The user supplies a node file and a triangle file, containing
%    the coordinates of the nodes, and the indices of the nodes that
%    make up each triangle.  Either 3-node or 6-node triangles may
%    be used.
%
%    The program reads the node and triangle data, computes the triangle
%    neighbor information, and writes it to a file.
%
%  Modified:
%
%    01 January 2007
%
%  Author:
%
%    John Burkardt
%
%  Usage:
%
%    triangulation_triangle_neighbors ( 'node_file', 'triangulation_file' )
%
  timestamp;

  fprintf ( 1, '\n' );
  fprintf ( 1, 'TRIANGULATION_TRIANGLE_NEIGHBORS\n' );
  fprintf ( 1, '  MATLAB version\n' );
  fprintf ( 1, '  Read a node dataset of NODE_NUM points in 2 dimensions.\n' );
  fprintf ( 1, '  Read an associated triangulation dataset of \n' );
  fprintf ( 1, '  TRIANGLE_NUM triangles using 3 or 6 nodes.\n' );
  fprintf ( 1, '\n' );
  fprintf ( 1, '  For each triangle, determine the indices of the\n' );
  fprintf ( 1, '  triangles opposite vertices 1, 2 and 3.\n' );
  fprintf ( 1, '\n' );
  fprintf ( 1, '  Write this triangle neighbor data to files.\n' );
%
%  If at least one command line argument, it's the node file name.
%
  if ( nargin < 1 )

    fprintf ( 1, '\n' );
    fprintf ( 1, 'TRIANGULATION_TRIANGLE_NEIGHBORS:\n' );
    input_node_filename = input ( '  Please enter the name of the node file.' );

  end
%
%  If at least two command line arguments, the second is the triangulation file.
%
  if ( nargin < 2 )

    fprintf ( 1, '\n' );
    fprintf ( 1, 'TRIANGULATION_TRIANGLE_NEIGHBORS:\n' );
    input_triangulation_filename = input ( ...
      '  Please enter the name of the triangulation file.' );

  end
%
%  Read the node data.
%
  [ dim_num, node_num ] = dtable_header_read (  nodes3 );

  fprintf ( 1, '\n' );
  fprintf ( 1, '  Read the header of "%s".\n', triangles );
  fprintf ( 1, '\n' );
  fprintf ( 1, '  Spatial dimension DIM_NUM = %d\n', dim_num );
  fprintf ( 1, '  Number of nodes NODE_NUM  = %d\n', node_num );

  node_xy(1:dim_num,1:node_num) = dtable_data_read ( nodes3, ...
    dim_num, node_num );

  fprintf ( 1, '\n' );
  fprintf ( 1, '  Read the data in "%s".\n', input_node_filename );

  r8mat_transpose_print_some ( dim_num, node_num, node_xy, 1, 1, ...
    dim_num, 5, '  Coordinates of first 5 nodes:' );
%
%  Read the triangulation data.
%
  [ triangle_order, triangle_num ] = itable_header_read ( ...
    input_triangulation_filename );

  fprintf ( 1, '\n' );
  fprintf ( 1, '  Read the header of "%s".\n', input_triangulation_filename );
  fprintf ( 1, '\n' );
  fprintf ( 1, '  Triangle order TRIANGLE_ORDER = %d\n', triangle_order );
  fprintf ( 1, '  Number of triangles TRIANGLE_NUM  = %d\n', triangle_num );

  if ( triangle_order ~= 3 & triangle_order ~= 6 )
    fprintf ( 1, '\n' );
    fprintf ( 1, 'TRIANGULATION_TRIANGLE_NEIGHBORS - Fatal error!\n' );
    fprintf ( 1, '  This program can only handle triangulations\n' );
    fprintf ( 1, '  of orders 3 and 6.\n' );
    fprintf ( 1, '\n' );
    fprintf ( 1, '  The input triangulation seems to have\n' );
    fprintf ( 1, '  order = %d\n', triangle_order );
    error ( 'TRIANGULATION_TRIANGLE_NEIGHBORS - Fatal error!' );
  end

  triangle_node(1:triangle_order,1:triangle_num) = itable_data_read ( ...
    input_triangulation_filename, triangle_order, triangle_num );

  fprintf ( 1, '\n' );
  fprintf ( 1, '  Read the data in "%s".\n', input_triangulation_filename );

  i4mat_transpose_print_some ( triangle_order, triangle_num, ...
    triangle_node, 1, 1, triangle_order, 5, '  First 5 triangles:' );
%
%  Create the triangle neighbor array.
%
  if ( triangle_order == 3 )

    triangle_neighbor = triangulation_order3_neighbor_triangles ( ...
      triangle_num, triangle_node );

  elseif ( triangle_order == 6 )

    triangle_neighbor = triangulation_order6_neighbor_triangles ( ...
      triangle_num, triangle_node );

  end
%
%  Write the nodes.
%
  output_tneighbor_filename = file_name_ext_swap ( ...
    input_triangulation_filename, 'tneighbor.txt' );

  header = 0;
  itable_write ( output_tneighbor_filename, 3, triangle_num, ...
    triangle_neighbor, header );

  fprintf ( 1, '\n' );
  fprintf ( 1, '  Created the triangle neighbor file "%s".\n', ...
    output_tneighbor_filename );

  fprintf ( 1, '\n' );
  fprintf ( 1, 'TRIANGULATION_TRIANGLE_NEIGHBORS:\n' );
  fprintf ( 1, '  Normal end of execution.\n' );

  fprintf ( 1, '\n' );
  timestamp;
