function value = s_index_last_c ( s, c )

%% S_INDEX_LAST_C finds the LAST occurrence of a given character.
%
%  Modified:
%
%    20 November 2004
%
%  Author:
%
%    John Burkardt
%
%  Parameters:
%
%    Input, character S(*), the string to be searched.
%
%    Input, character C, the character to search for.
%
%    Output, integer VALUE, the index in S where C occurs
%    last, or -1 if it does not occur.
%
  if ( c == ' ' )
    s_len = length ( s );
  else
    s_len = s_len_trim ( s );
  end

  for i = s_len : -1 : 1

    if ( s(i) == c )
      value = i;
      return
    end

  end

  value = -1;
