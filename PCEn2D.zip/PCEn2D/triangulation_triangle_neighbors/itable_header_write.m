function itable_header_write ( output_filename, output_unit, m, n )

%% ITABLE_HEADER_WRITE writes the header to a table file.
%
%  Modified:
%
%    22 October 2004.
%
%  Author:
%
%    John Burkardt
%
%  Parameters:
%
%    Input, string OUTPUT_FILENAME, the output filename.
%
%    Input, integer OUTPUT_UNIT, the output unit.
%
%    Input, integer M, the spatial dimension.
%
%    Input, integer N, the number of points.
%
  s = timestring;

  fprintf ( output_unit, '#  %s\n', output_filename );
  fprintf ( output_unit, '#  created by TABLE_IO.M\n' );
  fprintf ( output_unit, '#  at %s\n', s );
  fprintf ( output_unit, '#\n' );
  fprintf ( output_unit, '#  Spatial dimension M = %d\n', m );
  fprintf ( output_unit, '#  Number of points N = %d\n', n );
  fprintf ( output_unit, '#\n' );
