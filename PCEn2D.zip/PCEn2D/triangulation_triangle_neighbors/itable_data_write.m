function itable_data_write ( output_unit, m, n, table )

%% ITABLE_DATA_WRITE writes data to an integer table file.
%
%  Discussion:
%
%    This routine writes a single line of output for each point,
%    containing its spatial coordinates.
%
%  Modified:
%
%    22 October 2004
%
%  Author:
%
%    John Burkardt
%
%  Parameters:
%
%    Input, integer OUTPUT_UNIT, the output unit.
%
%    Input, integer M, the spatial dimension.
%
%    Input, integer N, the number of points.
%
%    Input, integer TABLE(M,N), the points.
%
  for j = 1 : n
    for i = 1 : m
      fprintf ( output_unit, '%12d  ', round ( table(i,j) ) );
    end
    fprintf ( output_unit, '\n' );
  end
