function itable_write ( output_filename, m, n, table, header )

%% ITABLE_WRITE writes information to an integer table file.
%
%  Modified:
%
%    20 July 2005
%
%  Author:
%
%    John Burkardt
%
%  Parameters:
%
%    Input, string OUTPUT_FILENAME, the output filename.
%
%    Input, integer M, the spatial dimension.
%
%    Input, integer N, the number of points.
%
%    Input, integer TABLE(M,N), the points.
%
%    Input, logical HEADER, is TRUE if the header is to be included.
%
  output_unit = fopen ( output_filename, 'wt' );

  if ( output_unit < 0 ) 
    fprintf ( 1, '\n' );
    fprintf ( 1, 'ITABLE_WRITE - Error!\n' );
    fprintf ( 1, '  Could not open the output file.\n' );
    error ( 'ITABLE_WRITE - Error!' );
    return;
  end

  if ( header )
    itable_header_write ( output_filename, output_unit, m, n );
  end

  itable_data_write ( output_unit, m, n, table );

  fclose ( output_unit );

