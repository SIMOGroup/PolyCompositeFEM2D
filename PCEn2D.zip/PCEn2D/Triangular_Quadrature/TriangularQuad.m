function [weight, point] = TriangularQuad(p, ngauss)
% [W, Q] = T3Quad(ngauss);                  %integration pnts & wgts for ref. triangle
[Q, ~, W, ~] = getQuadData(ngauss);
point = zeros(length(W), 2); 
weight = zeros(length(W), 1);
% dNdx = zeros(2, 3, 3);
for q = 1 : length(W)
    [N, dNds] = T3ShapeFnc(Q(q, :));  %compute shape functions
    % J0 = p' * dNds';
    J0 = dNds * p;
    %dNdx(:, :, q) = J0 \ dNds;
    point(q, :) = N*p;
    weight(q) = det(J0)*W(q);
end
end