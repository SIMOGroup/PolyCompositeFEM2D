function [N, dNds] = T3ShapeFnc(pospg)

xi = pospg(:, 1); eta = pospg(:, 2);
N    = [1 - (xi + eta), xi, eta];
Nxi  = [-ones(size(xi)), ones(size(xi)), zeros(size(xi))];
Neta = [-ones(size(xi)), zeros(size(xi)), ones(size(xi)),];
dNds = [Nxi; Neta];

end