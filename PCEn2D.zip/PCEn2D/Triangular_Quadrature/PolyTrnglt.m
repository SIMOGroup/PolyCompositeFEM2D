function [p, Tri] = PolyTrnglt(nn, xi)
% [p, Tri] = PolyTrnglt(nn, xi)
%--------------------------------------------------------------------------
% Input:
%       nn: the number of polygon vertices
%       xi: coordinate of interior point
% ------------------------------------------------------------------
% Output:
%       p: nodal coordinates of the reference polygon
%       Tri: nodal connectivities for sub triangles
% ------------------------------------------------------------------

%{
This function generates a directed triangulation of the reference n-gon by
connecting its vertices to the input point \xi that lies in its interior. 
The nodes of the reference n-gon are located at 
pi = (cos((2*\pi*i)/n), sin((2*\pi*i)/n)). This function is used both in 
the definition of the polygonal shape functions and the quadrature rule.
%}

p = [cos(2*pi*((1 : nn)) / nn); sin(2*pi*((1 : nn)) / nn)]';
p = [p; xi];
Tri = zeros(nn, 3);
Tri(1 : nn, 1) = nn + 1;
Tri(1 : nn, 2) = 1 : nn; 
Tri(1 : nn, 3) = 2 : nn + 1; 
Tri(nn, 3) = 1;
end