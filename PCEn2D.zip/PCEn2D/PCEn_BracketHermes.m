clear
close all;
clc
format long
global node element thickness;
% ******************************************************************************
% ***                             I N P U T                                  ***
% ******************************************************************************
tic;
disp('************************************************')
disp('***          S T A R T I N G    R U N        ***')
disp('************************************************')

disp([num2str(toc), '   START'])

% MATERIAL PROPERTIES
E0 = 2.1e11; % Young's modulus
nu0 = 0.3;  % Poisson's ratio
% nu0 = 0.4999999;

L = 0.7;
T = 0.1;
thickness = 1;
f = 1e3;

% MESH PROPERTIES
elemType = 'Poly';
% elemType = 'CQ4';

MethodLAB = 'PCEn';
% MethodLAB = 'Classic';

basisLAB = 'T3';
% basisLAB = 'Wachspress';
% basisLAB = 'CorrectedWachspress';

cenDOF = 'no';

plotMesh = 1;

MaxIt = 50;

% STRESS ASSUMPTION
% stressState = 'PLANE_STRAIN'; % set to either 'PLANE_STRAIN' or "PLANE_STRESS'
stressState = 'PLANE_STRESS';

warning(['Running under ', stressState, ' condition with ', 'nu = ', num2str(nu0, 16), ' and ', MethodLAB, ' approach with ', basisLAB, ' basis functions.'])

% ******************************************************************************
% ***                    P R E - P R O C E S S I N G                         ***
% ******************************************************************************
% COMPUTE ELASTICITY MATRIX
[Dm, gamma] = Dmaterial(E0, nu0, stressState);
%
%               GENERATE FINITE ELEMENT MESH

disp([num2str(toc), '   GENERATING MESH'])

switch elemType
    case 'CQ4'% here we generate the mesh of Q4 elements
        error('Not implemented yet!')
    case 'Poly'
        %im = 3;
        %Nelem = 1000;
        %[node, element] = PolyMesher(@BracketHermesDomain, Nelem, 1000);
        %save(strcat('MeshBracketHermes', num2str(Nelem)), 'node', 'element');
        
        load('MeshBracketHermes1000', 'node', 'element')
        
        AdaptiveMesh.Nodes = node;
        AdaptiveMesh.Elements = element;
        edgeElemType = 'L2';
end

% f = @(y) sqrt((0.693 - T)^2 + (y - T)^2) - L;
% fsolve(f, 0.4)

numnode = size(node, 1); % number of nodes
numelem = numel(element); % number of elements
ndof = 2;

if plotMesh% if plotMesh==1 we will plot the mesh
    clf
    Plot_PolyMesh(node, element, 0);
    hold on
end

% ---------------------------------------------------------------------
RightBC = find(AdaptiveMesh.Nodes(:, 1) > L + T - 1e-3 & AdaptiveMesh.Nodes(:, 1) < L + T + 1e-3);

for i = 1:length(RightBC) - 1
    for j = i + 1:length(RightBC)
        if AdaptiveMesh.Nodes(RightBC(i), 2) > AdaptiveMesh.Nodes(RightBC(j), 2)
            tmp = RightBC(i);
            RightBC(i) = RightBC(j);
            RightBC(j) = tmp;
        end
    end
end

RightEdge = [RightBC(1:end - 1), RightBC(2:end)];

TopBC = find(AdaptiveMesh.Nodes(:, 2) > L + T - 1e-3 & AdaptiveMesh.Nodes(:, 2) < L + T + 1e-3);
for i = 1:length(TopBC) - 1
    for j = i + 1:length(TopBC)
        if AdaptiveMesh.Nodes(TopBC(i), 1) > AdaptiveMesh.Nodes(TopBC(j), 1)
            tmp = TopBC(i);
            TopBC(i) = TopBC(j);
            TopBC(j) = tmp;
        end
    end
end

TopEdge = [TopBC(1:end - 1), TopBC(2:end)];

% GET NODES ON DISPLACEMENT BOUNDARY
fixedNodeX = unique(RightBC);
fixedNodeY = unique(RightBC);

bcdof = [fixedNodeX * 2 - 1; fixedNodeY * 2];
bcval = zeros(size(bcdof));

disp([num2str(toc), '   INITIALIZING DATA STRUCTURES'])
F = zeros(2 * (numnode), 1); % external load vector
%K = sparse(2 * (numnode), 2 * (numnode)); % stiffness matrix

% ******************************************************************************
% ***                          P R O C E S S I N G                           ***
% ******************************************************************************

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% COMPUTE EXTERNAL FORCES
%   integrate the tractions on the left and right edges
disp([num2str(toc), '   COMPUTING EXTERNAL LOADS'])
% COMPUTE EXTERNAL FORCES
[W, Q] = quadrature(2, 'GAUSS', 1); % three point quadrature

for e = 1:size(TopEdge, 1)% loop over the elements in the right edge
    sctr = TopEdge(e, :); % scatter vector for the element
    sctrx = 2 .* sctr - 1; % x scatter vector
    sctry = 2 .* sctr; % y scatter vector
    x = node(sctr, 1);
    y = node(sctr, 2);
    
    % compute normal vector
    dist = sqrt((x(2) - x(1))^2 + (y(2) - y(1))^2);
    n(1) = (y(2) - y(1)) / dist; % x direction normal of ie th side
    n(2) = -(x(2) - x(1)) / dist; % y direction normal of ie th side
    
    for q = 1:size(W, 1)% quadrature loop
        pt = Q(q, :); % quadrature point
        wt = W(q); % quadrature weight
        [N, dNdxi] = lagrange_basis(edgeElemType, pt); % element shape functions
        J0 = dNdxi' * node(sctr, :); % element Jacobian
        detJ0 = norm(J0); % determiniat of jacobian
        
        x = N' * node(sctr, 1); % x coordinate at quadrature point
        y = N' * node(sctr, 2); % y coordinate at quadrature point
        
        %quiver(x, y, n(1)*0.1, n(2)*0.1, 'k');
        
        px = f * n(1);
        py = f * n(2);
        
        F(sctrx) = F(sctrx) + N * px * detJ0 * wt;
        F(sctry) = F(sctry) + N * py * detJ0 * wt;
    end % of quadrature loop
    
end % of element loop

%%%%%%%%%%%%%%%%%%%%% COMPUTE STIFFNESS MATRIX %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
disp([num2str(toc), '   COMPUTING STIFFNESS MATRIX'])

Material.Dm = Dm;
Material.nu = nu0;
Material.E = E0;
K = computePCEnStiffnessMatrix(stressState, Material, gamma, ndof, basisLAB, MethodLAB, cenDOF);

%%%%%%%%%%%%%%%%%%% END OF STIFFNESS MATRIX COMPUTATION %%%%%%%%%%%%%%%%%%%%%%

% APPLY ESSENTIAL BOUNDARY CONDITIONS
% SOLVE SYSTEM
disp([num2str(toc), '   SOLVING SYSTEM'])
freedof = setdiff((1:2 * (numnode))', bcdof);
U = zeros(ndof * numnode, 1);
U(bcdof) = bcval;
F(freedof) = F(freedof) - K(freedof, bcdof) * bcval;

% solving system of equations for free dofs
U(freedof) = K(freedof, freedof) \ F(freedof);

EU = 0.5 * U' * K * U;
disp(['Strain Energy = ', num2str(EU, 20)]);

%******************************************************************************
%***                     P O S T  -  P R O C E S S I N G                    ***
%**************************************************************************
[W, Q] = quadrature(2, 'GAUSS', 2); % 2x2 Gaussian quadrature

if strcmp(MethodLAB, 'Classic')
    stressNode = computeStressNodeClassic(numnode, numelem, element, node, Dm, U, basisLAB);
elseif strcmp(MethodLAB, 'PCEn')
    if (strcmp(stressState, 'PLANE_STRAIN'))
        %[stressNode, stressElem, pressureNode, pressureElem] = stressNodeCFEMPoly(stressState, numnode, numelem, element, node, Dm, gamma, U, basisLAB, E0, nu0);
        [stressNode, stressElem, pressureNode, pressureElem] = computeStressNodePCEn(stressState, numnode, numelem, element, node, Dm, gamma, U, basisLAB, E0, nu0);
    elseif (strcmp(stressState, 'PLANE_STRESS'))
        %[stressNode, stressElem] = stressNodeCFEMPoly(stressState, numnode, numelem, element, node, Dm, gamma, U, basisLAB, E0, nu0);
        [stressNode, stressElem] = computeStressNodePCEn(stressState, numnode, numelem, element, node, Dm, gamma, U, basisLAB, E0, nu0, cenDOF);
    end
end

%func = @(x) sqrt((1 / 2 * ((x(1) - x(2)) .^ 2 + (x(2)) .^ 2 + (x(1)) .^ 2)) + 3 * (x(3) .^ 2));
%vonMisesElem = cellfun(func, stressElem);
stress = zeros([6, numnode]);
stress([1, 2, 4], :) = stressNode;

exportCFEMDisplToVTU(AdaptiveMesh, U, strcat('BracketHermes_', MethodLAB, '_Displ_', stressState, '_', elemType))
exportCFEMStressToVTU(AdaptiveMesh, stress, stressState, strcat('BracketHermes_', MethodLAB, '_Stress_', stressState, '_', elemType));
