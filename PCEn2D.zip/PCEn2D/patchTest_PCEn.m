% patchtest.m
%
% Solves a linear elastic 2D patch test problem
% Liu GR, IJNME (2011) 85: 461-497
%
% *********************************************************************************
%
%      by Hung Nguyen-Xuan
%      HUTECH University
%
% *********************************************************************************

clear
clc
close all
format long

% colordef black
state = 0;
global node element thickness;
% ******************************************************************************
% ***                             I N P U T                                  ***
% ******************************************************************************
tic;
disp('************************************************')
disp('***          S T A R T I N G    R U N        ***')
disp('************************************************')

disp([num2str(toc), '   START'])

% BEAM PROPERTIES
L = 0.24; %m
H = 0.12; %m

thickness = 1e-3;
% MESH PROPERTIES
elemType = 'Poly';
% elemType = 'CQ4';
numx = 2;
numy = 2;

MethodLAB = 'PCEn';
% MethodLAB = 'Classic';

% basisLAB = 'T3';
% basisLAB = 'Wachspress';
basisLAB = 'CorrectedWachspress';

cenDOF = 'yes';

OrderLAB = 'Linear';
% OrderLAB = 'Quadratic';

% MATERIAL PROPERTIES
if strcmp(OrderLAB, 'Linear')
    E0 = 1e6; % Young's modulus
    nu0 = 0.25; % Poisson's ratio
elseif strcmp(OrderLAB, 'Quadratic')
    E0 = 1e3;
    nu0 = 0.3;
else
    error('Not implemented yet!')
end

plotMesh = 1;

% STRESS ASSUMPTION
stressState = 'PLANE_STRESS'; % set to either 'PLANE_STRAIN' or "PLANE_STRESS'

warning(['Running under ', stressState, ' condition with ', 'nu = ', num2str(nu0, 16), ' and ', MethodLAB, ' approach with ', basisLAB, ' basis functions.'])

% ******************************************************************************
% ***                    P R E - P R O C E S S I N G                         ***
% ******************************************************************************

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% COMPUTE ELASTICITY MATRIX
[Dm, gamma] = Dmaterial(E0, nu0, stressState);

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
disp([num2str(toc), '   GENERATING MESH'])
% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
switch elemType
        %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    case 'Poly'
        Nelem = 15;
        [node,element] = PolyMesher(@patchTestDomain,Nelem,300);axis on

        rightnode = find(abs(node(:, 1) - L) < 1e-5);
        [~, idx] = sort(node(rightnode, 2), 'descend');
        rightnode = rightnode(idx);
        rightEdge = [rightnode(1:end - 1), rightnode(2:end)];
        leftnode = find(abs(node(:, 1) - 0) < 1e-5);
        [~, idx] = sort(node(leftnode, 2), 'descend');
        leftnode = leftnode(idx);
        leftEdge = [leftnode(1:end - 1), leftnode(2:end)];

        uppernode = find(abs(node(:, 2) - H) < 1e-5);
        [~, idx] = sort(node(uppernode, 1), 'descend');
        uppernode = uppernode(idx);
        upperEdge = [uppernode(1:end - 1), uppernode(2:end)];

        lowernode = find(abs(node(:, 2) - 0) < 1e-5);
        [~, idx] = sort(node(lowernode, 1), 'descend');
        lowernode = lowernode(idx);
        lowerEdge = [lowernode(1:end - 1), lowernode(2:end)];
        edgeElemType = 'L2';
    case 'CQ4'% here we generate the mesh of Q4 elements
        air = 0.3;
        nnx = numx + 1;
        nny = numy + 1;
        node = square_node_array([0, 0], [L, 0], [L, H], [0, H], nnx, nny);
        gcoord = singularmesh_beam(H, L, numx, numy, air);
        inc_u = 1;
        inc_v = nnx;
        node_pattern = [1, 2, nnx + 2, nnx + 1];

        element = make_elem(node_pattern, numx, numy, inc_u, inc_v);

        rightnode = find(abs(node(:, 1) - L) < 1e-5);
        [~, idx] = sort(node(rightnode, 2), 'descend');
        rightnode = rightnode(idx);
        rightEdge = [rightnode(1:end - 1), rightnode(2:end)];
        leftnode = find(abs(node(:, 1) - 0) < 1e-5);
        [~, idx] = sort(node(leftnode, 2), 'descend');
        leftnode = leftnode(idx);
        leftEdge = [leftnode(1:end - 1), leftnode(2:end)];

        uppernode = find(abs(node(:, 2) - H) < 1e-5);
        [~, idx] = sort(node(uppernode, 1), 'descend');
        uppernode = uppernode(idx);
        upperEdge = [uppernode(1:end - 1), uppernode(2:end)];

        lowernode = find(abs(node(:, 2) - 0) < 1e-5);
        [~, idx] = sort(node(lowernode, 1), 'descend');
        lowernode = lowernode(idx);
        lowerEdge = [lowernode(1:end - 1), lowernode(2:end)];
        edgeElemType = 'L2';
        node(5, 1) = 0.15;
        node(5, 2) = 0.08;
end

% save('patchTest', 'node', 'element')
numnode = size(node, 1); % number of nodes
numelem = size(element, 1); % number of elements
ndof = 2;

if plotMesh% if plotMesh==1 we will plot the mesh
    Plot_PolyMesh(node, element, 0);
    hold on;

    for i = 1:numnode
        text(node(i, 1), node(i, 2), num2str(i));
    end

end

% GET NODES ON DISPLACEMENT BOUNDARY
fixedNode = unique([leftEdge; rightEdge; lowerEdge; upperEdge]);

% LEFT EDGE ENFORCE BOUNDARY CONDITION

if strcmp(OrderLAB, 'Linear')
    warning('Running under Linear Patch Test')
    UExact = @(x, y) 1e-3 * (x + y ./ 2);
    VExact = @(x, y) 1e-3 * (x ./ 2 + y);
    strain = [1e-3; 1e-3; 1e-3];
    stress = Dm * strain;
elseif strcmp(OrderLAB, 'Quadratic')
    warning('Running under Quadratic Patch Test')
    UExact = @(x, y) 0.1 * x .^ 2 + 0.1 * x .* y + 0.2*y .^ 2;
    VExact = @(x, y) 0.05 * x .^ 2 + 0.15 * x .* y + 0.1 * y .^ 2;
else
    error('Not implemented yet!')
end

bcdof = [fixedNode * 2 - 1; fixedNode * 2];
bcval = [UExact(node(fixedNode, 1), node(fixedNode, 2)); VExact(node(fixedNode, 1), node(fixedNode, 2))];

disp([num2str(toc), '   INITIALIZING DATA STRUCTURES'])
F = zeros(2 * (numnode), 1); % external load vector

% ******************************************************************************
% ***                          P R O C E S S I N G                           ***
% ******************************************************************************

%%%%%%%%%%%%%%%%%%%%% COMPUTE STIFFNESS MATRIX %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
disp([num2str(toc), '   COMPUTING STIFFNESS MATRIX'])

Material.Dm = Dm;
Material.nu = nu0;
Material.E = E0;
K = computePCEnStiffnessMatrix(stressState, Material, gamma, ndof, basisLAB, MethodLAB, cenDOF);

% SOLVE SYSTEM
disp([num2str(toc), '   SOLVING SYSTEM'])
freedof = setdiff((1:2 * (numnode))', bcdof);
U = zeros(ndof * numnode, 1);
U(bcdof) = bcval;
F(freedof) = F(freedof) - K(freedof, bcdof) * bcval;

% solving system of equations for free dofs
U(freedof) = K(freedof, freedof) \ F(freedof);

% U(10*2-1)
% U(10*2)

% UExact(node(10, 1), node(10, 2))
% VExact(node(10, 1), node(10, 2))

EU = 0.5 * U' * K * U;

%******************************************************************************
%***                     P O S T  -  P R O C E S S I N G                    ***
%**************************************************************************

if strcmp(OrderLAB, 'Linear')
    problem.LAB = 'LINEAR_PATCH_TEST';
elseif strcmp(OrderLAB, 'Quadratic')
    problem.LAB = 'QUADRATIC_PATCH_TEST';
else
    error('Not implemented yet!')
end
problem.E = E0;
problem.nu = nu0;
% problem.L = L;
% problem.D = D;
% problem.P = P;
problem.Dm = Dm;
problem.gamma = gamma;

if strcmp(MethodLAB, 'Classic')
    [dnorm1, enorm1] = errorNormClassicPFEM(problem, stressState, U, basisLAB);
    disp(['Displacement Norm = ', num2str(dnorm1, 20)]);
    disp(['Energy Norm = ', num2str(enorm1, 20)]);
elseif strcmp(MethodLAB, 'PCEn')
    [dnorm2, enorm2, pnorm2] = evalErrorNormPCEn(problem, stressState, U, basisLAB, cenDOF);
    disp(['Displacement Norm = ', num2str(dnorm2, 20)]);
    disp(['Energy Norm = ', num2str(enorm2, 20)]);
else
    error('Not implemented yet!')
end
