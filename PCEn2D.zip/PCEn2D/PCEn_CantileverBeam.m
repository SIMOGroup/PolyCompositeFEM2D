clear
close all
clc
format long

global L node element thickness;
% ******************************************************************************
% ***                             I N P U T                                  ***
% ******************************************************************************
tic;
disp('************************************************')
disp('***          S T A R T I N G    R U N        ***')
disp('************************************************')

disp([num2str(toc), '   Start'])

% MATERIAL PROPERTIES
E0 = 3e7; % Young's modulus
nu0 = 0.3; % Poisson's ratio
% nu0 = 0.4999999; % Poisson's ratio

% BEAM PROPERTIES
L = 48; % length of the beam
D = 12;
thickness = 1;
c = D / 2; % the distance of the outer fiber of the beam from the mid-line

% MESH PROPERTIES
elemType = 'Poly';
% elemType = 'CQ4';
plotMesh = 1;

MethodLAB = 'PCEn';
% MethodLAB = 'Classic';

basisLAB = 'T3';
% basisLAB = 'Wachspress';
% basisLAB = 'CorrectedWachspress';

cenDOF = 'yes';

disp(basisLAB);
%
% numx = 32;
% numy = 8;

% numx = 32*2;
% numy = 8*2;

numx = 27; % the number of elements in the x-direction (beam length)
numy = 6; % the number of elements in the y-direction (width ength)

% numx = 39;
% numy = 9;

% numx = 55;
% numy = 13;

% numx = 79;
% numy = 19;

% numx = 111;
% numy = 27;

% numx = 159;
% numy = 39;

% TIP LOAD
P = 1000;

% STRESS ASSUMPTION
stressState = 'PLANE_STRESS';
% stressState = 'PLANE_STRAIN';

warning(['Running under ', stressState, ' condition with ', 'nu = ', num2str(nu0, 16), ' and ', MethodLAB, ' approach with ', basisLAB, ' basis functions.'])

% ******************************************************************************
% ***                    P R E - P R O C E S S I N G                         ***
% ******************************************************************************
I0 = 2 * c^3 / 3;

% COMPUTE ELASTICITY MATRIX
[Dm, gamma] = Dmaterial(E0, nu0, stressState);

disp([num2str(toc), '   Generating mesh'])
[element, node, nnx, nny] = meshBeam(elemType, numx, numy, L, c);

switch elemType
    case 'Poly'
        AdaptiveMesh.Nodes = node;
        AdaptiveMesh.Elements = element;
    case 'CQ4'
        AdaptiveMesh.Nodes = node;
        element = mat2cell(element, ones(size(element, 1), 1));
        AdaptiveMesh.Elements = element;
end

sqrt(L*D/numel(element))

edgeElemType = 'L2';

E1 = E0;
nu1 = nu0;
if (strcmp(stressState, 'PLANE_STRAIN'))
    E1 = E0 / (1 - nu0^2);
    nu1 = nu0 / (1 - nu0);
end

numnode = size(node, 1); % number of nodes
numelem = numel(element); % number of elements

% save(strcat('MeshBEAMQ4_', num2str(numnode*2)), 'node', 'element');
ndof = 2;

if plotMesh % if plotMesh==1 we will plot the mesh
    clf
    Plot_PolyMesh(node, element, 0);
    pause(1e-2)
    hold on;
end

% ---------------------------------------------------------------------
RightBC = find(AdaptiveMesh.Nodes(:, 1) > L-1e-3 & AdaptiveMesh.Nodes(:, 1) < L+1e-3);

for i = 1:length(RightBC) - 1
    for j = i + 1:length(RightBC)
        if AdaptiveMesh.Nodes(RightBC(i), 2) > AdaptiveMesh.Nodes(RightBC(j), 2)
            tmp = RightBC(i);
            RightBC(i) = RightBC(j);
            RightBC(j) = tmp;
        end
    end
end

RightEdge = [RightBC(1:end-1), RightBC(2:end)];
LeftBC = find(AdaptiveMesh.Nodes(:, 1) > 0-1e-3 & AdaptiveMesh.Nodes(:, 1) < 0+1e-3);

for i = 1:length(LeftBC) - 1
    for j = i + 1:length(LeftBC)
        if AdaptiveMesh.Nodes(LeftBC(i), 2) > AdaptiveMesh.Nodes(LeftBC(j), 2)
            tmp = LeftBC(i);
            LeftBC(i) = LeftBC(j);
            LeftBC(j) = tmp;
        end
    end
end

LeftEdge = [LeftBC(1:end-1), LeftBC(2:end)];

% LEFT EDGE ENFORCE BOUNDARY CONDITION
I = D^3 / 12;
bcdof = [LeftBC * 2 - 1; LeftBC * 2];

disp(['Num DOFs = ', num2str(ndof*numnode-numel(bcdof))])

solu = CantileverBeamPCEnExactSolu(L, D, E1, I, nu1, P);
bcval = [solu.ux(node(LeftBC, 1), node(LeftBC, 2)); solu.uy(node(LeftBC, 1), node(LeftBC, 2))];

disp([num2str(toc), '  Initialzing data structure'])


% ******************************************************************************
% ***                          P R O C E S S I N G                           ***
% ******************************************************************************

% integrate the tractions on the left and right edges
disp([num2str(toc), '  Computing load vector'])
F = zeros(ndof*(numnode + numelem), 1); % external load vector
F = loadBeam(elemType, edgeElemType, RightEdge, P, I0, c, F);
% Compute stiffness matrix
disp([num2str(toc), '  Computing stiffness matrix'])

Material.Dm = Dm;
Material.nu = nu0;
Material.E = E0;
K = computePCEnStiffnessMatrix(stressState, Material, gamma, ndof, basisLAB, MethodLAB, cenDOF);

% SOLVE SYSTEM
disp([num2str(toc), '   SOLVING SYSTEM'])
freedof = setdiff((1:ndof * (numnode))', bcdof);
% freedof = setdiff((1:ndof * (numnode + numelem))', bcdof);
U = zeros(ndof*numnode, 1);
% U = zeros(ndof * (numnode + numelem), 1);
U(bcdof) = bcval;
F(freedof) = F(freedof) - K(freedof, bcdof) * bcval;

% solving system of equations for free dofs
U(freedof) = K(freedof, freedof) \ F(freedof);

EU = 0.5 * U' * K * U;
disp(['Strain Energy = ', num2str(EU, 20)]);

CenterLineNodes = find(AdaptiveMesh.Nodes(:, 2) > 0-1e-3 & AdaptiveMesh.Nodes(:, 2) < 0+1e-3);
UYCenter = U(CenterLineNodes*2)';
XCoords = AdaptiveMesh.Nodes(CenterLineNodes, 1)';
UYCenterExact = solu.uy(AdaptiveMesh.Nodes(CenterLineNodes, 1), AdaptiveMesh.Nodes(CenterLineNodes, 2))';


%******************************************************************************
%***                     P O S T  -  P R O C E S S I N G                    ***
%**************************************************************************

problem.LAB = 'BEAM';
problem.E = E0;
problem.nu = nu0;
problem.L = L;
problem.D = D;
problem.P = P;
problem.Dm = Dm;
problem.gamma = gamma;
if strcmp(MethodLAB, 'Classic')
    [dnorm1, enorm1] = errorNormClassicPFEM(problem, stressState, U, basisLAB);
    disp(['Displacement Norm = ', num2str(dnorm1, 20)]);
    disp(['Energy Norm = ', num2str(enorm1, 20)]);
elseif strcmp(MethodLAB, 'PCEn')
    [dnorm2, enorm2, pnorm2] = evalErrorNormPCEn(problem, stressState, U, basisLAB, cenDOF);
    disp(['Displacement Norm = ', num2str(dnorm2, 20)]);
    disp(['Energy Norm = ', num2str(enorm2, 20)]);
    disp(['Pressure Norm = ', num2str(pnorm2, 20)]);
else
    error('Not implemented yet!')
end

%******************************************************************************
%***                     P O S T  -  P R O C E S S I N G                    ***
%**************************************************************************
[W, Q] = quadrature(2, 'GAUSS', 2); % 2x2 Gaussian quadrature

if strcmp(MethodLAB, 'Classic')
    stressNode = computeStressNodeClassic(numnode, numelem, element, node, Dm, U, basisLAB);
    [AdaptiveMesh.ETA, nuy, Dta_Re] = posterioriEstimateClassic(Dm, U, stressNode, basisLAB);
elseif strcmp(MethodLAB, 'PCEn')
    if (strcmp(stressState, 'PLANE_STRAIN'))
        [stressNode, stressElem, pressureNode, pressureElem] = computeStressNodePCEn(stressState, numnode, numelem, element, node, Dm, gamma, U, basisLAB, E0, nu0);
    elseif (strcmp(stressState, 'PLANE_STRESS'))
        [stressNode, stressElem] = computeStressNodePCEn(stressState, numnode, numelem, element, node, Dm, gamma, U, basisLAB, E0, nu0, cenDOF);
    end
end

stress = zeros([6, numnode]);
stress([1, 2, 4], :) = stressNode;

exportCFEMDisplToVTU(AdaptiveMesh, U, strcat('PCEn_CantileverBeam_Displ_', stressState, '_', elemType))
exportCFEMStressToVTU(AdaptiveMesh, stress, stressState, strcat('PCEn_CantileverBeam_Stress_', stressState, '_', elemType, '_', basisLAB));