function plotMesh(T,X,str,nonum)
% plotMesh(T,X,str,nonum)
% Funcion que dibuja la malla definida por X y T
% Input:  X:    coordenadas nodales
% 	  T:    conectividades (elementos)
% 	  str:  s�mbolos y color para el dibujo (opcional)
% 	  nonum = 1 si se quieren numerar los nodos (opcional)
%               = lista de nodos a numerar (opcional)

% definici�n del tipo de l�nea y color
if nargin == 2
  str1 = 'y.';
  str2 = 'y-';
else
  if str(1) == ':' | str(1) == '-'  
    str1 = 'y.'; 
    str2 = ['y' str];
  else
    str1 = [str(1) 'o'];
    str2 = str;
  end
end
 
nen = size(T,2);

elem=1;
aux = sqrt(nen);
if( abs(round(aux)-aux)<1.e-10) %Quadrilateral element
    elem = 0;
end

if elem == 0
    if nen <= 4
        order = [1:nen,1];
    elseif nen==9 
        % definici�n del orden para un elemento de 8 nodos
         order = [1 5 2 6 3 7 4 8 1];
    end
elseif elem == 1
    if nen <= 3
        order = [1:nen,1];
    elseif nen == 4
        order = [1  2  3  1];          
    elseif nen==6
        order = [1 4 2 5 3 6 1];      
    end
end

% Dibujo de los nodos
plot(X(:,1),X(:,2),str1)
hold on
% Dibujo de los elementos
for j = 1:size(T,1)
    plot(X(T(j,order),1),X(T(j,order),2),str2)
end


% Numeraci�n de los nodos
if nargin==4
   if length(nonum)>1
      for I=1:length(nonum)
         ien=nonum(I);
         text(X(ien,1),X(ien,2),int2str(ien))
      end
   else
      for I=1:size(X,1)
         text(X(I,1),X(I,2),int2str(I))
      end
   end
end
axis('equal')    
%axis('off') 
hold off 
