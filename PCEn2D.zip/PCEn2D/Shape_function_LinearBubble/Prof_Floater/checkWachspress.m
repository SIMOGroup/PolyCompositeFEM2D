function checkWachspress(v,x,phi,dphi)

disp('===================================');
disp('1. Checking for linear precision . . .');

y = phi' * v;
%disp([' x = [ ' num2str(x) ' ]' ]);
%disp([' y = [ ' num2str(y) ' ]' ]);

err = norm(y-x,2);
disp(['err = ' num2str(err) ]);

if err < 0.000001
   disp('Linearly precise');
else
   disp('Not linearly precise');
end

fprintf('\n2. Checking if the gradient is ok . . .\n');

disp(['sum of the gradients = ' num2str(sum(dphi)) ]);

dy = dphi' * v  - eye(3);
derr = sqrt(sum(sum(dy.*dy)));
disp(['derr = ' num2str(derr) ]);
disp('===================================');
