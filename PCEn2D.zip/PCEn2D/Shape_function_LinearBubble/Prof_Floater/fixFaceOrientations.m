function f2 = fixFaceOrientations(v,f)
%FIXFACEORIENTATIONS Given a convex
% polyhedron, put the vertices in each face in anticlockwise ordering
% as seen from outside, so that the face normals point outward.
%
%   Example
%   [v f] = createSoccerBall();
%   f2 = fixFaceOrientations(v,f);
%
% ------
% Author: Michael Floater
% e-mail: michaelf@ifi.uio.no
% Created: 2012-10-03,    using Matlab R2012a
% Copyright 2012 CMA

  % Compute barycentre
  Nv = size(v,1);
  bc = sum(v);
  bc = bc / Nv;
  
  % Compute face normals
  normal = faceNormal(v,f);

  f2 = f;

  Nf = length(f);
  for j = 1:Nf
      face = meshFace(f,j);
      h = dot(v(face(1),:) - bc, normal(j,:));
      if h < 0
         f2{j} = fliplr(face);
      end
  end

