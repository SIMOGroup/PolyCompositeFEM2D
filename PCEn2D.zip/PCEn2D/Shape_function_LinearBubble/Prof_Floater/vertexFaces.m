function g = vertexFaces(Nv,f)
%VERTEXFACES Given the connectivity of a
% polyhedron, with Nv vertices, defined by face indexes,
% return, for each vertex, a list of neighbouring faces
% (the "1-ring" neighbourhood), in some
% anticlockwise order around that vertex.
%
%   Example
%   [v f] = createCube();
%   Nv = size(v,1);
%   g = vertexFaces(Nv,f);
%
% ------
% Author: Michael Floater
% e-mail: michaelf@ifi.uio.no
% Created: 2012-10-02,    using Matlab R2012a
% Copyright 2012 CMA



  g1 = cell(Nv,1);
  g = cell(Nv,1);

  Nf = length(f);
  for j = 1:Nf
      face = meshFace(f,j);
      m = length(face);
      for i = 1:m
          if i<m
             vNext = face(i+1);
          else
             vNext = face(1);
          end
          if i>1
             vPrev = face(i-1);
          else
             vPrev = face(m);
          end
          g1{face(i)} = [g1{face(i)} [j; vNext; vPrev]];
      end
  end

  for i = 1:Nv
      gmat = g1{i};
      n = size(gmat,2);
      for j = 1:n-2
          for k = j+1:n
              if gmat(2,k) == gmat(3,j)
                 tmpvec = gmat(:,j+1);
                 gmat(:,j+1) = gmat(:,k);
                 gmat(:,k) = tmpvec;
                 break;
              end
          end
      end
      g{i} = gmat(1,:);
  end

