function testWachspress(p,V,C,e)

%
% 3D barycentric coordinates
% 

format long;

fprintf('Plotting element = %d\n\n',e);
plotElement(p,V,C,e);

vertices = V(C{e},:); % number of vertices X 3
nv = size(vertices,1);

faces2 = convhulln(vertices); % produces triangular facets
 
% faces is a cell array 
 
faces1 = meshReduce(vertices,faces2); % polygonal facets: see Geom3d/meshes3d

% Orientate all faces anticlockwise
faces = fixFaceOrientations(vertices,faces1);

%
% test Wachspress coordinates
%

v = vertices;
disp('v = '); disp(v)
nf = length(faces);
disp('f = '); 
for i = 1:nf
  face = meshFace(faces,i);
  disp(face);
end

disp('Functions are available in Geom3d/meshes3d to compute face normals');
disp('Need to be completed . . .');


% Compute outward unit face normals
un = faceNormal(v,faces);
for j=1:nf
un(j,:) = un(j,:) / norm(un(j,:));
end
% Assemble 1-ring neighbourhoods
g = vertexFaces(nv,faces);
disp('g = ');
for i = 1:nv
    disp(g{i});
end

disp('Computing Wachspress coordinates');
disp('of a random point inside the polyhedron . . .');

Nv = size(v,1);
weights = rand(1,Nv);
weights = weights / sum(weights);
disp('weights = ');
disp(weights);
x = weights * v;
disp('x = ');
disp(x);

[phi dphi] = wachspress3d(v,g,un,x);
disp('phi = '); disp(phi)

disp('Checking for linear precision . . .');

y = phi' * v;
disp([' x = [ ' num2str(x) ' ]' ]);
disp([' y = [ ' num2str(y) ' ]' ]);

err = norm(y-x,2);
disp([' err = ' num2str(err) ]);

if err < 0.000001
   disp('Linearly precise');
else
   disp('Not linearly precise');
end

fprintf('\n Checking if the gradient is ok . . .\n');
disp('dphi = '); disp(dphi); 
disp(['sum of the gradients = ' num2str(sum(dphi)) ]);

dy = dphi' * v  - eye(3)
derr = sqrt(sum(sum(dy.*dy)));
disp([' derr = ' num2str(derr) ]);

return
end
