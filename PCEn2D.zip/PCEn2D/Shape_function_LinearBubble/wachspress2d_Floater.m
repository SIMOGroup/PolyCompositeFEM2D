function [phi,dphi] = wachspress2d_Floater(v,x)
% Reference: GRADIENT BOUNDS FOR WACHSPRESS COORDINATES ON POLYTOPES
%            MICHAEL S. FLOATER, ANDREW GILLETTE, N. SUKUMAR
%
% Evaluate Wachspress basis functions in a convex polygon
%
% Inputs:
% v : [x1 y1; x2 y2; ...; xn yn], the n vertices of the polygon in ccw
% x : [x(1) x(2)], the point at which the basis functions are computed
% Outputs:
% phi : output basis functions = [phi_1; ...; phi_n]

n = size(v,1);
w = zeros(n,1);
% phi = zeros(n,1);
dphi = zeros(n,2);
for i = 1:n
    d = v(mod(i,n)+1,:) - v(i,:);
    normal_vector = [d(2) -d(1)]/norm(d);
    h = (v(i,:)-x) * normal_vector'; % dot product
    if h==0.0,h=1e-10;end
    p(i,:) = normal_vector / h;  % scaled normal vectors
end
for i = 1:n
    im1 = mod(i-2,n) + 1;
    w(i) = det([p(im1,:);p(i,:)]);
    R(i,:) = p(im1,:) + p(i,:);
end
wsum = sum(w);
phi = w/wsum;

phiR = phi' * R;
for k = 1:2
dphi(:,k) = phi .* (R(:,k) - phiR(:,k));
end
