% Shape functions of some elements in Finite Element Method.
%--------------------------------------------------------------------------
% Coded by:      Son Nguyen-Hoang


%                Computational Solid Mechanics Laboratory,
%                Department of Mechanical and Automotive Engineering,
%                Seoul National University of Science and Technology (SeoulTech), Seoul, Korea.


% Email:         mrnguyenhoangson@gmail.com
% 20 July 2014
%--------------------------------------------------------------------------

clc;
clear all;
close all;
addpath Prof_Floater


type='Qua';


nnel=3;
n=1;
switch type
    case 'Hexa'
        load mesh_hex
        nodesT4=[1 2 22 42 62 82 1261];
        node_of_elem=6;
        p = [cos(2*pi*((1:node_of_elem))/node_of_elem); sin(2*pi*((1:node_of_elem))/node_of_elem)]';
        coordT4=[p ;0 0];
        node_sc=[1 2 7;2 3 7;3 4 7;4 5 7;5 6 7;6 1 7];
        
        coordbound=[p zeros(node_of_elem,1);0 0 1];
        nnode_element=3;

        
    case 'Tri'
        load mesh_tri
        nodesT4=[1 332 22 2];
        node_of_elem=3;
        p = [cos(2*pi*((1:node_of_elem))/node_of_elem); sin(2*pi*((1:node_of_elem))/node_of_elem)]';
        coordT4=[p ;0 0];
        node_sc=[1 2 4;2 3 4;3 1 4];
        
        coordbound=[p zeros(node_of_elem,1);0 0 1];
        nnode_element=3;

        
    case 'Qua'
        load mesh_qua
        nodesT4=[1 22 332 642 2];
        node_of_elem=4;
        p = [cos(2*pi*((1:node_of_elem))/node_of_elem); sin(2*pi*((1:node_of_elem))/node_of_elem)]';
        coordT4=[p ;0 0];
        node_sc=[1 2 5;2 3 5;3 4 5;4 1 5];
        coordbound=[p zeros(node_of_elem,1);0 0 1];
        nnode_element=3;

end

figure(1000)
triplot(ele_node,gcoord(:,1),gcoord(:,2),'b');axis equal;hold on
    for i=1:length(gcoord)
        hhh=text(gcoord(i,1),gcoord(i,2),num2str(i));
        set(hhh,'fontsize',10,'color','r');hold on
    end


%plotMesh(ele_node,gcoord,'r');axis equal;hold on
nel=length(ele_node(:,1));             % number of elements
nnode=length(gcoord(:,1));             % total number of nodes in system
for iel=1:nel
    nod=ele_node(iel,:);
    e_gcoord = gcoord(ele_node(iel,1:nnel),:);
    xi=e_gcoord(:,1);
    eta=e_gcoord(:,2);

    Niel=[];
    dNielX=[];
    dNielY=[];
    
    for ii=1:3
        jj=1;
        while jj<=node_of_elem
            XV=coordT4(node_sc(jj,:),1);
            YV=coordT4(node_sc(jj,:),2);
            if inpolygon(xi(ii),eta(ii),XV,YV)==true
                index=jj;
                break
            end
            jj=jj+1;
        end
        v1=coordT4(1:end-1,:);
        v2=[coordT4(node_sc(index,:),1) coordT4(node_sc(index,:),2)];
        [phi1,dphi1] = wachspress2d_Floater(v1,[xi(ii) eta(ii)]);
        [phi2,dphi2] = wachspress2d_Floater_CenterNode(v1, [0, 0], [xi(ii) eta(ii)]);
        %[phi2,dphi2] = wachspress2d_Floater(v2,[xi(ii) eta(ii)]);
        Niel=[Niel;phi1' phi2(end)];
        dNielX=[dNielX;dphi1(:,1)' dphi2(end,1)];
        dNielY=[dNielY;dphi1(:,2)' dphi2(end,2)];
    end
    
    N(nod,:)=Niel(:,:);
    %dNX(nod,:)=dNielX(:,:);
    %dNY(nod,:)=dNielY(:,:);
end

for i=1:size(N,2)
    figure(i+10)
    hh(i)=trisurf(ele_node,gcoord(:,1),gcoord(:,2),N(:,i));
    shading interp;
    set(hh,'edgecolor','none');hold on
    view(3);
    
    figure(i+20)
    set(gcf,'color','w')
    contourTri(ele_node,gcoord(:,1),gcoord(:,2),N(:,i),20);hold on
    view(2);
    axis off;axis equal
    
%plot derivatives of shape function    
%     
%     figure(i+30)
%     hh(i)=trisurf(ele_node,gcoord(:,1),gcoord(:,2),dNX(:,i));
%     shading interp;
%     set(hh,'edgecolor','k');hold on
%     view(3);
%     
%     figure(i+40)
%     hh(i)=trisurf(ele_node,gcoord(:,1),gcoord(:,2),dNY(:,i));
%     shading interp;
%     set(hh,'edgecolor','k');hold on
%     view(3);




figure(100)
%     set(gcf,'color','w')
%     contourTri(NodesT3,GcoordT3(:,1),GcoordT3(:,2),N(:,6),20);hold on
%     coordbound_plot=[coordbound(1:end-1,:);coordbound(1,:)];
%     plot(coordbound_plot(:,1),coordbound_plot(:,2),'k','linewidth',2);
%     axis off;axis equal
end








