function [phi, dphi] = wachspress2d_Floater_CenterNode(v, cent, x)
% Reference: GRADIENT BOUNDS FOR WACHSPRESS COORDINATES ON POLYTOPES
%            MICHAEL S. FLOATER, ANDREW GILLETTE, N. SUKUMAR
%
% Evaluate Wachspress basis functions in a convex polygon
%
% Inputs:
% v : [x1 y1; x2 y2; ...; xn yn], the n vertices of the polygon in ccw
% x : [x(1) x(2)], the point at which the basis functions are computed
% Outputs:
% phi : output basis functions = [phi_1; ...; phi_n]

%===============================================
% Coded by: Son Nguyen-Hoang   (Seoul National University of
%                               Science and Technology - South Korea)
% Email: mrnguyenhoangson@gmail.com
%===============================================

n = size(v, 1);
w = zeros(n, 1);
% phi = zeros(n,1);
dphi = zeros(n, 2);
p = zeros(n, 2);
R = zeros(n, 2);

for i = 1:n
    d = v(mod(i, n) + 1, :) - v(i, :);
    normal_vector = [d(2), -d(1)] / norm(d);
    h = (v(i, :) - x) * normal_vector'; % dot product
    if h == 0, h = eps; end
    p(i, :) = normal_vector / h; % scaled normal vectors
end

for i = 1:n
    im1 = mod(i - 2, n) + 1;
    w(i) = det([p(im1, :); p(i, :)]);
    R(i, :) = p(im1, :) + p(i, :);
end

wsum = sum(w);
phi = w / wsum;
% Gradient
phiR = phi' * R;

for k = 1:2
    dphi(:, k) = phi .* (R(:, k) - phiR(:, k));
end

%==================================================
%  Bubble function
%==================================================
L = (norm(x - cent))^2;
phiBubble = (1 / wsum) / (L + 1 / wsum);
% phiBubble = 1 / (1 + L*wsum);
phi = [phi; phiBubble];
%Gradient
wR = w' * R;
dL = [2 * (x(1) - cent(1)), 2 * (x(2) - cent(2))];

for k = 1:2
    dphi_Bubble(1, k) = -(L * wR(k) + dL(k) * wsum) / ((L * wsum + 1)^2);
end

% -(L * wR + dL * wsum) / ((L * wsum + 1)^2);

dphi = [dphi; dphi_Bubble];
end
