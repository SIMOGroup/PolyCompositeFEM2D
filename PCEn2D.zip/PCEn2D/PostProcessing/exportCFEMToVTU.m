function exportCFEMToVTU(AdaptiveMesh, d, filename)

% written by Khanh Chau-Nguyen

% d = AdaptiveMesh.ETA_Nodes;
NumNodes = size(AdaptiveMesh.Nodes, 1); % number of nodes
NumCells = numel(AdaptiveMesh.Elements); % number of elements
x = zeros(NumNodes, 3);
x(:, 1 : 2) = AdaptiveMesh.Nodes; % node coordinates
nface = NumCells; % number of faces
faces = AdaptiveMesh.Elements; % face connectivities

% Output files

outfileVTU  = strcat(filename, '.vtu');
fid = fopen(outfileVTU, 'wt');

%  VTK_EMPTY_CELL = 0, VTK_VERTEX = 1, VTK_POLY_VERTEX = 2, VTK_LINE = 3, 
%   VTK_POLY_LINE = 4, VTK_TRIANGLE = 5, VTK_TRIANGLE_STRIP = 6, VTK_POLYGON = 7, 
%   VTK_PIXEL = 8, VTK_QUAD = 9, VTK_TETRA = 10, VTK_VOXEL = 11, 
%   VTK_HEXAHEDRON = 12, VTK_WEDGE = 13, VTK_PYRAMID = 14, VTK_PENTAGONAL_PRISM = 15, 
%   VTK_HEXAGONAL_PRISM = 16, VTK_QUADRATIC_EDGE = 21, VTK_QUADRATIC_TRIANGLE = 22, VTK_QUADRATIC_QUAD = 23, 
%   VTK_QUADRATIC_POLYGON = 36, VTK_QUADRATIC_TETRA = 24, VTK_QUADRATIC_HEXAHEDRON = 25, VTK_QUADRATIC_WEDGE = 26, 
%   VTK_QUADRATIC_PYRAMID = 27, VTK_BIQUADRATIC_QUAD = 28, VTK_TRIQUADRATIC_HEXAHEDRON = 29, VTK_QUADRATIC_LINEAR_QUAD = 30, 
%   VTK_QUADRATIC_LINEAR_WEDGE = 31, VTK_BIQUADRATIC_QUADRATIC_WEDGE = 32, VTK_BIQUADRATIC_QUADRATIC_HEXAHEDRON = 33, VTK_BIQUADRATIC_TRIANGLE = 34, 
%   VTK_CUBIC_LINE = 35, VTK_CONVEX_POINT_SET = 41, VTK_POLYHEDRON = 42, VTK_PARAMETRIC_CURVE = 51, 
%   VTK_PARAMETRIC_SURFACE = 52, VTK_PARAMETRIC_TRI_SURFACE = 53, VTK_PARAMETRIC_QUAD_SURFACE = 54, VTK_PARAMETRIC_TETRA_REGION = 55, 
%   VTK_PARAMETRIC_HEX_REGION = 56, VTK_HIGHER_ORDER_EDGE = 60, VTK_HIGHER_ORDER_TRIANGLE = 61, VTK_HIGHER_ORDER_QUAD = 62, 
%   VTK_HIGHER_ORDER_POLYGON = 63, VTK_HIGHER_ORDER_TETRAHEDRON = 64, VTK_HIGHER_ORDER_WEDGE = 65, VTK_HIGHER_ORDER_PYRAMID = 66, 
%   VTK_HIGHER_ORDER_HEXAHEDRON = 67, VTK_NUMBER_OF_CELL_TYPES 

% VTKCellCode = 3; % VTK_LINE
% VTK_POLYHEDRON = 42
VTKCellCode = 7; % VTK_POLYGON
% VTKCellCode = 9; % VTK_QUAD

% Write headers
fprintf(fid, '<VTKFile type="UnstructuredGrid"  version="0.1"   > \n');
fprintf(fid, '<UnstructuredGrid> \n');
fprintf(fid, '<Piece  NumberOfPoints="  %g" NumberOfCells=" %g"> \n', NumNodes, NumCells);

% Write point data
fprintf(fid, '<Points> \n');

fprintf(fid, '<DataArray  type="Float64"  NumberOfComponents="3"  format="ascii" > \n');
fprintf(fid, '%g ', reshape(x', [], 1));

fprintf(fid, '</DataArray> \n');
fprintf(fid, '</Points> \n');

% Print cells
fprintf(fid, '<Cells> \n');

% Print cell connectivity
fprintf( fid, '<DataArray  type="Int32"  Name="connectivity"  format="ascii"> \n');
for i = 1 : nface
    fprintf( fid, '%g ', faces{i} - 1 );
end
fprintf( fid, '</DataArray> \n' );

% Print cell offsets

fprintf(fid, '<DataArray  type="Int32"  Name="offsets"  format="ascii"> \n');
offset = 0;
for i = 1 : nface
    offset = offset + length(faces{i});
    fprintf(fid, '%d ', offset);
end
fprintf(fid, horzcat('\n', '</DataArray> \n'));

% Print cell types
fprintf(fid, '<DataArray  type="UInt8"  Name="types"  format="ascii"> \n');
fprintf(fid, '%g ', VTKCellCode * ones(1, NumCells));
fprintf(fid, horzcat('\n', '</DataArray> \n'));
fprintf(fid, '</Cells> \n');

% print temperature field

fprintf( fid, '<PointData> \n' );
fprintf( fid, '<DataArray  type="Float64"  Name="Pressure" NumberOfComponents="1" format="ascii"> \n' );
fprintf( fid, '%g \n', d(1 : NumNodes) );
fprintf( fid, horzcat('\n', '</DataArray> \n') );
fprintf(fid, '</PointData> \n');

% end of VTK file

fprintf(fid, '</Piece> \n');
fprintf(fid, '</UnstructuredGrid> \n');
fprintf(fid, '</VTKFile> \n');

fclose(fid);
disp(['Output written to ', filename, '.vtu'])
end
