function contmoy=contmoy2dq(nodpost,nnodpost,elempost,nelempost,sigsom1,nnel)

if nnel==3 
sigsom=[mean(sigsom1(:,:,:),2) mean(sigsom1(:,:,:),2) mean(sigsom1(:,:,:),2)];
else
    sigsom=[mean(sigsom1(:,:,:),2) mean(sigsom1(:,:,:),2) mean(sigsom1(:,:,:),2) mean(sigsom1(:,:,:),2)];
end;
    contmoy=zeros(1,nnodpost);
compt=zeros(nnodpost,1);
for i=1:nelempost
    for j=1:nnel
        sigVM=sqrt((sigsom(1,j,i)+sigsom(2,j,i))^2-3*(sigsom(1,j,i)*sigsom(2,j,i)-sigsom(3,j,i)^2));
        contmoy(elempost(i,j))=contmoy(elempost(i,j))+sigVM;
        compt(elempost(i,j))=compt(elempost(i,j))+1;
    end;
end;
for i=1:nnodpost
    contmoy(i)=contmoy(i)/compt(i);
end;
