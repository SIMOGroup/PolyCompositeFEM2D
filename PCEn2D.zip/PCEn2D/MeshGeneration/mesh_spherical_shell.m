function [node,element] = mesh_spherical_shell(nume,numr,R,t,phi)
syms delta_phi;
if nume>1
    delta_phi=phi/(nume-1);
else
    disp(['Wrong number of nume. Number of numr and nume must greater than one.'])
    node=[];
    element=[];
    return
end
for i=1:numr
    for j=1:nume
        if numr>1
            node(j+nume*(i-1),1)=(R+t/(numr-1)*(i-1))*cos(pi/2-phi+delta_phi*(j-1));
            node(j+nume*(i-1),2)=(R+t/(numr-1)*(i-1))*sin(pi/2-phi+delta_phi*(j-1));
        else     
           disp(['Wrong number of numr. Number of numr and nume must greater than one.'])
           node=[];
           element=[];
           return
        end
    end 
end
element=[];
for i=1:(numr-1)
    for j=1:(nume-1)        
        element=[element;j+nume*(i-1) j+nume*i j+nume*i+1 j+nume*(i-1)+1;];
    end
end
