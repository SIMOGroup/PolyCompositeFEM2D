
function gcoord = singularmesh_beam(lengthx, lengthy, lx,ly, air)

% lengthx:           length of x-axis side of problem
% lengthy:           length of y-axis side of problem
% lx     :           number of element in x-axis
% ly     :           number of element in y-axis
% air    :           singularity scale coefficient   
%--------------------------------------------
%input data for nodal coordinate values
%gcoord(i,j) where i->node no.  and j->x or y
%--------------------------------------------

dx=lengthx/lx;          % the length of side of element in x-axis
dy=lengthy/ly;          % the length of side of element in y-axis

gcoord=[];

for i=1:lx+1
    for j=ly/2:-1:1
        gcoord=[gcoord; (i-1)*dx -j*dy;]; 
    end
    for j=1:ly/2+1
        gcoord=[gcoord; (i-1)*dx (j-1)*dy;]; 
    end
end

nn=0;
for ip=1:lx+1                % sampling node coordiantes for discretisation
    for iq=1:ly+1 
        nn=nn+1;     
        r=0.03;
        %r=random('beta',1,1);        % r=[0 1];
        r=air*(2*r-1);               % project r=[-air air];

        if ip==1 | ip==lx+1 | iq==1 | iq==ly+1 %| (iq-1)*bb==5 %|(ip-1)*aa==L/2
            r=0;
        end
        gcoord(nn,1)=gcoord(nn,1)+dx*r;
        gcoord(nn,2)=gcoord(nn,2)+dy*r;  
    end
end

clear nn;