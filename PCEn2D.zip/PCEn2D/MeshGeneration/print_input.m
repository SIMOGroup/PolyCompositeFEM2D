function print_input(outfile,node,element,ndof)
%      Print coord, elemental connections
numnode=size(node,1);
numelem=size(element,1);

fprintf(outfile,'# vtk DataFile Version 2.0\n');
fprintf(outfile,'Cookmembrane\n');
fprintf(outfile,'ASCII\n\n');
fprintf(outfile,'DATASET UNSTRUCTURED_GRID\n');

fprintf(outfile,'POINTS'); fprintf(outfile,'%6d',numnode); fprintf(outfile,' double \n'); 

if (ndof == 2) 
     %fprintf(outfile,' Node      Coords         u1       u2 \n');
     for i = 1:numnode
      fprintf(outfile,'%12.4f %12.4f %12.4f \n',node(i,1),node(i,2),0.0);
     end
 elseif (ndof == 3) 
     %fprintf(outfile,' Node            Coords            u1       u2       u3 \n');
     for i = 1:nnode
      fprintf(outfile,'%12.4f %12.4f %12.4f\n',node(i,1),node(i,2),node(i,3));
     end
end
fprintf(outfile,'\n');
fprintf(outfile,'CELLS'); fprintf(outfile,'%6d',numelem); fprintf(outfile,'%6d\n',4*numelem);
   
%
%   Loop over all the elements
%
if (size(element,2) == 3) 
   for iel = 1:numelem
      fprintf(outfile,'%6d %6d %6d %6d \n',3,element(iel,1)-1,element(iel,2)-1,element(iel,3)-1);
   end
     
elseif (size(element,2) == 4) 
  for iel = 1:numelem
      fprintf(outfile,'%6d %6d %6d %6d %6d \n',3,element(iel,1),element(iel,2),element(iel,3),element(iel,3));
  end
end

fprintf(outfile,'\n');
fprintf(outfile,'CELL_TYPES'); fprintf(outfile,'%6d \n',numelem);

if (size(element,2) == 3) 
   for iel = 1:numelem
      fprintf(outfile,'%3d',5);
   end
     
elseif (size(element,2) == 4) 
  for iel = 1:numelem
      fprintf(outfile,'%3d',5);
  end
end
