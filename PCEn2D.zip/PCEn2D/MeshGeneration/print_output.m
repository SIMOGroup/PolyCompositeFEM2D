function print_output(outfile,node,sigVM)
%      Print coord, elemental connections
numnode=size(node,1);

fprintf(outfile,'\n');
fprintf(outfile,'SCALARS  Pho  double'); fprintf(outfile,'%3d \n',1); 
fprintf(outfile,'LOOKUP_TABLE  default \n');  
for i = 1:numnode
      fprintf(outfile,'%8.4f \n',sigVM(i));
end
