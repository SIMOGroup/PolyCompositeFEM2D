function [element, node, nnx, nny] = meshBeam(elemType, numx, numy, L, c)

switch elemType
    case 'Q4'
        nnx = numx + 1;
        nny = numy + 1;
        node = square_node_array([0, -c], [L, -c], [L, c], [0, c], nnx, nny);
        
        inc_u = 1;
        inc_v = nnx;
        node_pattern = [1 2 nnx + 2 nnx + 1];
        
        element = make_elem(node_pattern, numx, numy, inc_u, inc_v);
        
    case 'CQ4'
        nnx = numx + 1;
        nny = numy + 1;
        node = square_node_array([0, -c], [L, -c], [L, c], [0, c], nnx, nny);
        
        inc_u = 1;
        inc_v = nnx;
        node_pattern = [1 2 nnx + 2 nnx + 1];
        
        element = make_elem(node_pattern, numx, numy, inc_u, inc_v);
        
        %    nel=size(elementQ4,1);
        %    nnode=size(node,1);
        %    element=[];
        %    for ie=1:nel
        %        element=[element; elementQ4(ie,1) elementQ4(ie,2) nnode+ie];
        %        element=[element; elementQ4(ie,2) elementQ4(ie,3) nnode+ie];
        %        element=[element; elementQ4(ie,3) elementT3(ie,4) nnode+ie];
        %        element=[element; elementQ4(ie,4) elementT3(ie,1) nnode+ie];
        %    end
        
    case 'Qm6'
        nnx = numx + 1;
        nny = numy + 1;
        node = square_node_array([0 - c], [L - c], [L c], [0 c], nnx, nny);
        
        inc_u = 1;
        inc_v = nnx;
        node_pattern = [1 2 nnx + 2 nnx + 1];
        
        element = make_elem(node_pattern, numx, numy, inc_u, inc_v);
        
    case 'Q8'
        nnx = 2 * numx + 1;
        nny = 2 * numy + 1;
        
        for j = 1:numy + 1
            
            for i = 1:numx + 1
                node((3 * numx + 2) * (j - 1) + (2 * i - 1), 1) = (pt3(1) / numx) * (i - 1);
                node((3 * numx + 2) * (j - 1) + (2 * i - 1), 2) = -D / 2 + (pt3(2) / numy) * (j - 1);
            end
            
        end
        
        index = 1;
        
        for i = 1:numy
            
            for k = 1:numx
                element(index, 1) = (3 * numx + 2) * (i - 1) + (2 * k - 1);
                element(index, 2) = (3 * numx + 2) * (i - 1) + (2 * k + 1);
                element(index, 3) = (3 * numx + 2) * i + (2 * k + 1);
                element(index, 4) = (3 * numx + 2) * i + (2 * k - 1);
                element(index, 5) = (element(index, 2) + element(index, 1)) / 2;
                element(index, 6) = (3 * numx + 2) * i - numx + k;
                element(index, 7) = (element(index, 3) + element(index, 4)) / 2;
                element(index, 8) = (3 * numx + 2) * i - (numx + 1) + k;
                index = index + 1;
            end
            
        end
        
        for i = 1:size(element, 1)
            node(element(i, 5), :) = (node(element(i, 1), :) + node(element(i, 2), :)) / 2;
            node(element(i, 6), :) = (node(element(i, 2), :) + node(element(i, 3), :)) / 2;
            node(element(i, 7), :) = (node(element(i, 3), :) + node(element(i, 4), :)) / 2;
            node(element(i, 8), :) = (node(element(i, 4), :) + node(element(i, 1), :)) / 2;
        end
        
    case 'Q9'
        nnx = 2 * numx + 1;
        nny = 2 * numy + 1;
        node = square_node_array([0 - c], [L - c], [L c], [0 c], nnx, nny);
        
        inc_u = 2;
        inc_v = 2 * nnx;
        node_pattern = [1 3 2 * nnx + 3 2 * nnx + 1 2 nnx + 3 2 * nnx + 2 nnx + 1 nnx + 2];
        
        element = make_elem(node_pattern, numx, numy, inc_u, inc_v);
    case 'T6'
        nnx = 2 * numx + 1;
        nny = 2 * numy + 1;
        node = square_node_array([0 - c], [L - c], [L c], [0 c], nnx, nny);
        
        inc_u = 2;
        inc_v = 2 * nnx;
        node_pattern1 = [1 3 2 * nnx + 1 2 nnx + 2 nnx + 1];
        node_pattern2 = [3 2 * nnx + 3 2 * nnx + 1 nnx + 3 2 * nnx + 2 nnx + 2];
        element = [make_elem(node_pattern1, numx, numy, inc_u, inc_v);
            make_elem(node_pattern2, numx, numy, inc_u, inc_v)];
    case 'CT3'
        nnx = numx + 1;
        nny = numy + 1;
        node = square_node_array([0 - c], [L - c], [L c], [0 c], nnx, nny);
        
        node_pattern1 = [1 2 nnx + 1];
        node_pattern2 = [2 nnx + 2 nnx + 1];
        inc_u = 1;
        inc_v = nnx;
        
        element = [make_elem(node_pattern1, numx, numy, inc_u, inc_v);
            make_elem(node_pattern2, numx, numy, inc_u, inc_v)];
        %    nel=size(elementT3,1);
        %    nnode=size(node,1);
        %    element=[];
        %    for ie=1:nel
        %        element=[element; elementT3(ie,1) elementT3(ie,2) nnode+ie];
        %        element=[element; elementT3(ie,2) elementT3(ie,3) nnode+ie];
        %        element=[element; elementT3(ie,3) elementT3(ie,1) nnode+ie];
        %    end
    case 'Poly'
        iter = 6;
        nnx = numx;
        nny = numy;
        % Nelem = 800;
        % [node, element] = PolyMesher(@CantileverBeam, Nelem, 3000); axis on
        % save(strcat('MeshBeamNEW', num2str(Nelem)), 'node', 'element');
        
        if iter == 1
            load('MeshBeam100', 'node', 'element')
        elseif iter == 2
            load('MeshBeam200', 'node', 'element')
        elseif iter == 3
            load('MeshBeam400', 'node', 'element')
        elseif iter == 4
            load('MeshBeam800', 'node', 'element')
        elseif iter == 5
            load('MeshBeam1600', 'node', 'element')
        elseif iter == 6
            load('MeshBeam3200', 'node', 'element')
        end
        
%         if iter==1
%             load Mesh_MBB_1
%         elseif iter==2
%             load Mesh_MBB_2
%         elseif iter==3
%             load Mesh_MBB_3
%         elseif iter==4
%             load Mesh_MBB_4
%         end
%         node=gcoord;
%         element=ele_nods;
%         clear gcoord ele_nods
        
    otherwise %'T3'
        nnx = numx + 1;
        nny = numy + 1;
        node = square_node_array([0 - c], [L - c], [L c], [0 c], nnx, nny);
        
        node_pattern1 = [1 2 nnx + 1];
        node_pattern2 = [2 nnx + 2 nnx + 1];
        inc_u = 1;
        inc_v = nnx;
        
        element = [make_elem(node_pattern1, numx, numy, inc_u, inc_v);
            make_elem(node_pattern2, numx, numy, inc_u, inc_v)];
end

end
