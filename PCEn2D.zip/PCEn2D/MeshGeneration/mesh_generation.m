function mesh_generation

% A set of matlab function that perform standard operations commonly used
% in generationg finite element meshes.
%
% arcmesh.m	  linemesh.m		mapmesh2D.m	        splitElement.m
% arrow.m	  make_cross_mesh.m	mesh_generation.m   square_node_array.m
% contura.m	  make_elem.m		mirrormesh.m	    t3tot6.m
% getSubElements.m              make_hex_sheet.m	msh2mlab.m	    
% holeinplate.m	                make_triangle_mesh.m	
% plot_mesh.m	                tricheck.m
% holeplatemesh.m               mapmesh2Db.m		remove_free_nodes.m
