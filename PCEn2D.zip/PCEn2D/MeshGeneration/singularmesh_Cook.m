
function node = singularmesh_Cook(L1,L2,L3,numx,numy,air)
   
   for i=1:numx+1
    for j=1:numy+1
        h=L2-(j-1)*(L2-L3)/numy;
        node((numx+1)*(j-1)+i,1)=(i-1)*L1/numx;
        node((numx+1)*(j-1)+i,2)=(i-1)*L1*(h/L1)/numx+(j-1)*L2/numy;
    end
   end
dx=L1/numx;

nn=0;
for ip=1:numx+1                % sampling node coordiantes for discretisation
    for iq=1:numy+1 
        h=L2-(iq-1)*(L2-L3)/numy;
        nn=nn+1;     
        r=random('beta',1,1);        % r=[0 1];
        r=air*(2*r-1);               % project r=[-air air];

        if ip==1 | ip==numx+1 | iq==1 | iq==numy+1 
            r=0;
        end
%         if ip==1 | iq==numx/2+1| ip==numx+1 | iq==1 | iq==numy+1 
%             r=0;
%         end
        node(nn,1)=node(nn,1)+dx*r;
        node(nn,2)=node(nn,2)+r*(L2-L3)/numy;%((ip-1)*L1*(h/L1)/numx+(iq-1)*L2/numy);
    end
end

