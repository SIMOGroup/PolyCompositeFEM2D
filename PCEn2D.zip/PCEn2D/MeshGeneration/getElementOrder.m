function [order,quadShape,dim]=getElementOrder(elemType)

% function order=getElementOrder(elemType)
% Returns the order of the element interpolant
%
% [order,quadShape,dim]=getElementOrder(elemType)
% Returns the order of the element interpolant and the quadrature
% shape (ie. GAUSS TRIANGULAR) and the dimension.

switch elemType
  
case 'L2'
  order = 1;
  quadShape='GAUSS';
  dim=1;
  
case 'L3'
  order = 2;
  quadShape='GAUSS';
  dim=1;
  
case 'T3'
  order = 1;
  quadShape='TRIANGULAR';
  dim=2;
  
case 'T4'
  order = 3;
  quadShape='TRIANGULAR';
  dim=2;
  
case 'T6'
  order = 2;
  quadShape='TRIANGULAR';
  dim=2;
  
case 'Q4'
  order = 2;
  quadShape='GAUSS';
  dim=2;
  
case 'Q9'
  order = 3;
  quadShape='GAUSS';
  dim=2;
  
case 'H3'
  order = 1;
  quadShape='TRIANGULAR';
  dim=3;
  
case 'H10'
  order = 2;
  quadShape='TRIANGULAR';
  dim=3;
  
case 'B8'
  order = 2;
  quadShape='GAUSS';
  dim=3;
  
case 'B27'
  order = 3;
  quadShape='GAUSS';
  dim=3;
  
otherwise
  disp(['ERROR IN getElementOrder ELEMENT TYPE ',elemType,' NOT DEFINED'])
end
  