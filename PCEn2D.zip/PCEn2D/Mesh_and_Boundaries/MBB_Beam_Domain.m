function FEM=MBB_Beam_Domain(FEM,iter)
%--------------------------------------------------------------------------
FEM.FactorInitial.Domain.lx=48;
FEM.FactorInitial.Domain.ly=12;
lengthx=FEM.FactorInitial.Domain.lx;
lengthy=FEM.FactorInitial.Domain.ly;
xmin=0;ymin=-lengthy/2;xmax=lengthx;ymax=lengthy/2;
box=[xmin,xmax;ymin,ymax];
%--------------------------------------------------------------------------
if FEM.TypeElement.Type==2

    if iter==1
        load Mesh_MBB_1 
    elseif iter==2
        load Mesh_MBB_2 
    elseif iter==3
        load Mesh_MBB_3 
    elseif iter==4
        load Mesh_MBB_4 
    end
    FEM.Mesh.Nodes=gcoord;
    FEM.Mesh.Elements=ele_nods;
    clear gcoord ele_nods
    
    figure(1)
    set(gcf,'color','w');
    Plot_PolyMesh(FEM.Mesh.Nodes,FEM.Mesh.Elements,0);hold on;axis on
    %plot(FEM.Mesh.Nodes(:,1),FEM.Mesh.Nodes(:,2),'bo','MarkerFaceColor','b');

else
    
    n=4*iter;
    nx=4*n;ny=n;
    
    [FEM.Mesh.Nodes,FEM.Mesh.Elements]=rectangleMesh(FEM.TypeElement.Type,FEM.TypeElement.NumNodeElem,xmin,xmax,ymin,ymax,nx,ny);
    
    for i=1:size(FEM.Mesh.Elements,1)
        Temp{i}=FEM.Mesh.Elements(i,:);
    end
    FEM.Mesh.Elements=Temp;clear Temp;
    figure(1)
    set(gcf,'color','w');
    Plot_PolyMesh(FEM.Mesh.Nodes,FEM.Mesh.Elements,0);hold on;axis off
    %plot(FEM.Mesh.Nodes(:,1),FEM.Mesh.Nodes(:,2),'bo','MarkerFaceColor','b');
end
