function FEM=Making_boundary(FEM)
%==========================================================================
tol=1e-3;
FEM.BC.BCDof=[];
FEM.BC.BCValue=[];

if FEM.Example == 1 
    %----------------------
    RigthBC = find(FEM.Mesh.Nodes(:,1) > 48-tol & FEM.Mesh.Nodes(:,1) < 48+tol);
    for i=1:length(RigthBC)-1
        for j=i+1:length(RigthBC)
            if FEM.Mesh.Nodes(RigthBC(i),2)>FEM.Mesh.Nodes(RigthBC(j),2)
                temp=RigthBC(i);
                RigthBC(i)=RigthBC(j);
                RigthBC(j)=temp;
            end
        end
    end
    FEM.BC.NeumannBC=[RigthBC(1:end-1),RigthBC(2:end)]; 
    
    FEM.BC.DirichletBC = find(FEM.Mesh.Nodes(:,1) > 0-tol & FEM.Mesh.Nodes(:,1) < 0+tol);
    for i=1:size(FEM.BC.DirichletBC)
        FEM.BC.BCDof=[FEM.BC.BCDof (FEM.BC.DirichletBC(i)*2-1) (FEM.BC.DirichletBC(i)*2)];
        FEM.BC.BCValue=[FEM.BC.BCValue 0 0];
    end
%------------------------
elseif FEM.Example == 2
     RigthBC = find(FEM.Mesh.Nodes(:,1) > FEM.FactorInitial.Domain.lx-tol &...
        FEM.Mesh.Nodes(:,1) < FEM.FactorInitial.Domain.lx+tol);
    for i=1:length(RigthBC)-1
        for j=i+1:length(RigthBC)
            if FEM.Mesh.Nodes(RigthBC(i),2)>FEM.Mesh.Nodes(RigthBC(j),2)
                temp=RigthBC(i);
                RigthBC(i)=RigthBC(j);
                RigthBC(j)=temp;
            end
        end
    end
    FEM.BC.NeumannBC=[RigthBC(1:end-1),RigthBC(2:end)];
    
    FEM.BC.DirichletBC = find(FEM.Mesh.Nodes(:,1) > 0-tol & FEM.Mesh.Nodes(:,1) < 0+tol);
    for i=1:size(FEM.BC.DirichletBC)
        FEM.BC.BCDof=[FEM.BC.BCDof (FEM.BC.DirichletBC(i)*2-1) (FEM.BC.DirichletBC(i)*2)];
        FEM.BC.BCValue=[FEM.BC.BCValue 0 0];
    end   
   
end



