function Plot_PolyMesh(Node,Element, flag)

axis equal
NElem=length(Element);

if isnumeric(Element)
    for iel=1:NElem
        Element1{iel} = Element(iel,:);
    end
    Element=Element1;
end

hold on
for el = 1:NElem
    connect = Element{el};
    
    xpt = Node([connect, connect(1)], 1);
    ypt = Node([connect, connect(1)], 2);
    
    plot(xpt, ypt, 'b-');
end

% Element = Element(1:NElem)';                 %Only plot the first block
% MaxNVer = max(cellfun(@numel,Element));      %Max. num. of vertices in mesh
% PadWNaN = @(E) [E NaN(1,MaxNVer-numel(E))];  %Pad cells with NaN
% ElemMat = cellfun(PadWNaN,Element,'UniformOutput',false);
% ElemMat = vertcat(ElemMat{:});               %Create padded element matrix
% patch('Faces',ElemMat,'Vertices',Node,'FaceColor','none', 'EdgeColor', 'blue', 'LineWidth', 0.75);
% pause(1e-6)
if flag==1
    % Plot node numbers
    for i=1:length(Node)
        h1=text(Node(i,1),Node(i,2),num2str(i));
        set(h1,'fontsize',12,'color','k');hold on
    end
    % Plot element numbers
    for e=1:length(Element)
        xc = mean(Node(Element{e},:));
        h2=text(xc(1),xc(2), sprintf('%d',e));
        set(h2,'fontsize',12,'color','r');hold on
    end
end





%-------------------------------------------------------------------------%