function [FEM]=Making_Mesh(FEM,iter)
%=============================  Mesh ======================================
if FEM.Example==1 
    FEM=Cook_Domain(FEM,iter);
elseif FEM.Example==2
    FEM=MBB_Beam_Domain(FEM,iter);


end

%==========================================================================
% Input data for nodal connectivity for each element                      %
%==========================================================================
FEM.Mesh.Connect.Dof=2;
if isnumeric(FEM.Mesh.Elements)
    FEM.Mesh.Connect.NumElem=size(FEM.Mesh.Elements,1);  % number of elements
    FEM.Mesh.Connect.NumNode=size(FEM.Mesh.Nodes,1); % total number of nodes in system
    FEM.Mesh.Connect.SysDof=FEM.Mesh.Connect.NumNode*FEM.Mesh.Connect.Dof; % total system dofs
else
    FEM.Mesh.Connect.NumElem=length(FEM.Mesh.Elements);  % number of elements
    FEM.Mesh.Connect.NumNode=length(FEM.Mesh.Nodes); % total number of nodes in system
    FEM.Mesh.Connect.SysDof=FEM.Mesh.Connect.NumNode*FEM.Mesh.Connect.Dof; % total system dofs
end
%==========================================================================




