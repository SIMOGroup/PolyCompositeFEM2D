clear
clc
close all
format long
state = 0;
global node element thickness;
% ******************************************************************************
% ***                             I N P U T                                  ***
% ******************************************************************************
tic;
disp('************************************************')
disp('***          S T A R T I N G    R U N        ***')
disp('************************************************')

disp([num2str(toc), '   START'])

% MATERIAL PROPERTIES
E0 = 1; % Young's modulus
% E0 = 240.565;
% nu0 = 0.3; % Poisson's ratio
nu0 = 0.4999999;

% BEAM PROPERTIES
L1 = 48; %m
L2 = 44; %m
L3 = 16;
thickness = 1;

% MESH PROPERTIES
elemType = 'Poly';
% elemType = 'CQ4';

MethodLAB = 'PCEn';
% MethodLAB = 'Classic';

basisLAB = 'T3';
% basisLAB = 'Wachspress';
% basisLAB = 'CorrectedWachspress';

cenDOF = 'yes';

numx = 8*3; % and in the x-direciton.
numy = 8*3; % the number of elements in the y-direction (beam length)

plotMesh = 1; % A flag that if set to 1 plots the initial mesh (to make sure
% that the mesh is correct)
% TIP LOAD
P = 1 / L3; % the peak magnitude of the traction at the right edge
% P = 100 / L3;

% STRESS ASSUMPTION
% stressState = 'PLANE_STRESS'; % set to either 'PLANE_STRAIN' or "PLANE_STRESS'
stressState = 'PLANE_STRAIN';
warning(['Running under ', stressState, ' condition with ', 'nu = ', num2str(nu0, 16), ' and ', MethodLAB, ' approach with ', basisLAB, ' basis functions.'])

% ******************************************************************************
% ***                    P R E - P R O C E S S I N G                         ***
% ******************************************************************************

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% COMPUTE ELASTICITY MATRIX
[Dm, gamma] = Dmaterial(E0, nu0, stressState);

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
disp([num2str(toc), '   GENERATING MESH'])

switch elemType
    case 'Poly'
        % Nelem = 2048;
        % [node, element] = PolyMesher(@CookDomain, Nelem, 1000);
        % axis on
        % hold on
        % save(strcat('MeshCooksMembrane', num2str(Nelem)), 'node', 'element');
        im = 5;
        if im == 1
            load('MeshCooksMembrane128', 'node', 'element')
        elseif im == 2
            load('MeshCooksMembrane256', 'node', 'element')
        elseif im == 3
            load('MeshCooksMembrane512', 'node', 'element')
        elseif im == 4
            load('MeshCooksMembrane1024', 'node', 'element')
        elseif im == 5
            load('MeshCooksMembrane2048', 'node', 'element')
        else
            error("Not implemented yet!")
        end
        AdaptiveMesh.Nodes = node;
        AdaptiveMesh.Elements = element;
    case 'CQ4'% here we generate the mesh of Q4 elements
        nnx = numx + 1;
        nny = numy + 1;
        
        for i = 1:numx + 1
            
            for j = 1:numy + 1
                h = L2 - (j - 1) * (L2 - L3) / numy;
                node((numx + 1) * (j - 1) + i, 1) = (i - 1) * L1 / numx;
                node((numx + 1) * (j - 1) + i, 2) = (i - 1) * L1 * (h / L1) / numx + (j - 1) * L2 / numy;
            end
            
        end
        
        inc_u = 1;
        inc_v = nnx;
        node_pattern = [1, 2, nnx + 2, nnx + 1];
        
        element = make_elem(node_pattern, numx, numy, inc_u, inc_v);
        
        AdaptiveMesh.Nodes = node;
        element = mat2cell(element, ones(size(element, 1), 1));
        AdaptiveMesh.Elements = element;
end
edgeElemType = 'L2';

numnode = size(node, 1); % number of nodes
numelem = numel(element); % number of elements
ndof = 2;

if plotMesh% if plotMesh==1 we will plot the mesh
    clf
    Plot_PolyMesh(node, element, 0);
    hold on;
end
% matlab2tikz('CookMembraneMesh5.tex', 'width', '\figurewidth','showInfo', false)
% ---------------------------------------------------------------------
RightBC = find(AdaptiveMesh.Nodes(:, 1) > L1 - 1e-3 & AdaptiveMesh.Nodes(:, 1) < L1 + 1e-3);

for i = 1:length(RightBC) - 1
    for j = i + 1:length(RightBC)
        if AdaptiveMesh.Nodes(RightBC(i), 2) > AdaptiveMesh.Nodes(RightBC(j), 2)
            tmp = RightBC(i);
            RightBC(i) = RightBC(j);
            RightBC(j) = tmp;
        end
    end
end

RightEdge = [RightBC(1:end - 1), RightBC(2:end)];
LeftBC = find(AdaptiveMesh.Nodes(:, 1) > 0 - 1e-3 & AdaptiveMesh.Nodes(:, 1) < 0 + 1e-3);

for i = 1:length(LeftBC) - 1
    for j = i + 1:length(LeftBC)
        if AdaptiveMesh.Nodes(LeftBC(i), 2) > AdaptiveMesh.Nodes(LeftBC(j), 2)
            tmp = LeftBC(i);
            LeftBC(i) = LeftBC(j);
            LeftBC(j) = tmp;
        end 
    end
end

% LEFT EDGE ENFORCE BOUNDARY CONDITION

bcdof = [LeftBC * 2 - 1; LeftBC * 2];
bcval = zeros(size(bcdof));

% ---------------------------------------------------------------------

disp([num2str(toc), '   INITIALIZING DATA STRUCTURES'])
F = zeros(2 * (numnode + numelem) + numnode, 1); % external load vector

% ******************************************************************************
% ***                          P R O C E S S I N G                           ***
% ******************************************************************************

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% COMPUTE EXTERNAL FORCES
%   integrate the tractions on the left and right edges
disp([num2str(toc), '   COMPUTING EXTERNAL LOADS'])

[W, Q] = quadrature(2, 'GAUSS', 1);
for e = 1:size(RightEdge, 1)% loop over the elements in the right edge
    sctr = RightEdge(e, :); % scatter vector for the element
    sctry = 2 .* sctr;
    for q = 1:size(W, 1)% quadrature loop
        pt = Q(q, :); % quadrature point
        wt = W(q); % quadrature weight
        [N, dNdxi] = lagrange_basis(edgeElemType, pt); % element shape functions
        J0 = dNdxi' * node(sctr, :); % element Jacobian
        detJ0 = norm(J0); % determiniat of jacobian
        
        fyPt = P; % y traction at quadrature point
        F(sctry) = F(sctry) + N * fyPt * detJ0 * wt; % scatter force into global force vector
        
    end % of quadrature loop
end % of element loop

%%%%%%%%%%%%%%%%%%%%% COMPUTE STIFFNESS MATRIX %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
disp([num2str(toc), '   COMPUTING STIFFNESS MATRIX'])

% K = CompistePFEMStiffnessMatrix(stressState, Dm, gamma, ndof, K, basisLAB);

Material.Dm = Dm;
Material.nu = nu0;
Material.E = E0;
K = computePCEnStiffnessMatrix(stressState, Material, gamma, ndof, basisLAB, MethodLAB, cenDOF);

%%%%%%%%%%%%%%%%%%% END OF STIFFNESS MATRIX COMPUTATION %%%%%%%%%%%%%%%%%%%%%%

% SOLVE SYSTEM
disp([num2str(toc), '   SOLVING SYSTEM'])
% freedof = setdiff((1 : (2 * (numnode + numelem) + numelem))', bcdof);
% U = zeros(2 * (numnode + numelem) + numelem, 1);
freedof = setdiff((1:2 * (numnode))', bcdof);
U = zeros(2 * (numnode), 1);
U(bcdof) = bcval;
F(freedof) = F(freedof) - K(freedof, bcdof) * bcval;

% solving system of equations for free dofs
U(freedof) = K(freedof, freedof) \ F(freedof);

EU = 0.5 * U' * K * U;
% reference value of the strain energy (compressible): 12.015
% reference value of the strain energy (incompressible): 9.27769
disp(['Strain Energy = ', num2str(EU, 20)]);

CenterNode = find(AdaptiveMesh.Nodes(:, 1) > 48 - 1e-3 & AdaptiveMesh.Nodes(:, 1) < 48 + 1e-3 & AdaptiveMesh.Nodes(:, 2) > 52 - 1e-3 & AdaptiveMesh.Nodes(:, 2) < 52 + 1e-3);
UYCenter = U(CenterNode*2)';
disp(['Num DOFs = ', num2str(ndof * numnode)])
disp(['Center tip displacement = ', num2str(UYCenter, 20)]);

%******************************************************************************
%***                     P O S T  -  P R O C E S S I N G                    ***
%**************************************************************************
[W, Q] = quadrature(2, 'GAUSS', 2); % 2x2 Gaussian quadrature

if strcmp(MethodLAB, 'Classic')
    stressNode = computeStressNodeClassic(numnode, numelem, element, node, Dm, U, basisLAB);
elseif strcmp(MethodLAB, 'PCEn')
    if (strcmp(stressState, 'PLANE_STRAIN'))
        [stressNode, stressElem, pressureNode, pressureElem] = computeStressNodePCEn(stressState, numnode, numelem, element, node, Dm, gamma, U, basisLAB, E0, nu0, cenDOF);
    elseif (strcmp(stressState, 'PLANE_STRESS'))
        [stressNode, stressElem] = computeStressNodePCEn(stressState, numnode, numelem, element, node, Dm, gamma, U, basisLAB, E0, nu0);
    end
end

%func = @(x) sqrt((1 / 2 * ((x(1) - x(2)) .^ 2 + (x(2)) .^ 2 + (x(1)) .^ 2)) + 3 * (x(3) .^ 2));
%vonMisesElem = cellfun(func, stressElem);
stress = zeros([6, numnode]);
stress([1, 2, 4], :) = stressNode;

exportCFEMStressToVTU(AdaptiveMesh, stress, stressState, strcat('PCEn_CooksMembrane_Stress_', stressState, '_', elemType, '_'));

exportCFEMToVTU(AdaptiveMesh, pressureNode, strcat('PCEn_CooksMembrane_Pressure_', stressState, '_', elemType));

