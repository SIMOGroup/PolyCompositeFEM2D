function [F] = loadBeam(elemType, edgeElemType, rightEdge, P, I0, c, F)
global node thickness;

[W, Q] = quadPoints(elemType);
% RIGHT EDGE
for e = 1:size(rightEdge, 1) % loop over the elements in the right edge
    
    sctr = rightEdge(e, :); % scatter vector for the element
    sctry = 2 .* sctr;
    
    fe = zeros(2, 1);
    for q = 1:size(W, 1) % quadrature loop
        pt = Q(q, :); % quadrature point
        wt = W(q); % quadrature weight
        [N, dNdxi] = lagrange_basis(edgeElemType, pt); % element shape functions
        J0 = dNdxi' * node(sctr, :); % element Jacobian
        detJ0 = norm(J0); % determiniat of jacobian
        
        yPt = N' * node(sctr, 2); % y coordinate at quadrature point
        fyPt = -P * (c^2 - yPt^2) / (2 * I0); % y traction at quadrature point
        fe = fe + N * fyPt * detJ0 * wt * thickness; % scatter force into global force vector
    end % of quadrature loop
    F(sctry, 1) = F(sctry, 1) + fe;
end % of element loop
