function Ke = computePEnElementStiffnessMatrix(Coord, Connect, Dm, thickness, LAB)

nn = size(Coord, 1);
nnel = nn - 1;
if strcmp(LAB, 'CorrectedWachspress')
    WGC = evalWachspressGradientCorrection(Coord, Connect);
end
NumGPs = 3;
[P, ~, W, ~] = getQuadData(NumGPs);
ndof = 2;
Ke = zeros(ndof*nnel, ndof*nnel);

for icell = 1:nnel
    CoSubTriPhys = Coord(Connect(icell, :), :);
    for igaus = 1 : NumGPs
        [NT3, dNdsT3] = T3ShapeFnc(P(igaus, :));
        xy = NT3*CoSubTriPhys;
        J = dNdsT3 * CoSubTriPhys;
        dNdxT3 = J \ dNdsT3;
        
        if (strcmp(LAB, 'Wachspress') || strcmp(LAB, 'CorrectedWachspress'))
            [~, dNdx] = wachspress2d_Floater_CenterNode(Coord(1:nnel, :), Coord(end, :), xy);
            % [~, dNdx] = wachspress2d_Floater(Coord(1:nnel, :), xy);
            if strcmp(LAB, 'CorrectedWachspress')
                dNdx = dNdx + WGC;
            end
        elseif (strcmp(LAB, 'T3'))
            dNdx = zeros(nnel, 2);
            dNdx(Connect(icell, 2 : 3), :) = dNdxT3(:, 2 : 3)';
            dNdx = dNdx + repmat(dNdxT3(:, 1)' / nnel, nnel, 1);
        end
        
        subel = 1:nnel;
        Be = zeros(3, 2 * nnel);
        Be(1, 2 * subel - 1) = dNdx(1 : nnel, 1);
        Be(2, 2 * subel) = dNdx(1 : nnel, 2);
        Be(3, 2 * subel - 1) = dNdx(1 : nnel, 2);
        Be(3, 2 * subel) = dNdx(1 : nnel, 1);
        
        Ke = Ke + Be' * Dm * Be * det(J) * W(igaus) * thickness;
    end
end
end