function [bcdof, bcval]=rigidFlatPunch(lx,ly,ndof) 
bcdof=[];
bcval=[];

for i=2:ly+1
    bcdof=[bcdof ndof*i-1 ndof*i];
    bcval=[bcval 0 0];
end
for i=1:lx
    bcdof=[bcdof ndof*((i-1)*(ly+1)+1)-1 ndof*((i-1)*(ly+1)+1)];
    bcval=[bcval 0 0];
end

for i=1:ly+1
    bcdof=[bcdof ndof*((ly+1)*lx +i)-1 ndof*((ly+1)*lx +i)];
    bcval=[bcval 0 0];
end

for i=lx/3+1:2*lx/3+1
    bcdof=[bcdof ndof*(ly+1)*i];
    bcval=[bcval 0.03];
end
