function [xd,yd]=xy_subQ8(num_sub,sub_elem,iel)

global node element

sctr=element(iel,:);
if num_sub==1
    xd=node(sctr(1:4),1);
    yd=node(sctr(1:4),2);
elseif num_sub==2
    xy_5=node(sctr(5),:);
    xy_7=node(sctr(7),:);
    if sub_elem==1
        xd=[node(sctr(1),1) xy_5(1) xy_7(1) node(sctr(4),1)];
        yd=[node(sctr(1),2) xy_5(2) xy_7(2) node(sctr(4),2)];
    else % sub elem==2
        xd=[xy_5(1) node(sctr(2),1) node(sctr(3),1) xy_7(1)];
        yd=[xy_5(2) node(sctr(2),2) node(sctr(3),2) xy_7(2)];
    end
 elseif num_sub==3
    xy_5=node(sctr(5),:);
    xy_6=node(sctr(6),:);
    xy_7=node(sctr(7),:);
    xy_9 =mean(node(sctr,:));
    if sub_elem==1
        xd=[node(sctr(1),1) xy_5(1) xy_7(1) node(sctr(4),1)];
        yd=[node(sctr(1),2) xy_5(2) xy_7(2) node(sctr(4),2)];
    elseif sub elem==2
        xd=[xy_5(1) node(sctr(2),1) xy_6(1) xy_9(1)];
        yd=[xy_5(2) node(sctr(2),2) xy_6(2) xy_9(2)];
    else
       xd=[xy_9(1) xy_6(1) node(sctr(3),1) xy_7(1)];
       yd=[xy_9(2) xy_6(2) node(sctr(3),2) xy_7(2)]; 
    end
    
elseif num_sub==4
    xy_5=node(sctr(5),:);
    xy_6=node(sctr(6),:);
    xy_7=node(sctr(7),:);
    xy_8=node(sctr(8),:);
    xy_9 =mean(node(sctr,:));
    if sub_elem==1
        xd=[node(sctr(1),1) xy_5(1) xy_9(1) xy_8(1)];
        yd=[node(sctr(1),2) xy_6(2) xy_9(2) xy_8(2)];
    elseif sub_elem==2
        xd=[xy_5(1) node(sctr(2),1) xy_6(1) xy_9(1)];
        yd=[xy_5(2) node(sctr(2),2) xy_6(2) xy_9(2)];
    elseif sub_elem==3
        xd=[xy_9(1) xy_6(1) node(sctr(3),1) xy_7(1)];
        yd=[xy_9(2) xy_6(2) node(sctr(3),2) xy_7(2)];
    elseif sub_elem==4
        xd=[xy_8(1) xy_9(1) xy_7(1) node(sctr(4),1)];
        yd=[xy_8(2) xy_9(2) xy_7(2) node(sctr(4),2)];
    end
end
end
