function K= sfemKQ8_alpha(ivo,elemType,neighbour,area,supp,enrich_node,D,ng,al)
                          
global node element K 
nc = length(neighbour); %number of neighbouring cells corresponding to index of element (No of element)
if (strcmp(elemType,'T6'))
  for i = 1:nc
    kcc = neighbour(i);% index of element
    sctr = element(kcc,:);
    nodes = node(sctr,:);
    
    for inode=1:6
        n(inode) = element(kcc,inode);
        x(inode) = node(n(inode),1);
        y(inode) = node(n(inode),2); 
    end    

    xm1 = (node(n(1),1)+node(n(4),1))/2; ym1 = (node(n(1),2)+node(n(4),2))/2;
    xm2 = (node(n(2),1)+node(n(4),1))/2; ym2 = (node(n(2),2)+node(n(4),2))/2;
    xm3 = (node(n(2),1)+node(n(5),1))/2; ym3 = (node(n(2),2)+node(n(5),2))/2;
    xm4 = (node(n(3),1)+node(n(5),1))/2; ym4 = (node(n(3),2)+node(n(5),2))/2;
    xm5 = (node(n(3),1)+node(n(6),1))/2; ym5 = (node(n(3),2)+node(n(6),2))/2;
    xm6 = (node(n(1),1)+node(n(6),1))/2; ym6 = (node(n(1),2)+node(n(6),2))/2;
    xm7 = (node(n(1),1)+node(n(4),1)+node(n(6),1))/3;
    ym7 = (node(n(1),2)+node(n(4),2)+node(n(6),2))/3;
    xm8 = (node(n(2),1)+node(n(5),1)+node(n(4),1))/3;
    ym8 = (node(n(2),2)+node(n(5),2)+node(n(4),2))/3;
    xm9 = (node(n(3),1)+node(n(6),1)+node(n(5),1))/3;
    ym9 = (node(n(3),2)+node(n(6),2)+node(n(5),2))/3;
    xm10 = (node(n(1),1)+node(n(2),1)+node(n(3),1))/3;
    ym10 = (node(n(1),2)+node(n(2),2)+node(n(3),2))/3;
    
    x_sc=[x';xm1;xm2;xm3;xm4;xm5;xm6;xm7;xm8;xm9;xm10];
    y_sc=[y';ym1;ym2;ym3;ym4;ym5;ym6;ym7;ym8;ym9;ym10];
        
    gcoord(:,1)=x_sc;
    gcoord(:,2)=y_sc;
    node_sc1=[1 7 13; 1 13 12];
    node_sc2=[2 9 14; 2 14 8];
    node_sc3=[3 11 15; 3 15 10];% corner nodes
    
   %node_sc1=[1 7 13 12;2 9 14 8;3 11 15 10];% corner nodes
   %node_sc2=[4 8 14 16 13 7;5 10 15 16 14 9;6 12 13 16 15 11];
    node_sc4=[4 8 14; 4 14 16; 4 16 13;4 13 7];
    node_sc5=[5 10 15; 5 15 16;5 16 14;5 16 9];
    node_sc6=[6 12 13;6 13 16;6 16 15;6 15 11];
    % loop on the two segments in cell kcc against node ia 
    % dof_enr=2*sum(enrich_node(sctr));
    %for isc=1:nsc % loop sub cell element
    xsupp = supp{neighbour(i)}; % support node numbering
    nsf = length(xsupp);
    %B_sfem=[];%zeros(3,2*nsf);
    % B_enr=zeros(3,dof_enr);
    bx=zeros(nsf,1);
    by=zeros(nsf,1);
    
   if (ivo-n(1)<1e-10)
     for icel=1:2
       xx=gcoord(node_sc1(icel,:),1);
       yy=gcoord(node_sc1(icel,:),2);
       %Ac=area_sc(xx,yy);
       side=cal_side(xx,yy);
       [nx,ny]=cal_nx_ny(xx,yy,side);
       ns=length(xx); % number side of sub element. T3 ==>ns=3
       for is=1:ns % loop ns-sides of sub cell element-two gauss points per side
            [W,Q]=quadrature(ng,'GAUSS',1);
            for ig=1:ng
                %Bs_enr=[];
                N_g=lagrange_basis('L2',Q(ig));
                [xi1,eta1]=xi_eta4xy('T3',is,N_g);
                N_xy=lagrange_basis('T3',[xi1 eta1]);
                xy_g=N_xy'*[xx yy];

                xieta=cal_xieta('T3',xy_g,nodes);
                N_T=lagrange_basis(elemType,xieta);

%               plot_g=[plot_g;xy_g];
                J2=side(is)/2; % Jacobian matrix for L2 
                
                bx=bx + nx(is)*N_T*J2*W(ig);
                by=by + ny(is)*N_T*J2*W(ig);
            end % end loop of gauss points on side
       end %end of side
     end
   end
  if (ivo-n(2)<1e-10)
     for icel=1:2
       xx=gcoord(node_sc2(icel,:),1);
       yy=gcoord(node_sc2(icel,:),2);
       %Ac=area_sc(xx,yy);
       side=cal_side(xx,yy);
       [nx,ny]=cal_nx_ny(xx,yy,side);
       ns=length(xx); % number side of sub element. T3 ==>ns=3
       for is=1:ns % loop ns-sides of sub cell element-two gauss points per side
            [W,Q]=quadrature(ng,'GAUSS',1);
            for ig=1:ng
                %Bs_enr=[];
                N_g=lagrange_basis('L2',Q(ig));
                [xi1,eta1]=xi_eta4xy('T3',is,N_g);
                N_xy=lagrange_basis('T3',[xi1 eta1]);
                xy_g=N_xy'*[xx yy];
                xieta=cal_xieta('T3',xy_g,nodes);
                N_T=lagrange_basis(elemType,xieta);

%               plot_g=[plot_g;xy_g];
                J2=side(is)/2; % Jacobian matrix for L2 
                
                bx=bx + nx(is)*N_T*J2*W(ig);
                by=by + ny(is)*N_T*J2*W(ig);
            end % end loop of gauss points on side
       end %end of side
     end
   end
   if (ivo == n(3))
      for icel=1:2
       xx=gcoord(node_sc3(icel,:),1);
       yy=gcoord(node_sc3(icel,:),2);
       %Ac=area_sc(xx,yy);
       side=cal_side(xx,yy);
       [nx,ny]=cal_nx_ny(xx,yy,side);
       ns=length(xx); % number side of sub element. T3 ==>ns=3
       for is=1:ns % loop ns-sides of sub cell element-two gauss points per side
            [W,Q]=quadrature(ng,'GAUSS',1);
            for ig=1:ng
                %Bs_enr=[];
                N_g=lagrange_basis('L2',Q(ig));
                [xi1,eta1]=xi_eta4xy('T3',is,N_g);
                N_xy=lagrange_basis('T3',[xi1 eta1]);
                xy_g=N_xy'*[xx yy];

                xieta=cal_xieta('T3',xy_g,nodes);
                N_T=lagrange_basis(elemType,xieta);

%               plot_g=[plot_g;xy_g];
                J2=side(is)/2; % Jacobian matrix for L2 
                
                bx=bx + nx(is)*N_T*J2*W(ig);
                by=by + ny(is)*N_T*J2*W(ig);
            end % end loop of gauss points on side
       end %end of side
      end
   end

   if (ivo == n(4))
      for icel=1:4
       xx=gcoord(node_sc4(icel,:),1);
       yy=gcoord(node_sc4(icel,:),2);
       %Ac=area_sc(xx,yy);
       side=cal_side(xx,yy);
       [nx,ny]=cal_nx_ny(xx,yy,side);
       ns=length(xx); % number side of sub element. T3 ==>ns=3
       for is=1:ns % loop ns-sides of sub cell element-two gauss points per side
            [W,Q]=quadrature(ng,'GAUSS',1);
            for ig=1:ng
                %Bs_enr=[];
                N_g=lagrange_basis('L2',Q(ig));
                [xi1,eta1]=xi_eta4xy('T3',is,N_g);
                N_xy=lagrange_basis('T3',[xi1 eta1]);
                xy_g=N_xy'*[xx yy];

                xieta=cal_xieta('T3',xy_g,nodes);
                N_T=lagrange_basis(elemType,xieta);

%               plot_g=[plot_g;xy_g];
                J2=side(is)/2; % Jacobian matrix for L2 
                
                bx=bx + nx(is)*N_T*J2*W(ig);
                by=by + ny(is)*N_T*J2*W(ig);
            end % end loop of gauss points on side
       end %end of side
      end
   end
    if (ivo == n(5))
      for icel=1:4
       xx=gcoord(node_sc5(icel,:),1);
       yy=gcoord(node_sc5(icel,:),2);
       %Ac=area_sc(xx,yy);
       side=cal_side(xx,yy);
       [nx,ny]=cal_nx_ny(xx,yy,side);
       ns=length(xx); % number side of sub element. T3 ==>ns=3
       for is=1:ns % loop ns-sides of sub cell element-two gauss points per side
            [W,Q]=quadrature(ng,'GAUSS',1);
            for ig=1:ng
                %Bs_enr=[];
                N_g=lagrange_basis('L2',Q(ig));
                [xi1,eta1]=xi_eta4xy('T3',is,N_g);
                N_xy=lagrange_basis('T3',[xi1 eta1]);
                xy_g=N_xy'*[xx yy];

                xieta=cal_xieta('T3',xy_g,nodes);
                N_T=lagrange_basis(elemType,xieta);

%               plot_g=[plot_g;xy_g];
                J2=side(is)/2; % Jacobian matrix for L2 
                
                bx=bx + nx(is)*N_T*J2*W(ig);
                by=by + ny(is)*N_T*J2*W(ig);
            end % end loop of gauss points on side
       end %end of side
      end
    end
   if (ivo == n(6))
     for icel=1:4
       xx=gcoord(node_sc6(icel,:),1);
       yy=gcoord(node_sc6(icel,:),2);
       %Ac=area_sc(xx,yy);
       side=cal_side(xx,yy);
       [nx,ny]=cal_nx_ny(xx,yy,side);
       ns=length(xx); % number side of sub element. T3 ==>ns=3
       for is=1:ns % loop ns-sides of sub cell element-two gauss points per side
            [W,Q]=quadrature(ng,'GAUSS',1);
            for ig=1:ng
                %Bs_enr=[];
                N_g=lagrange_basis('L2',Q(ig));
                [xi1,eta1]=xi_eta4xy('T3',is,N_g);
                N_xy=lagrange_basis('T3',[xi1 eta1]);
                xy_g=N_xy'*[xx yy];

                xieta=cal_xieta('T3',xy_g,nodes);
                N_T=lagrange_basis(elemType,xieta);

%               plot_g=[plot_g;xy_g];
                J2=side(is)/2; % Jacobian matrix for L2 
                
                bx=bx + nx(is)*N_T*J2*W(ig);
                by=by + ny(is)*N_T*J2*W(ig);
            end % end loop of gauss points on side
       end %end of side
     end
   end
    
     if i==1
           nodL=supp{neighbour(i)};
           nn=nsf;
           for jj=1:nn
           B_sfem(1,2*jj-1)=bx(jj);
           B_sfem(2,2*jj)=by(jj);
           B_sfem(3,2*jj-1)=by(jj);
           B_sfem(3,2*jj)=bx(jj);
           end
     else  
          i0=0;
          for jj=1:nsf
                nod=supp{neighbour(i)}(jj);
                flag=0;
              for j=1:nn
                  if nodL(j)==nod
                      B_sfem(1,2*j-1)=B_sfem(1,2*j-1)+bx(jj)/area;
                      B_sfem(2,2*j)=B_sfem(2,2*j)+ by(jj)/area;
                      B_sfem(3,2*j-1)=B_sfem(3,2*j-1)+by(jj)/area;
                      B_sfem(3,2*j)=B_sfem(3,2*j)+bx(jj)/area;
                      flag=1;  break
                  end
              end
                if flag==0
                    i0=i0+1;
                     nodL(nn+i0)=nod;
                    B_sfem(1,2*(nn+i0)-1)=bx(jj)/area;
                    B_sfem(2,2*(nn+i0))=by(jj)/area;
                    B_sfem(3,2*(nn+i0)-1)=by(jj)/area;
                    B_sfem(3,2*(nn+i0))=bx(jj)/area;
                end
           end 
             nn=nn+i0;             
     end  %end else
 end %number of neighbouring cells
     
  if ( any(enrich_node(sctr)) == 0 ) % Non-enriched elements
                B_sm=B_sfem;
  else
                B_sm=[B_sfem B_enr];
  end
      clear B_sfem xx yy ;
      %Ke_sc=zeros(2*nn+dof_enr,2*nn+dof_enr);
  Ke_sc = B_sm'*D*B_sm*area;
  numnod = length(nodL);
  sctrB(1:2:2*numnod) = 2.*nodL-1 ;
  sctrB(2:2:2*numnod) = 2.*nodL   ;    
  K(sctrB,sctrB) = K(sctrB,sctrB) + Ke_sc;
      %rank(Ke_sc)
      clear B_sm Ke_sc nodL;
elseif (strcmp(elemType,'T3'))
  for i = 1:nc % num of element
    kcc = neighbour(i);% index of element
    sctr = element(kcc,:);
    nodes = node(sctr,:);
    
    for inode=1:3
        n(inode) = element(kcc,inode);
        x(inode) = node(n(inode),1);
        y(inode) = node(n(inode),2); 
    end    
    xm1 = (node(n(1),1)+node(n(2),1))/2; ym1 = (node(n(1),2)+node(n(2),2))/2;
    xm2 = (node(n(2),1)+node(n(3),1))/2; ym2 = (node(n(2),2)+node(n(3),2))/2;
    xm3 = (node(n(3),1)+node(n(1),1))/2; ym3 = (node(n(3),2)+node(n(1),2))/2;
    xm4 = (node(n(1),1)+node(n(2),1)+node(n(3),1))/3;
    ym4 = (node(n(1),2)+node(n(2),2)+node(n(3),2))/3;
    x_sc=[x';xm1;xm2;xm3;xm4];
    y_sc=[y';ym1;ym2;ym3;ym4];
        
    gcoord(:,1)=x_sc;
    gcoord(:,2)=y_sc;
    node_sc1=[1 4 7; 1 7 6];
    node_sc2=[2 5 7; 2 7 4];
    node_sc3=[3 6 7; 3 7 5];% corner nodes
    
    % loop on the two segments in cell kcc against node ia 
    % dof_enr=2*sum(enrich_node(sctr));
    %for isc=1:nsc % loop sub cell element
    xsupp = supp{neighbour(i)}; % support node numbering
    nsf = length(xsupp);
    bx=zeros(nsf,1);
    by=zeros(nsf,1);
    % compute B_fem
    [W,Q]=quadrature(1, 'TRIANGULAR', 2 ); % 1 point triangural quadrature    
    for q=1:size(W,1)                        % quadrature loop
      pt=Q(q,:);                             % quadrature point
      %wt=W(q);                               % quadrature weight
      [N,dNdxi]=lagrange_basis(elemType,pt); % element shape functions
      J0=node(sctr,:)'*dNdxi;                % element Jacobian matrix        
      invJ0=inv(J0);
      dNdx=dNdxi*invJ0;
    
%     %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
      B_fem=zeros(3,2*nsf);
      B_fem(1,1:2:2*nsf-1) = dNdx(:,1)';
      B_fem(2,2:2:2*nsf)   = dNdx(:,2)';
      B_fem(3,1:2:2*nsf-1) = dNdx(:,2)';
      B_fem(3,2:2:2*nsf)  = dNdx(:,1)';
    end
     
   if (ivo == n(1))
     for icel=1:2
       xx=gcoord(node_sc1(icel,:),1);
       yy=gcoord(node_sc1(icel,:),2);
       side=cal_side(xx,yy);
       [nx,ny]=cal_nx_ny(xx,yy,side);
       ns=length(xx); % number side of sub element. T3 ==>ns=3
       for is=1:ns % loop ns-sides of sub cell element-two gauss points per side
            [W,Q]=quadrature(ng,'GAUSS',1);
            for ig=1:ng
                %Bs_enr=[];
                N_g=lagrange_basis('L2',Q(ig));
                [xi1,eta1]=xi_eta4xy('T3',is,N_g);
                N_xy=lagrange_basis('T3',[xi1 eta1]);
                xy_g=N_xy'*[xx yy];

                xieta=cal_xieta('T3',xy_g,nodes);
                N_T=lagrange_basis(elemType,xieta);

%               plot_g=[plot_g;xy_g];
                J2=side(is)/2; % Jacobian matrix for L2 
                
                bx=bx + nx(is)*N_T*J2*W(ig);
                by=by + ny(is)*N_T*J2*W(ig);
            end % end loop of gauss points on side
       end %end of side
     end 
   clear W Q;
   end
  if (ivo == n(2))
     for icel=1:2
       xx=gcoord(node_sc2(icel,:),1);
       yy=gcoord(node_sc2(icel,:),2);
       side=cal_side(xx,yy);
       [nx,ny]=cal_nx_ny(xx,yy,side);
       ns=length(xx); % number side of sub element. T3 ==>ns=3
       for is=1:ns % loop ns-sides of sub cell element-two gauss points per side
            [W,Q]=quadrature(ng,'GAUSS',1);
            for ig=1:ng
                %Bs_enr=[];
                N_g=lagrange_basis('L2',Q(ig));
                [xi1,eta1]=xi_eta4xy('T3',is,N_g);
                N_xy=lagrange_basis('T3',[xi1 eta1]);
                xy_g=N_xy'*[xx yy];
                xieta=cal_xieta('T3',xy_g,nodes);
                N_T=lagrange_basis(elemType,xieta);

%               plot_g=[plot_g;xy_g];
                J2=side(is)/2; % Jacobian matrix for L2 
                
                bx=bx + nx(is)*N_T*J2*W(ig);
                by=by + ny(is)*N_T*J2*W(ig);
            end % end loop of gauss points on side
       end %end of side
     end
    clear W Q;
%    [W,Q]=quadrature(1, 'TRIANGULAR', 2 ); % 1 point triangural quadrature    
%     for q=1:size(W,1)                        % quadrature loop
%      pt=Q(q,:);                             % quadrature point
%      wt=W(q);                               % quadrature weight
%      [N,dNdxi]=lagrange_basis(elemType,pt); % element shape functions
%      J0=node(sctr,:)'*dNdxi;                % element Jacobian matrix        
%      invJ0=inv(J0);
%      dNdx=dNdxi*invJ0;
%      B_fem=zeros(3,2*nsf);
%      B_fem(1,1:2:2*nsf-1) = dNdx(:,1)';
%      B_fem(2,2:2:2*nsf)   = dNdx(:,2)';
%      B_fem(3,1:2:2*nsf-1) = dNdx(:,2)';
%      B_fem(3,2:2:2*nsf)  = dNdx(:,1)';
%      end 
  end
   if (ivo == n(3))
      for icel=1:2
       xx=gcoord(node_sc3(icel,:),1);
       yy=gcoord(node_sc3(icel,:),2);
       side=cal_side(xx,yy);
       [nx,ny]=cal_nx_ny(xx,yy,side);
       ns=length(xx); % number side of sub element. T3 ==>ns=3
       for is=1:ns % loop ns-sides of sub cell element-two gauss points per side
            [W,Q]=quadrature(ng,'GAUSS',1);
            for ig=1:ng
                %Bs_enr=[];
                N_g=lagrange_basis('L2',Q(ig));
                [xi1,eta1]=xi_eta4xy('T3',is,N_g);
                N_xy=lagrange_basis('T3',[xi1 eta1]);
                xy_g=N_xy'*[xx yy];

                xieta=cal_xieta('T3',xy_g,nodes);
                N_T=lagrange_basis(elemType,xieta);

%               plot_g=[plot_g;xy_g];
                J2=side(is)/2; % Jacobian matrix for L2 
                
                bx=bx + nx(is)*N_T*J2*W(ig);
                by=by + ny(is)*N_T*J2*W(ig);
            end % end loop of gauss points on side
       end %end of side
      end
      clear W Q;
%       [W,Q]=quadrature(1, 'TRIANGULAR', 2 ); % 1 point triangural quadrature    
%     for q=1:size(W,1)                        % quadrature loop
%      pt=Q(q,:);                             % quadrature point
%      wt=W(q);                               % quadrature weight
%      [N,dNdxi]=lagrange_basis(elemType,pt); % element shape functions
%      J0=node(sctr,:)'*dNdxi;                % element Jacobian matrix        
%      invJ0=inv(J0);
%      dNdx=dNdxi*invJ0;
%       B_fem=zeros(3,2*nsf);
%       B_fem(1,1:2:2*nsf-1) = dNdx(:,1)';
%       B_fem(2,2:2:2*nsf)   = dNdx(:,2)';
%       B_fem(3,1:2:2*nsf-1) = dNdx(:,2)';
%       B_fem(3,2:2:2*nsf)  = dNdx(:,1)';
%      end 
   end
     bx=bx/area;
     by=by/area;
     Bfem{i}=B_fem;
     clear B_fem
     if i==1
           nodL=element(neighbour(i),:);%supp{neighbour(i)};
           nn=nsf;% num of node of each element
           for jj=1:nn
            B_sfem(1,2*jj-1)=bx(jj);
            B_sfem(2,2*jj)=by(jj);
            B_sfem(3,2*jj-1)=by(jj);
            B_sfem(3,2*jj)=bx(jj);
           end
     else  
          i0=0;
          for jj=1:nsf
                nod=element(neighbour(i),jj);%supp{neighbour(i)}(jj);
                flag=0;
              for j=1:nn
                  if nodL(j)==nod
                      B_sfem(1,2*j-1)=B_sfem(1,2*j-1)+bx(jj);
                      B_sfem(2,2*j)=B_sfem(2,2*j)+ by(jj);
                      B_sfem(3,2*j-1)=B_sfem(3,2*j-1)+by(jj);
                      B_sfem(3,2*j)=B_sfem(3,2*j)+bx(jj);
                      flag=1;  break
                  end
              end
                if flag==0
                    i0=i0+1;
                    nodL(nn+i0)=nod;
                    B_sfem(1,2*(nn+i0)-1)=bx(jj);
                    B_sfem(2,2*(nn+i0))=by(jj);
                    B_sfem(3,2*(nn+i0)-1)=by(jj);
                    B_sfem(3,2*(nn+i0))=bx(jj);
                end
           end 
             nn=nn+i0;             
     end  %end else
 end %number of neighbouring cells
 % nodL   
  if ( any(enrich_node(sctr)) == 0 ) % Non-enriched elements
                B_sm=B_sfem;
  else
                B_sm=[B_sfem B_enr];
  end
  %%%% store B_FEM----------------
  %Ke_sc = B_sm'*D*B_sm*area;
  Ke_sc=zeros(2*size(nodL,2));
  for i = 1:nc % num of element
    xsupp = supp{neighbour(i)}; % support node numbering
    nsf = length(xsupp);
    nodes = node(xsupp,:);
    Ac=cal_area(nodes(:,1),nodes(:,2));
    %a=size(nodL,2)
    %b=size(B,2)
    Bf{i}=zeros(3,2*size(nodL,2));  
    if i==1
           nodLl=element(neighbour(i),:);%supp{neighbour(i)};
           nn=nsf;% num of node of each element
           Bf{i}(1,1:2:2*nn-1) = Bfem{i}(1,1:2:2*nn-1);
           Bf{i}(2,2:2:2*nn)   = Bfem{i}(2,2:2:2*nn);
           Bf{i}(3,1:2:2*nn-1) = Bfem{i}(3,1:2:2*nn-1);
           Bf{i}(3,2:2:2*nn)  =  Bfem{i}(3,2:2:2*nn);
    else  
          i0=0;
          for jj=1:nsf
                nod=element(neighbour(i),jj);
                flag=0;
              for j=1:nn
                  if nodLl(j)==nod
                      Bf{i}(1,2*j-1) = Bfem{i}(1,2*jj-1);
                      Bf{i}(2,2*j)   = Bfem{i}(2,2*jj);
                      Bf{i}(3,2*j-1) = Bfem{i}(3,2*jj-1);
                      Bf{i}(3,2*j)  =  Bfem{i}(3,2*jj);
                      flag=1;  break
                  end
              end
                if flag==0
                    i0=i0+1;
                    nodLl(nn+i0)=nod;
                    Bf{i}(1,2*(nn+i0)-1) = Bfem{i}(1,2*jj-1);
                    Bf{i}(2,2*(nn+i0))   = Bfem{i}(2,2*jj);
                    Bf{i}(3,2*(nn+i0)-1) = Bfem{i}(3,2*jj-1);
                    Bf{i}(3,2*(nn+i0))  =  Bfem{i}(3,2*jj);
                end
           end 
             nn=nn+i0;              
     end  %end else
    B=Bf{i};
    %Ke_sc=Ke_sc+(B'*D*B/3-al^2*(B_sm-B)'*D*(B_sm-B)/3)*Ac;
    Ke_sc=Ke_sc+(B'*D*B/3-al^2*(B_sm-B)'*D*(B_sm-B)/9)*Ac;
    clear Bf; 
 end %number of neighbouring cells
 
  clear B_sfem xx yy x y nn nodL1 B;
  %Ke_sc=zeros(2*nn+dof_enr,2*nn+dof_enr);
  %Ke_sc = B_sm'*D*B_sm*area;
  numnod = length(nodL);
  sctrB(1:2:2*numnod) = 2.*nodL-1 ;
  sctrB(2:2:2*numnod) = 2.*nodL   ;
  K(sctrB,sctrB) = K(sctrB,sctrB) + Ke_sc;
  %rank(Ke_sc)
  clear B_sm Ke_sc nodL sctrB;
      
 elseif (strcmp(elemType,'Q4'))
   for i = 1:nc  
    kcc = neighbour(i);% index of element
    sctr = element(kcc,:);
    nodes = node(sctr,:);
    
    for inode=1:4
        n(inode) = element(kcc,inode);
        x(inode) = node(n(inode),1);
        y(inode) = node(n(inode),2); 
    end 
    x_sc=[x';1/2*(x(1)+x(2));1/2*(x(2)+x(3));...
            1/2*(x(3)+x(4));1/2*(x(4)+x(1));1/4*(x(1)+x(2)+x(3)+x(4))];
    y_sc=[y';1/2*(y(1)+y(2));1/2*(y(2)+y(3));...
            1/2*(y(3)+y(4));1/2*(y(4)+y(1));1/4*(y(1)+y(2)+y(3)+y(4))];
        
    gcoord(:,1)=x_sc;
    gcoord(:,2)=y_sc;
    
    %       4------7-----3
    %       | sc4  | sc3 |
    %       8------9-----6
    %       | sc1  | sc2 | 
    %       1------5-----2    
        
        node_sc=[1 5 9 8;
                 2 6 9 5;
                 3 7 9 6;
                 4 8 9 7];
    
    xsupp = supp{neighbour(i)}; % support node numbering
    nsf = length(xsupp);
    %B_sfem=[];%zeros(3,2*nsf);
    % B_enr=zeros(3,dof_enr);
    bx=zeros(nsf,1);
    by=zeros(nsf,1);
    
   if (ivo == n(1))
       xx=gcoord(node_sc(1,:),1);
       yy=gcoord(node_sc(1,:),2);
       %Ac=area_sc(xx,yy);
       side=cal_side(xx,yy);
       [nx,ny]=cal_nx_ny(xx,yy,side);
       ns=length(xx); % number side of sub element. T3 ==>ns=3
       for is=1:ns % loop ns-sides of sub cell element-two gauss points per side
            [W,Q]=quadrature(ng,'GAUSS',1);
            for ig=1:ng
                %Bs_enr=[];
                N_g=lagrange_basis('L2',Q(ig));
                [xi1,eta1]=xi_eta4xy('Q4',is,N_g);
                N_xy=lagrange_basis('Q4',[xi1 eta1]);
                xy_g=N_xy'*[xx yy];

                xieta=cal_xieta('Q4',xy_g,nodes);
                N_T=lagrange_basis(elemType,xieta);

%               plot_g=[plot_g;xy_g];
                J2=side(is)/2; % Jacobian matrix for L2 
                
                bx=bx + nx(is)*N_T*J2*W(ig);
                by=by + ny(is)*N_T*J2*W(ig);
            end % end loop of gauss points on side
       end %end of side
   end
    if (ivo == n(2))
      xx=gcoord(node_sc(2,:),1);
       yy=gcoord(node_sc(2,:),2);
       %Ac=area_sc(xx,yy);
       side=cal_side(xx,yy);
       [nx,ny]=cal_nx_ny(xx,yy,side);
       ns=length(xx); % number side of sub element. T3 ==>ns=3
       for is=1:ns % loop ns-sides of sub cell element-two gauss points per side
            [W,Q]=quadrature(ng,'GAUSS',1);
            for ig=1:ng
                %Bs_enr=[];
                N_g=lagrange_basis('L2',Q(ig));
                [xi1,eta1]=xi_eta4xy('Q4',is,N_g);
                N_xy=lagrange_basis('Q4',[xi1 eta1]);
                xy_g=N_xy'*[xx yy];
                xieta=cal_xieta('Q4',xy_g,nodes);
                N_T=lagrange_basis(elemType,xieta);

%               plot_g=[plot_g;xy_g];
                J2=side(is)/2; % Jacobian matrix for L2 
                
                bx=bx + nx(is)*N_T*J2*W(ig);
                by=by + ny(is)*N_T*J2*W(ig);
            end % end loop of gauss points on side
       end %end of side
   end
   if (ivo == n(3))
       xx=gcoord(node_sc(3,:),1);
       yy=gcoord(node_sc(3,:),2);
       %Ac=area_sc(xx,yy);
       side=cal_side(xx,yy);
       [nx,ny]=cal_nx_ny(xx,yy,side);
       ns=length(xx); % number side of sub element. T3 ==>ns=3
       for is=1:ns % loop ns-sides of sub cell element-two gauss points per side
            [W,Q]=quadrature(ng,'GAUSS',1);
            for ig=1:ng
                %Bs_enr=[];
                N_g=lagrange_basis('L2',Q(ig));
                [xi1,eta1]=xi_eta4xy('Q4',is,N_g);
                N_xy=lagrange_basis('Q4',[xi1 eta1]);
                xy_g=N_xy'*[xx yy];

                xieta=cal_xieta('Q4',xy_g,nodes);
                N_T=lagrange_basis(elemType,xieta);

%               plot_g=[plot_g;xy_g];
                J2=side(is)/2; % Jacobian matrix for L2 
                
                bx=bx + nx(is)*N_T*J2*W(ig);
                by=by + ny(is)*N_T*J2*W(ig);
            end % end loop of gauss points on side
       end %end of side
    end
      
   if (ivo == n(4))
      xx=gcoord(node_sc(4,:),1);
       yy=gcoord(node_sc(4,:),2);
       %Ac=area_sc(xx,yy);
       side=cal_side(xx,yy);
       [nx,ny]=cal_nx_ny(xx,yy,side);
       ns=length(xx); % number side of sub element. T3 ==>ns=3
       for is=1:ns % loop ns-sides of sub cell element-two gauss points per side
            [W,Q]=quadrature(ng,'GAUSS',1);
            for ig=1:ng
                %Bs_enr=[];
                N_g=lagrange_basis('L2',Q(ig));
                [xi1,eta1]=xi_eta4xy('Q4',is,N_g);
                N_xy=lagrange_basis('Q4',[xi1 eta1]);
                xy_g=N_xy'*[xx yy];

                xieta=cal_xieta('Q4',xy_g,nodes);
                N_T=lagrange_basis(elemType,xieta);

%               plot_g=[plot_g;xy_g];
                J2=side(is)/2; % Jacobian matrix for L2 
                
                bx=bx + nx(is)*N_T*J2*W(ig);
                by=by + ny(is)*N_T*J2*W(ig);
            end % end loop of gauss points on side
       end %end of side
   end
     bx=bx/area;
     by=by/area;
     if i==1
           nodL=supp{neighbour(i)};
           nn=nsf;
           for jj=1:nn
           B_sfem(1,2*jj-1)=bx(jj);
           B_sfem(2,2*jj)=by(jj);
           B_sfem(3,2*jj-1)=by(jj);
           B_sfem(3,2*jj)=bx(jj);
           end
     else  
          i0=0;
          for jj=1:nsf
                nod=supp{neighbour(i)}(jj);
                flag=0;
              for j=1:nn
                  if nodL(j)==nod
                      B_sfem(1,2*j-1)=B_sfem(1,2*j-1)+bx(jj);
                      B_sfem(2,2*j)=B_sfem(2,2*j)+ by(jj);
                      B_sfem(3,2*j-1)=B_sfem(3,2*j-1)+by(jj);
                      B_sfem(3,2*j)=B_sfem(3,2*j)+bx(jj);
                      flag=1;  break
                  end
              end
                if flag==0
                    i0=i0+1;
                    nodL(nn+i0)=nod;
                    B_sfem(1,2*(nn+i0)-1)=bx(jj);
                    B_sfem(2,2*(nn+i0))=by(jj);
                    B_sfem(3,2*(nn+i0)-1)=by(jj);
                    B_sfem(3,2*(nn+i0))=bx(jj);
                end
           end 
             nn=nn+i0;             
     end  %end else
 end %number of neighbouring cells
     %nodL
  if ( any(enrich_node(sctr)) == 0 ) % Non-enriched elements
                B_sm=B_sfem;
  else
                B_sm=[B_sfem B_enr];
  end
      clear B_sfem xx yy x y n;
      %Ke_sc=zeros(2*nn+dof_enr,2*nn+dof_enr);
  Ke_sc = B_sm'*D*B_sm*area;
  numnod = length(nodL);
  sctrB(1:2:2*numnod) = 2.*nodL-1 ;
  sctrB(2:2:2*numnod) = 2.*nodL   ;    
  K(sctrB,sctrB) = K(sctrB,sctrB) + Ke_sc;
  
 else
   disp('Number smoothing cells of element are not implemented');
   return
end



   

