function coord=cal_xieta3D(elemType,xyz_g,nodes1)

%epsilon = 0.00001;
 if (strcmp(elemType,'B8'))
     nodes=nodes1(1:4,:);     
%     corner  = [1 2 3 4 1];
%     node    = [-1 -1; 1 -1; 1 1; -1 1];
 else %if(strcmp(elemType,'H4')) or H4b
     nodes=nodes1(1:4,:);     
%     corner  = [1 2 3 1];
%     node    = [0 0;1 0;0 1];
 end

coord = zeros(1,3);
ksi   = 0;
eta   = 0;
zeta   = 0;

iter  = 5;
inc = 1;

while (inc < iter)
    [N,dNdxi]=lagrange_basis(elemType,coord);  % compute shape functions

    x = N'*nodes(:,1);
    y = N'*nodes(:,2);
    z = N'*nodes(:,3);
    
    dx_dxi = dNdxi(:,1)' * nodes(:,1);
    dy_dxi = dNdxi(:,1)' * nodes(:,2);
    dz_dxi = dNdxi(:,1)' * nodes(:,3);
    
    dx_deta = dNdxi(:,2)' * nodes(:,1);
    dy_deta = dNdxi(:,2)' * nodes(:,2);
    dz_deta = dNdxi(:,2)' * nodes(:,3);
    
    dx_dzeta = dNdxi(:,3)' * nodes(:,1);
    dy_dzeta = dNdxi(:,3)' * nodes(:,2);
    dz_dzeta = dNdxi(:,3)' * nodes(:,3);
    
    deltaX = x - xyz_g(1);
    deltaY = y - xyz_g(2);
    deltaZ = z - xyz_g(3);
    
    delta=[deltaX;deltaY;deltaZ];
    F=[dx_dxi dx_deta dx_dzeta; dy_dxi dy_deta dy_dzeta; ...
       dz_dxi dz_deta dz_dzeta];
   
    invF=inv(F);
    
    ksi = ksi - invF(1,:)*delta;
    eta = eta - invF(2,:)*delta;
    zeta = zeta - invF(3,:)*delta;
    coord(1) = ksi;
    coord(2) = eta;
    coord(3) = zeta;
    
    inc = inc + 1;
end
