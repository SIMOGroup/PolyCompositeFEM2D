function stress_node=stressnode_FEMQ4(numnode,numelem,nnel,element,node,Q,U,C,elemType)

Matrix_extrapolation=[1+0.5*sqrt(3) -0.5  1-0.5*sqrt(3) -0.5;
                     -0.5  1+0.5*sqrt(3)  -0.5  1-0.5*sqrt(3);
                     1-0.5*sqrt(3)  -0.5  1+0.5*sqrt(3) -0.5;
                     -0.5  1-0.5*sqrt(3) -0.5  1+0.5*sqrt(3)];

stress_node=zeros(3,numnode);
index_numb_node=zeros(numnode,1);
for e=1:numelem                          % start of element loop
   sctr=element(e,:);           % element scatter vector
   nn=length(sctr);
   sctrB(1:2:2*nn) = 2.*sctr-1 ;
   sctrB(2:2:2*nn) = 2.*sctr   ;
   Udisp=U(sctrB);
   stress_Gauss=cell(1,size(Q,1));
   n1=0;
   for q=1:size(Q,1)                        % quadrature loop
    pt=Q(q,:);                             % quadrature point
    [N,dNdxi]=lagrange_basis(elemType,pt); % element shape functions
    J0=node(sctr,:)'*dNdxi;                % element Jacobian matrix        
    invJ0=inv(J0);
    dNdx=dNdxi*invJ0;
    B(1,1:2:2*nn-1) = dNdx(:,1)';
    B(2,2:2:2*nn)   = dNdx(:,2)';
    B(3,1:2:2*nn-1) = dNdx(:,2)';
    B(3,2:2:2*nn)  = dNdx(:,1)';
    estress=C*B*Udisp;
     n1=n1+1;
     if n1==1
        stress_Gauss{1,3}(1:3)=estress(:);            
      elseif n1==2
        stress_Gauss{1,2}(1:3)=estress(:);            
      elseif n1==3
        stress_Gauss{1,4}(1:3)=estress(:);  
      else
        stress_Gauss{1,1}(1:3)=estress(:);  
      end
   end
   
    for i=1:nnel        
        temp_M=zeros(3,1);
        for j=1:size(Q,1)
            temp_M(:) = temp_M(:) + Matrix_extrapolation(i,j) * stress_Gauss{1,j}(:);
        end
        stress_node(:,sctr(i)) = stress_node(:,sctr(i)) + temp_M(:);
        index_numb_node(sctr(i))=index_numb_node(sctr(i))+1;              
    end
end         

for i=1:numnode
    stress_node(:,i)=stress_node(:,i)/index_numb_node(i);  %unweighted average
end

% for iel=1:numelem       %loop for the total number of element
%     for i=1:nnel
%         nd(i)=nodes(iel,i);             % extract nodes for (iel)-th element
%         xcoord(i)=node(nd(i),1);      % extract x value of the node
%         ycoord(i)=node(nd(i),2);      % extract y value of the node
%     end     
%     index=feeldof(nd,nnel,ndof);  %extract system dofs for the element            
%     eldisp=U(index);
%     %---------------------
%     %numerical integration
%     %---------------------
%     stress_Gauss=cell(1,nglx*ngly);
%     nn=0;    
%     for intx=1:nglx
%         x=point2(intx,1);           %sampling point in x-axis
%         for inty=1:ngly
%             y=point2(inty,2);       %sampling point in y-axis
%             [shape,dhdr,dhds]=feisoq4(x,y,1);     %compute shape functions and derivatives at sampling point            
%             jacob2=fejacob2(nnel,dhdr,dhds,xcoord,ycoord);  %compute Jacobian            
%             invjacob=inv(jacob2);                           %inverse of Jacobian matrix            
%             [dhdx,dhdy]=federiv2(nnel,dhdr,dhds,invjacob);  %derivatives w.r.t physical coordinate            
%             kinmtx2=fekine2d(nnel,dhdx,dhdy);               %kinematic matrice            
%             
%             estrain=kinmtx2*eldisp;             % compute strains
%             estress=matmtx*estrain;             % compute stresses
%             nn=nn+1;
%             if nn==2
%                 stress_Gauss{1,4}(1:3)=estress(:);            
%             elseif nn==3
%                 stress_Gauss{1,2}(1:3)=estress(:);            
%             elseif nn==4
%                 stress_Gauss{1,3}(1:3)=estress(:);  
%             else
%                 stress_Gauss{1,1}(1:3)=estress(:);  
%             end
%         end
%     end         
%             
%     for i=1:nnel        
%         temp_M=zeros(3,1);
%         for j=1:nglx*ngly
%             temp_M(:) = temp_M(:) + Matrix_extrapolation(i,j) * stress_Gauss{1,j}(:);
%         end
%         stress_node(:,nd(i)) = stress_node(:,nd(i)) + temp_M(:);
%         index_numb_node(nd(i))=index_numb_node(nd(i))+1;              
%     end
% end

