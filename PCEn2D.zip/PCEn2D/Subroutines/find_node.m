% Returns the node id if found or -1 if not.
function [id] = find_node(xI, x)
    d = sqrt((xI(:,1)-x(1)).^2+(xI(:,2)-x(2)).^2);
    match = find(d < 1e-4);
    if isempty(match), id = -1;
    else               id = match(1);
    end
end