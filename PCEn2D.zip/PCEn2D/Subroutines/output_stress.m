function [X1,Y1,X2,Y2,Y3,Y4]= output_stress(ne,nr,R1,R2,stress,p)


for i=1:nr-1
    
    %ele=(i-1)*(ne-1)+(ne-1)/2;
    %angle=pi/2/(ne-1)*(ne-2)/2;
  
    quarter=round((ne-1)/4);    
    ele=(i-1)*(ne-1) + quarter;
    angle=pi/2/(ne-1)*(quarter*2-1)/2;  
    
    stress_R(i)=stress(1,ele)*(cos(angle)^2) + stress(2,ele)*(sin(angle)^2)+...
        2*stress(3,ele)*sin(angle)*cos(angle);
    stress_T(i)=stress(1,ele)*(sin(angle)^2) + stress(2,ele)*(cos(angle)^2)-...
        2*stress(3,ele)*sin(angle)*cos(angle);
end


%stress_R(nr)=stress_4((nr-2)*(ne-1)+1,1);
%stress_T(nr)=stress_4((nr-2)*(ne-1)+1,2);

num=1:1:nr-1;
output=[num' stress_R' stress_T'];

%---------------------------------------------------
% tinh ung suat tiep va ung suat phap theo ly thuyet
%---------------------------------------------------

%------------------------------------------------
% find yield radius rad
%------------------------------------------------
% syms c a b f t
% rad_temp=solve('log(c/a)+1/2*(1-c^2/b^2)=f/t','c');
% rad=rad_temp(1,1);
% rad=subs(rad,{a,b,f,t},{R1,R2,p,2/sqrt(3)*st(1,2)})
% sigma_rad = -p+2/sqrt(3)*st(1,2)*log(rad/R1);

%rad=R1;
%step=(R2-R1)/200;
%error=1;
%err=0.001;
%while error > err & rad <= R2
%    error=force1/(2/sqrt(3)*st(1,2))-log(rad/R1)-1/2*(1-rad^2/R2^2);
%    rad=rad+step;
%end
%rad
%sigma_rad=-load*R1^2/(R2^2-R1^2)*(R2^2/rad^2-1);

num_len=100;
X1=[];X2=[];Y1=[];Y2=[];
X3=[];X4=[];Y3=[];Y4=[];
dist=(R2-R1)/num_len;
ff_cal=p*R1^2/(R2^2-R1^2);
distan_nr =(R2-R1)/(nr-1);
    for i=1:num_len+1
        R(i)=R1+dist*(i-1);
        X2=[X2 R(i)];
        X4=[X4 R(i)];
        sigmar(i)=-ff_cal*(R2^2/R(i)^2-1);
        sigmas(i)=ff_cal*(R2^2/R(i)^2+1);
        Y2=[Y2 sigmas(i)];
        Y4=[Y4 sigmar(i)];
    end
for i=1:nr-1
   	X1=[X1 R1+(i-1+1/2)*distan_nr]; % data on x axis (data of radius coordinate)
                                    % at the middle point of 2 points 
    Y1=[Y1 stress_T(i)];            % data on y axis (data of circumferent stress of FEM solution)
end
for i=1:nr-1
   	X3=[X3 R1+(i-1+1/2)*distan_nr];  % data on x axis (data of radius coordinate)
                                     % at the middle point of 2 points 
    Y3=[Y3 stress_R(i)];             % data on y axis (data of radius stress of numerical solution)
end
figure(1);
plot(X2,Y2,'r-','LineWidth',1);  
hold on
plot(X1,Y1,'b--*','LineWidth',1);  
hold on
xlabel('Radial distance r');
ylabel('\sigma_\theta');
legend('Exact sol.','SSM');
figure(2)
plot(X4,Y4,'r-','LineWidth',1);  
hold on
plot(X3,Y3,'b--*','LineWidth',1);  
hold on
xlabel('Radial distance r');
ylabel('\sigma_r');
legend('Exact sol.','SSM');


