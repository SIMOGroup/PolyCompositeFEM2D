function xcenter = central_node(gcoord,nodes,elemType,neigh,vol_node,nodebound)
%This is to compute the area of integration domain for each node
%  Detailed explanation goes here
nnode = max(size(gcoord));
if (strcmp(elemType,'T3'))
    
%Compute the integration domain of each node
xce=[];
yce=[];
for inode=1:nnode
    xnode = [];
    ynode = [];
   for jel = 1:length(neigh{inode}(:))
        k=neigh{inode}(jel);       
        if find(inode==nodes(k,1))> 0.5
            xnode=[xnode [(gcoord(nodes(k,1),1)+gcoord(nodes(k,2),1))/2 ...
                   mean(gcoord(nodes(k,:),1)) ...
                   (gcoord(nodes(k,1),1)+gcoord(nodes(k,3),1))/2]];
            ynode=[ynode [(gcoord(nodes(k,1),2)+gcoord(nodes(k,2),2))/2 ...
                   mean(gcoord(nodes(k,:),2)) ...
                   (gcoord(nodes(k,1),2)+gcoord(nodes(k,3),2))/2]];
            % single element case       
%             if length(neigh{inode}(:))==1
%                 xnode=[gcoord(nodes(k,1),1) xnode];
%                 ynode=[gcoord(nodes(k,1),2) ynode];
%             end    
        elseif find(inode==nodes(k,2))> 0.5
            xnode=[xnode [(gcoord(nodes(k,2),1)+gcoord(nodes(k,3),1))/2 ...
                   mean(gcoord(nodes(k,:),1)) ...
                   (gcoord(nodes(k,2),1)+gcoord(nodes(k,1),1))/2]];
            ynode=[ynode [(gcoord(nodes(k,2),2)+gcoord(nodes(k,3),2))/2 ...
                   mean(gcoord(nodes(k,:),2)) ...
                   (gcoord(nodes(k,2),2)+gcoord(nodes(k,1),2))/2]];
            % single element case    
%             if length(neigh{inode}(:))==1
%                 xnode=[gcoord(nodes(k,2),1) xnode];
%                 ynode=[gcoord(nodes(k,2),2) ynode];
%             end    
        else% if find(inode==nodes(k,3))> 0.5
            xnode=[xnode [(gcoord(nodes(k,3),1)+gcoord(nodes(k,1),1))/2 ...
                   mean(gcoord(nodes(k,:),1)) ...
                   (gcoord(nodes(k,3),1)+gcoord(nodes(k,2),1))/2]];
            ynode=[ynode [(gcoord(nodes(k,3),2)+gcoord(nodes(k,1),2))/2 ...
                   mean(gcoord(nodes(k,:),2)) ...
                   (gcoord(nodes(k,3),2)+gcoord(nodes(k,2),2))/2]];
           % single element case    
%            if length(neigh{inode}(:))==1
%                 xnode=[gcoord(nodes(k,3),1) xnode];
%                 ynode=[gcoord(nodes(k,3),2) ynode];
%             end    
        end
   end
   for i=1:length(nodebound)
       if inode==nodebound(i)
         xnode=[gcoord(inode,1) xnode];
         ynode=[gcoord(inode,2) ynode];
       end
   end
   xnode=[xnode xnode(1)];
   ynode=[ynode ynode(1)];
   
   xc=0;
   yc=0;
   for i=1:length(xnode)-1
    xc=xc+(xnode(i)+xnode(i+1))*(xnode(i)*ynode(i+1)-xnode(i+1)*ynode(i));
    yc=yc+(ynode(i)+ynode(i+1))*(xnode(i)*ynode(i+1)-xnode(i+1)*ynode(i));
   end
   xc=xc/(6*vol_node(inode));
   yc=yc/(6*vol_node(inode));
   
   xce=[xce xc];
   yce=[yce yc];
end
 xcenter=[xce' yce'];
else
 disp('integral cell type is not implemented');
 return
end  