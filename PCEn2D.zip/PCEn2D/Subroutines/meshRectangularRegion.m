% =======================================================================
% function [node,element] = meshRectangularRegion(L,D/2,numx,numy,elemType)
%
% elemType : element type 'PARTICLE','T3','T4','T6','Q4','Q8','Q9' 
% GOAL :
% Generate the nodal coordinates (node) and connectivity (element) for a
% rectangular region given the four corners pti, the number of nodes in
% each direction (numx+1,numy+1), the element type 
%
% =======================================================================
% 
% Modify be Hung Nguyen Xuan March 26 2009
% SMA
% =======================================================================
function [nnx,nny,node,element] = meshRectangularRegion(L,c,numx,numy,elemType)

% obtain number of elements from number of nodes
switch elemType
    case 'PARTICLE' % generate the mesh for particles
       nnx=numx+1;
       nny=numy+1;
        % NOTE : for now, does just like a Q4
        % in actuality, the element returned by make_elem is just dummy and
        % is to be used nowhere. only kept so that element is returned and
        % all output arguments are defined when function returns.
        % SB.2004.12.01
        node=square_node_array([0 -c],[L -c],[L c],[0 c],nnx,nny);
        inc_u=1;
        inc_v=nnx;
        node_pattern=[ 1 2 nnx+2 nnx+1 ];
        [element]=make_elem(node_pattern,numx,numy,inc_u,inc_v);
        
 case 'Q4'           % here we generate the mesh of Q4 elements
   nnx=numx+1;
   nny=numy+1;
   node=square_node_array([0 -c],[L -c],[L c],[0 c],nnx,nny);
   
   inc_u=1;
   inc_v=nnx;
   node_pattern=[ 1 2 nnx+2 nnx+1 ];
   
   element=make_elem(node_pattern,numx,numy,inc_u,inc_v);
 case 'Q8'
  nnx=2*numx+1;
  nny=2*numy+1;
 for j=1:numy+1
   for i=1:numx+1
      node((3*numx+2)*(j-1)+(2*i-1),1)=(L/numx)*(i-1);
      node((3*numx+2)*(j-1)+(2*i-1),2)=-c+(2*c/numy)*(j-1);
   end
 end
index=1;
for i=1:numy
    for k=1:numx
        element(index,1)=(3*numx+2)*(i-1)+(2*k-1); 
        element(index,2)=(3*numx+2)*(i-1)+(2*k+1); 
        element(index,3)=(3*numx+2)*i+(2*k+1);
        element(index,4)=(3*numx+2)*i+(2*k-1);
        element(index,5)=(element(index,2)+element(index,1))/2; 
        element(index,6)=(3*numx+2)*i-numx + k; 
        element(index,7)=(element(index,3)+element(index,4))/2;
        element(index,8)=(3*numx+2)*i-(numx+1)+ k;  
        index=index+1;
    end
end
for i=1:size(element,1)
    node(element(i,5),:)=(node(element(i,1),:)+node(element(i,2),:))/2;
    node(element(i,6),:)=(node(element(i,2),:)+node(element(i,3),:))/2;
    node(element(i,7),:)=(node(element(i,3),:)+node(element(i,4),:))/2;
    node(element(i,8),:)=(node(element(i,4),:)+node(element(i,1),:))/2;
end
case 'Q9'           % here we generate a mehs of Q9 elements
   nnx=2*numx+1;
   nny=2*numy+1;
   node=square_node_array([0 -c],[L -c],[L c],[0 c],nnx,nny);
   
   inc_u=2;
   inc_v=2*nnx;
   node_pattern=[ 1 3 2*nnx+3 2*nnx+1 2 nnx+3 2*nnx+2 nnx+1 nnx+2 ];
   
   element=make_elem(node_pattern,numx,numy,inc_u,inc_v);
 
case 'T6'           % here we generate a mehs of Q9 elements
   nnx=2*numx+1;
   nny=2*numy+1;
   node=square_node_array([0 -c],[L -c],[L c],[0 c],nnx,nny);
   
   inc_u=2;
   inc_v=2*nnx;
   node_pattern1=[ 1 3 2*nnx+1 2 nnx+2 nnx+1];
   node_pattern2=[ 3 2*nnx+3 2*nnx+1 nnx+3 2*nnx+2 nnx+2];
   element=[make_elem(node_pattern1,numx,numy,inc_u,inc_v);
            make_elem(node_pattern2,numx,numy,inc_u,inc_v)];
case 'T4'           % here we generate a mehs of Q9 elements
   nnx=numx+1;
   nny=numy+1;
   node=square_node_array([0 -c],[L -c],[L c],[0 c],nnx,nny);
   
   node_pattern1=[ 1 2 nnx+1 ];
   node_pattern2=[ 2 nnx+2 nnx+1 ];
   inc_u=1;
   inc_v=nnx;
   
   element=[make_elem(node_pattern1,numx,numy,inc_u,inc_v);
            make_elem(node_pattern2,numx,numy,inc_u,inc_v) ];
   nel=size(element,1);     
   nnode=size(node,1);
   for ie=1:nel
       element(ie,4)=nnode+ie;
   end
   for ie=1:nel
       node(nnode+ie,1)=mean(node(element(ie,1:3),1));
       node(nnode+ie,2)=mean(node(element(ie,1:3),2));
   end
 case 'T3'
   nnx=numx+1;
   nny=numy+1;
   node=square_node_array([0 -c],[L -c],[L c],[0 c],nnx,nny);
   
   node_pattern1=[ 1 2 nnx+1 ];
   node_pattern2=[ 2 nnx+2 nnx+1 ];
   inc_u=1;
   inc_v=nnx;
   
   element=[make_elem(node_pattern1,numx,numy,inc_u,inc_v);
            make_elem(node_pattern2,numx,numy,inc_u,inc_v) ];
  otherwise
        error('For now, only PARTICLE, Q4, Q8, Q9,T4,T6 and T3 are supported by the mesh generator');
end
