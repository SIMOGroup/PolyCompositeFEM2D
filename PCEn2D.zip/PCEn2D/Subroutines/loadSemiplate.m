function f=loadSemiplate(node,bcnode,A,p0,n1,f)

nu=length(bcnode{1});          % upper surface
for i=1:nu
    n=bcnode{1}(i); c3=1;
    if i==1 | i==nu
        c3=0.5;
    end
    f(2*n)=p0*c3*A/n1;
end

nr=length(bcnode{3});          % right surface
for i=1:nr
    n=bcnode{3}(i); 
    x=node(n,1); y=node(n,2);
    if i==1
        n2=bcnode{3}(i+1);
        dy=abs(y-node(n2,2))/2;
    elseif i==nr
        n0=bcnode{3}(i-1);
        dy=abs(y-node(n0,2))/2;
    else
        n0=bcnode{3}(i-1); n2=bcnode{3}(i+1);
        dy=abs(node(n0,2)-node(n2,2))/2;
    end
    if abs(y)<1e-12
        theta1=pi/2; theta2=pi/2;
    else
        theta1=atan(-(x+A)/y);      theta2=atan(-(x-A)/y);
    end
  
    s11=p0*(2*(theta1-theta2)-sin(2*theta1)+sin(2*theta2))/2/pi;
    s12=p0*(cos(2*theta1)-cos(2*theta2))/2/pi;
    
    f(2*n-1)=s11*dy;
    f(2*n)=s12*dy;
end