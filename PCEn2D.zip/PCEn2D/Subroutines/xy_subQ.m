function [xd,yd]=xy_subQ(elemType,num_sub,sub_elem,iel)

global node element;

sctr=element(iel,:);
switch elemType  % define cell
case 'Q8'
if num_sub==1
    xd=node(sctr(1:4),1);
    yd=node(sctr(1:4),2);
elseif num_sub==2
    if sub_elem==1
        xd=[node(sctr(1),1) node(sctr(5),1) node(sctr(7),1) node(sctr(4),1)];
        yd=[node(sctr(1),2) node(sctr(5),2) node(sctr(7),2) node(sctr(4),2)];
    else % sub elem==2
        xd=[node(sctr(5),1) node(sctr(2),1) node(sctr(3),1) node(sctr(7),1)];
        yd=[node(sctr(5),2) node(sctr(2),2) node(sctr(3),2) node(sctr(7),2)];
    end
elseif num_sub==3
    xy_5=node(sctr(5),:);
    xy_6=node(sctr(6),:);
    xy_7=node(sctr(7),:);
    xy_9 =mean(node(sctr,:));
    if sub_elem==1
        xd=[node(sctr(1),1) xy_5(1) xy_7(1) node(sctr(4),1)];
        yd=[node(sctr(1),2) xy_5(2) xy_7(2) node(sctr(4),2)];
    elseif sub_elem==2
        xd=[xy_5(1) node(sctr(2),1) xy_6(1) xy_9(1)];
        yd=[xy_5(2) node(sctr(2),2) xy_6(2) xy_9(2)];
    else
       xd=[xy_9(1) xy_6(1) node(sctr(3),1) xy_7(1)];
       yd=[xy_9(2) xy_6(2) node(sctr(3),2) xy_7(2)]; 
    end
    
elseif num_sub==4
    xy_5=node(sctr(5),:);
    xy_6=node(sctr(6),:);
    xy_7=node(sctr(7),:);
    xy_8=node(sctr(8),:);
    xy_9 =mean(node(sctr,:));
    if sub_elem==1
        xd=[node(sctr(1),1) xy_5(1) xy_9(1) xy_8(1)];
        yd=[node(sctr(1),2) xy_6(2) xy_9(2) xy_8(2)];
    elseif sub_elem==2
        xd=[xy_5(1) node(sctr(2),1) xy_6(1) xy_9(1)];
        yd=[xy_5(2) node(sctr(2),2) xy_6(2) xy_9(2)];
    elseif sub_elem==3
        xd=[xy_9(1) xy_6(1) node(sctr(3),1) xy_7(1)];
        yd=[xy_9(2) xy_6(2) node(sctr(3),2) xy_7(2)];
    else
        xd=[xy_8(1) xy_9(1) xy_7(1) node(sctr(4),1)];
        yd=[xy_8(2) xy_9(2) xy_7(2) node(sctr(4),2)];
    end
else
   disp('Number smoothing cells of element are not implemented');
   return
end  

case 'Q9'
  if num_sub==1
    xd=node(sctr(1:4),1);
    yd=node(sctr(1:4),2);
elseif num_sub==2
    xy_5=node(sctr(5),:);
    xy_7=node(sctr(7),:);
    if sub_elem==1
        xd=[node(sctr(1),1) xy_5(1) xy_7(1) node(sctr(4),1)];
        yd=[node(sctr(1),2) xy_5(2) xy_7(2) node(sctr(4),2)];
    else % sub elem==2
        xd=[xy_5(1) node(sctr(2),1) node(sctr(3),1) xy_7(1)];
        yd=[xy_5(2) node(sctr(2),2) node(sctr(3),2) xy_7(2)];
    end
elseif num_sub==3
    xy_5=node(sctr(5),:);
    xy_6=node(sctr(6),:);
    xy_7=node(sctr(7),:);
    xy_9 =node(sctr(9),:);
    if sub_elem==1
        xd=[node(sctr(1),1) xy_5(1) xy_7(1) node(sctr(4),1)];
        yd=[node(sctr(1),2) xy_5(2) xy_7(2) node(sctr(4),2)];
    elseif sub_elem==2
        xd=[xy_5(1) node(sctr(2),1) xy_6(1) xy_9(1)];
        yd=[xy_5(2) node(sctr(2),2) xy_6(2) xy_9(2)];
    else
       xd=[xy_9(1) xy_6(1) node(sctr(3),1) xy_7(1)];
       yd=[xy_9(2) xy_6(2) node(sctr(3),2) xy_7(2)]; 
    end
    
elseif num_sub==4
    xy_5=node(sctr(5),:);
    xy_6=node(sctr(6),:);
    xy_7=node(sctr(7),:);
    xy_8=node(sctr(8),:);
    xy_9 =node(sctr(9),:);
    if sub_elem==1
        xd=[node(sctr(1),1) xy_5(1) xy_9(1) xy_8(1)];
        yd=[node(sctr(1),2) xy_6(2) xy_9(2) xy_8(2)];
    elseif sub_elem==2
        xd=[xy_5(1) node(sctr(2),1) xy_6(1) xy_9(1)];
        yd=[xy_5(2) node(sctr(2),2) xy_6(2) xy_9(2)];
    elseif sub_elem==3
        xd=[xy_9(1) xy_6(1) node(sctr(3),1) xy_7(1)];
        yd=[xy_9(2) xy_6(2) node(sctr(3),2) xy_7(2)];
    else
        xd=[xy_8(1) xy_9(1) xy_7(1) node(sctr(4),1)];
        yd=[xy_8(2) xy_9(2) xy_7(2) node(sctr(4),2)];
    end
else
   disp('Number smoothing cells of element are not implemented');
   return
  end  
  
case 'T4'
if num_sub==1
    xd=node(sctr(1:4),1);
    yd=node(sctr(1:4),2);
else %num_sub==3
    if sub_elem==1
        xd=[node(sctr(1),1) node(sctr(2),1) node(sctr(4),1)];
        yd=[node(sctr(1),2) node(sctr(2),2) node(sctr(4),2)];
    elseif sub_lem==2
        xd=[node(sctr(2),1) node(sctr(3),1) node(sctr(4),1)];
        yd=[node(sctr(2),2) node(sctr(3),2) node(sctr(4),2)];
    else
        xd=[node(sctr(3),1) node(sctr(1),1) node(sctr(4),1)];
        yd=[node(sctr(3),2) node(sctr(1),2) node(sctr(4),2)];
    end
end
case 'T6'
if num_sub==1
    xd=node(sctr(1:6),1);
    yd=node(sctr(1:6),2);
else %num_sub==3
    if sub_elem==1
        xd=[node(sctr(1),1) node(sctr(2),1) mean(node(sctr(1:3),1))];
        yd=[node(sctr(1),2) node(sctr(2),2) mean(node(sctr(1:3),2))];
    elseif sub_lem==2
        xd=[node(sctr(2),1) node(sctr(3),1) mean(node(sctr(1:3),1))];
        yd=[node(sctr(2),2) node(sctr(3),2) mean(node(sctr(1:3),2))];
    else
        xd=[node(sctr(3),1) node(sctr(1),1) mean(node(sctr(1:3),1))];
        yd=[node(sctr(3),2) node(sctr(1),2) mean(node(sctr(1:3),2))];
    end
end
case 'Q4'
  if num_sub==1
    xd=node(sctr,1);
    yd=node(sctr,2);
elseif num_sub==2
    xy_m1=mean(node(sctr([1 2]),:));
    xy_m2=mean(node(sctr([3 4]),:));
    if sub_elem==1
        xd=[node(sctr(1),1) xy_m1(1) xy_m2(1) node(sctr(4),1)]';
        yd=[node(sctr(1),2) xy_m1(2) xy_m2(2) node(sctr(4),2)]';
    else % sub elem==2
        xd=[xy_m1(1) node(sctr(2),1) node(sctr(3),1) xy_m2(1)]';
        yd=[xy_m1(2) node(sctr(2),2) node(sctr(3),2) xy_m2(2)]';
    end
elseif num_sub==4
    xy_m1=mean(node(sctr([1 2]),:));
    xy_m2=mean(node(sctr([2 3]),:));
    xy_m3=mean(node(sctr([3 4]),:));
    xy_m4=mean(node(sctr([4 1]),:));
    xy_m =mean(node(sctr,:));
    if sub_elem==1
        xd=[node(sctr(1),1) xy_m1(1) xy_m(1) xy_m4(1)]';
        yd=[node(sctr(1),2) xy_m1(2) xy_m(2) xy_m4(2)]';
    elseif sub_elem==2
        xd=[xy_m1(1) node(sctr(2),1) xy_m2(1) xy_m(1)]';
        yd=[xy_m1(2) node(sctr(2),2) xy_m2(2) xy_m(2)]';
    elseif sub_elem==3
        xd=[xy_m(1) xy_m2(1) node(sctr(3),1) xy_m3(1)]';
        yd=[xy_m(2) xy_m2(2) node(sctr(3),2) xy_m3(2)]';
    else %sub_elem==4
        xd=[xy_m4(1) xy_m(1) xy_m3(1) node(sctr(4),1)]';
        yd=[xy_m4(2) xy_m(2) xy_m3(2) node(sctr(4),2)]';
    end
 else
   disp('Number smoothing cells of element are not implemented');
   return
  end 
case 'Qm6'
  if num_sub==1
    xd=node(sctr,1);
    yd=node(sctr,2);
elseif num_sub==2
    xy_m1=mean(node(sctr([1 2]),:));
    xy_m2=mean(node(sctr([3 4]),:));
    if sub_elem==1
        xd=[node(sctr(1),1) xy_m1(1) xy_m2(1) node(sctr(4),1)]';
        yd=[node(sctr(1),2) xy_m1(2) xy_m2(2) node(sctr(4),2)]';
    else % sub elem==2
        xd=[xy_m1(1) node(sctr(2),1) node(sctr(3),1) xy_m2(1)]';
        yd=[xy_m1(2) node(sctr(2),2) node(sctr(3),2) xy_m2(2)]';
    end
elseif num_sub==4
    xy_m1=mean(node(sctr([1 2]),:));
    xy_m2=mean(node(sctr([2 3]),:));
    xy_m3=mean(node(sctr([3 4]),:));
    xy_m4=mean(node(sctr([4 1]),:));
    xy_m =mean(node(sctr,:));
    if sub_elem==1
        xd=[node(sctr(1),1) xy_m1(1) xy_m(1) xy_m4(1)]';
        yd=[node(sctr(1),2) xy_m1(2) xy_m(2) xy_m4(2)]';
    elseif sub_elem==2
        xd=[xy_m1(1) node(sctr(2),1) xy_m2(1) xy_m(1)]';
        yd=[xy_m1(2) node(sctr(2),2) xy_m2(2) xy_m(2)]';
    elseif sub_elem==3
        xd=[xy_m(1) xy_m2(1) node(sctr(3),1) xy_m3(1)]';
        yd=[xy_m(2) xy_m2(2) node(sctr(3),2) xy_m3(2)]';
    else %sub_elem==4
        xd=[xy_m4(1) xy_m(1) xy_m3(1) node(sctr(4),1)]';
        yd=[xy_m4(2) xy_m(2) xy_m3(2) node(sctr(4),2)]';
    end
 else
   disp('Number smoothing cells of element are not implemented');
   return
  end   
otherwise
  disp('Element type is not implemented');
   return
end


