function [err]=error_num_ana(U_analysis,U_num)

nU=length(U_analysis);

err1=0;
err2=0;
erra=0;
errb=0;
for i=1:nU
    erra=erra+abs(U_analysis(i)-U_num(i));
    err1=err1+(U_analysis(i)-U_num(i))^2;
    err2=err2+U_analysis(i)^2;
    errb=errb+abs(U_analysis(i));
end
%erra
%err=sqrt(err1)/sqrt(err2)*100;
err=erra/errb*100;