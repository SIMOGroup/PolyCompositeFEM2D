function [intarea, area ] = intdomain(gcoord,nodes)
%This is to compute the area of integration domain for each node
%  Detailed explanation goes here

nel = size(nodes,1);
nnode = max(size(gcoord));
%Compute the area of each triangle
for i = 1:nel
    x0 = gcoord(nodes(i,1),1);
    y0 = gcoord(nodes(i,1),2);
    x1 = gcoord(nodes(i,2),1);
    y1 = gcoord(nodes(i,2),2);
    x2 = gcoord(nodes(i,3),1);
    y2 = gcoord(nodes(i,3),2);
    la=sqrt((x0-x1)*(x0-x1)+(y0-y1)*(y0-y1));      % side length
    lb=sqrt((x0-x2)*(x0-x2)+(y0-y2)*(y0-y2));
    lc=sqrt((x2-x1)*(x2-x1)+(y2-y1)*(y2-y1)); 
    p=(la+lb+lc)/2;
    S=sqrt(p*(p-la)*(p-lb)*(p-lc));
    area(i) = S;
end

%Compute the integration domain of each node
intarea = zeros(nnode,1);
for i=1:nnode
    for j = 1:nel
        if find(i==nodes(j,:))> 0.5
            intarea(i) = intarea(i)+area(j)/3;
        end
    end
end

return
