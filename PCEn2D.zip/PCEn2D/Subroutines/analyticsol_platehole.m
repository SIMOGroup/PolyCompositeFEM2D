function [ue,estress0]=analyticsol_platehole(x,y,emodu,poiss,R)

tol=1e-12;
% dtot=0;  tot=0;  ipx=0; ipy=0;
G=emodu/(1+poiss)/2;
a2=R*R;    r2=x*x+y*y;
a4=a2*a2;  r4=r2*r2;
r=sqrt(r2);
s1=y/r; c1=x/r;        % note that r is always positive (nonzero)!
s2=2*s1*c1; c2=2*c1*c1-1;
ur=((1-2*poiss+c2)+(1+4*(1-poiss)*c2)*a2/r2-a4*c2/r4)*r/(4*G); % for plane strain
ut=((4*poiss-2)*a2/r2-1-a4/r4)*s2*r/(4*G);
ux=c1*ur-s1*ut;
vy=s1*ur+c1*ut;
ue=[ux;vy];

if (abs(x))<tol
   if y>0  
       theta=pi/2;
   else
       theta=-pi/2;
   end
else
       theta=atan(y/x);
end
c2=cos(2*theta);    c4=cos(4*theta);
s2=sin(2*theta);    s4=sin(4*theta);

sigmax=1-(1.5*c2+c4)*a2/r2+1.5*c4*a4/(r4);
sigmay=-(c2/2-c4)*a2/r2-1.5*c4*a4/(r4);
sigmaxy=-(0.5*s2+s4)*a2/r2+1.5*s4*a4/(r4);
estress0=[sigmax; sigmay; sigmaxy];

% G=emodu/(1+poiss)/2;
% a2=R*R; a4=a2*a2;
% %x0=x; y0=y;
% r2=x*x+y*y; r4=r2*r2;
% r=sqrt(r2);
% s1=y/r; c1=x/r;        % note that r is always positive (nonzero)!
% s2=2*s1*c1; c2=2*c1*c1-1;
% c4=c2*c2-s2*s2;
% s4=2*s2*c2;
% ur=((1-2*poiss+c2)+(1+4*(1-poiss)*c2)*a2/r2-a4*c2/r4)*r/(4*G); % for plane strain
% ut=((4*poiss-2)*a2/r2-1-a4/r4)*s2*r/(4*G);
% u0=c1*ur-s1*ut;
% v0=s1*ur+c1*ut;
% sigxx0= 1-a2*(3*c2/2+c4)/r2+3*a4*c4/(2*r4);
% sigyy0= -a2*(0.5*c2-c4)/r2-3*a4*c4/(2*r4);
% sigxy0= -a2*(0.5*s2+s4)/r2+3*a4*s4/(2*r4);     
% ue=[u0;v0];
% estress0=[sigxx0;sigyy0;sigxy0];
