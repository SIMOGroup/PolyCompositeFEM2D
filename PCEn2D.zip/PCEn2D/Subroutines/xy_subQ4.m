function [xd,yd]=xy_subQ4(num_sub,sub_elem,iel)

global node element

sctr=element(iel,:);
if num_sub==1
    xd=node(sctr,1);
    yd=node(sctr,2);
elseif num_sub==2
    xy_m1=mean(node(sctr([1 2]),:));
    xy_m2=mean(node(sctr([3 4]),:));
    if sub_elem==1
        xd=[node(sctr(1),1) xy_m1(1) xy_m2(1) node(sctr(4),1)]';
        yd=[node(sctr(1),2) xy_m1(2) xy_m2(2) node(sctr(4),2)]';
    else % sub elem==2
        xd=[xy_m1(1) node(sctr(2),1) node(sctr(3),1) xy_m2(1)]';
        yd=[xy_m1(2) node(sctr(2),2) node(sctr(3),2) xy_m2(2)]';
    end
elseif num_sub==4
    xy_m1=mean(node(sctr([1 2]),:));
    xy_m2=mean(node(sctr([2 3]),:));
    xy_m3=mean(node(sctr([3 4]),:));
    xy_m4=mean(node(sctr([4 1]),:));
    xy_m =mean(node(sctr,:));
    if sub_elem==1
        xd=[node(sctr(1),1) xy_m1(1) xy_m(1) xy_m4(1)]';
        yd=[node(sctr(1),2) xy_m1(2) xy_m(2) xy_m4(2)]';
    elseif sub_elem==2
        xd=[xy_m1(1) node(sctr(2),1) xy_m2(1) xy_m(1)]';
        yd=[xy_m1(2) node(sctr(2),2) xy_m2(2) xy_m(2)]';
    elseif sub_elem==3
        xd=[xy_m(1) xy_m2(1) node(sctr(3),1) xy_m3(1)]';
        yd=[xy_m(2) xy_m2(2) node(sctr(3),2) xy_m3(2)]';
    else %sub_elem==4
        xd=[xy_m4(1) xy_m(1) xy_m3(1) node(sctr(4),1)]';
        yd=[xy_m4(2) xy_m(2) xy_m3(2) node(sctr(4),2)]';
    end
 else
   disp('Number smoothing cells of element are not implemented');
   return
end 

