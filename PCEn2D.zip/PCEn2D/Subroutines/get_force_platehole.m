function [ff]=get_force_platehole(nx,ny,a,xd,yd)

% Note: ff should be cleared to zeros! Node numbering accords to main
%      program.

sdof=(nx+1)*(ny+1)*2;
ff=zeros(sdof,1);       % system mechanical force vector

dang=pi/(2*nx);
a2=a*a;
a4=a2*a2;
sigx=zeros(1,nx+1);
sigxy=zeros(1,nx+1);

for i=1:nx+1
   ndi=1+(ny+1)*(i-1);
   ndi2=1+(ny+1)*i;
   if i<nx+1
      d1=(xd(ndi2)-xd(ndi))*(xd(ndi2)-xd(ndi));
      d1=d1+(yd(ndi2)-yd(ndi))*(yd(ndi2)-yd(ndi));
      dist(i)=sqrt(d1);
   end
       
   r2=xd(ndi)*xd(ndi)+yd(ndi)*yd(ndi);
   r4=r2*r2;
   ang=pi/2-(i-1)*dang;
   
   c2=cos(ang)*cos(ang)-sin(ang)*sin(ang);
   s2=2*sin(ang)*cos(ang);
   c4=c2*c2-s2*s2;
   s4=2*s2*c2;
   
   if (i<=nx/2+1)
      sigy(i)=-a2*(0.5*c2-c4)/r2-3*a4*c4/(2*r4);
    %  sigyx(i)=-a2*(0.5*s2+s4)/r2+3*a4*s4/(2*r4);
      sigyx(i)=-a2*(0.5*s2+s4)/r2+3*a4*s4/(2*r4);
   end
   if (i>=nx/2+1)
      sigx(i)=1-a2*(3*c2/2+c4)/r2+3*a4*c4/(2*r4);
    %  sigxy(i)=-a2*(0.5*s2+s4)/r2+3*a4*s4/(2*r4);
      sigxy(i)=-a2*(0.5*s2+s4)/r2+3*a4*s4/(2*r4);
 end
end

ff(1)=(sigyx(1)+sigyx(2))*dist(1)/4;
ff(2)=(sigy(1)+sigy(2))*dist(1)/4;

for i=2:nx/2
   ndi=1+(ny+1)*(i-1);
   ff(2*ndi-1)=(sigyx(i-1)+sigyx(i))*dist(i-1)/4+ ...
               (sigyx(i)+sigyx(i+1))*dist(i)/4;
   ff(2*ndi)=(sigy(i-1)+sigy(i))*dist(i-1)/4+ ...
               (sigy(i)+sigy(i+1))*dist(i)/4;
end
         
nc=1+(ny+1)*nx/2;
n1=nx/2+1;
ff(2*nc-1)=(sigx(n1)+sigx(n1+1))*dist(n1)/4+ ...
         (sigyx(n1)+sigyx(n1-1))*dist(n1-1)/4;
ff(2*nc)=(sigxy(n1)+sigxy(n1+1))*dist(n1)/4+ ...
         (sigy(n1)+sigy(n1-1))*dist(n1-1)/4;
   
for i=n1+1:nx
   ndi=1+(ny+1)*(i-1);
   ff(2*ndi-1)=(sigx(i-1)+sigx(i))*dist(i-1)/4+ ...
               (sigx(i)+sigx(i+1))*dist(i)/4;
   ff(2*ndi)=(sigxy(i-1)+sigxy(i))*dist(i-1)/4+ ...
      (sigxy(i)+sigxy(i+1))*dist(i)/4;
end

nl=1+(ny+1)*nx;
ff(2*nl-1)=(sigx(nx)+sigx(nx+1))*dist(nx)/4;
ff(2*nl)=(sigxy(nx)+sigxy(nx+1))*dist(nx)/4;

return
      
      
   
