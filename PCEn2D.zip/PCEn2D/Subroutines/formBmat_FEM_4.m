function [nodL,BL] = formBmat_FEM_4(neighbour,nodes,gcoord,supp,area,ia,quadarea)
%This program form the B matrix for beam problem 
%with FEM formulation
%R =1 for plane stress; R =2 for plane strain;
% area is the area of subdomain
%*****************************************************
%The integration is divided into different sub-domains
%*****************************************************
%neighbour
nc = length(neighbour); %number of neighbouring cells corresponding to index of element

for i = 1:nc
    kcc = neighbour(i);
    n1 = nodes(kcc,1);
    n2 = nodes(kcc,2);
    n3 = nodes(kcc,3);
    n4 = nodes(kcc,4);
%     xx1 = gcoord(n1,1); yy1 = gcoord(n1,2);
%     xx2 = gcoord(n2,1); yy2 = gcoord(n2,2);
%     xx3 = gcoord(n3,1); yy3 = gcoord(n3,2);
%     xx4 = gcoord(n4,1); yy4 = gcoord(n4,2);
    xm1 = (gcoord(n1,1)+gcoord(n2,1))/2; ym1 = (gcoord(n1,2)+gcoord(n2,2))/2;
    xm2 = (gcoord(n2,1)+gcoord(n3,1))/2; ym2 = (gcoord(n2,2)+gcoord(n3,2))/2;
    xm3 = (gcoord(n3,1)+gcoord(n4,1))/2; ym3 = (gcoord(n3,2)+gcoord(n4,2))/2;
    xm4 = (gcoord(n4,1)+gcoord(n1,1))/2; ym4 = (gcoord(n4,2)+gcoord(n1,2))/2;
    xm5 = (gcoord(n1,1)+gcoord(n2,1)+gcoord(n3,1)+gcoord(n4,1))/4;
    ym5 = (gcoord(n1,2)+gcoord(n2,2)+gcoord(n3,2)+gcoord(n4,2))/4;
    
    %Calculate the outward normals of the four mid-line
    xL1 = sqrt(((xm1-xm5)^2+(ym1-ym5)^2));
    onx11 = (ym5-ym1)/xL1; ony11 = (xm1-xm5)/xL1;
    onx12 = -onx11; ony12 = -ony11;
    
    xL2 = sqrt(((xm2-xm5)^2+(ym2-ym5)^2));
    onx22 = (ym5-ym2)/xL2; ony22 = (xm2-xm5)/xL2;
    onx23 = -onx22; ony23 = -ony22;
    
    xL3 = sqrt(((xm3-xm5)^2+(ym3-ym5)^2));
    onx33 = (ym5-ym3)/xL3; ony33 = (xm3-xm5)/xL3;
    onx34 = -onx33; ony34 = -ony33;
    
    xL4 = sqrt(((xm4-xm5)^2+(ym4-ym5)^2));
    onx44 = (ym5-ym4)/xL4; ony44 = (xm4-xm5)/xL4;
    onx41 = -onx44; ony41 = -ony44;
    %two segments of mid-line for each node
    if ia == n1
        onxy(1,1)= onx11; onxy(1,2) = ony11;
        onxy(2,1)= onx41; onxy(2,2) = ony41;
        xgg(1,1) = xm1; xgg(1,2) = ym1;
        xgg(2,1) = xm5; xgg(2,2) = ym5;
        xgg(3,1) = xm4; xgg(3,2) = ym4;   
        shape=[1/2 1/2 0 0;1/4 1/4 1/4 1/4;1/2 0 0 1/2;1 0 0 0];  
    elseif ia == n2
        onxy(1,1)= onx22; onxy(1,2) = ony22;
        onxy(2,1)= onx12; onxy(2,2) = ony12;
        xgg(1,1) = xm2; xgg(1,2) = ym2;
        xgg(2,1) = xm5; xgg(2,2) = ym5;
        xgg(3,1) = xm1; xgg(3,2) = ym1;
        shape=[0 1/2 1/2 0;1/4 1/4 1/4 1/4;1/2 1/2 0 0;0 1 0 0];   
    elseif ia == n3
        onxy(1,1)= onx33; onxy(1,2) = ony33;
        onxy(2,1)= onx23; onxy(2,2) = ony23;
        xgg(1,1) = xm3; xgg(1,2) = ym3;
        xgg(2,1) = xm5; xgg(2,2) = ym5;
        xgg(3,1) = xm2; xgg(3,2) = ym2;
        shape=[0 0 1/2 1/2;1/4 1/4 1/4 1/4;0 1/2 1/2 0;0 0 1 0];  
    else
        onxy(1,1)= onx44; onxy(1,2) = ony44;
        onxy(2,1)= onx34; onxy(2,2) = ony34;
        xgg(1,1) = xm4; xgg(1,2) = ym4;
        xgg(2,1) = xm5; xgg(2,2) = ym5;
        xgg(3,1) = xm3; xgg(3,2) = ym3;
        shape=[1/2 0 0 1/2;1/4 1/4 1/4 1/4;0 0 1/2 1/2;0 0 0 1];  
    end
    xgg(4,:) = gcoord(ia,:);
    xL4 = sqrt((xgg(4,1)-xgg(3,1))^2+(xgg(4,2)-xgg(3,2))^2);
    onxy(3,1) = (xgg(4,2)-xgg(3,2))/xL4; onxy(3,2) = (xgg(3,1)-xgg(4,1))/xL4;
    
    xL5 = sqrt((xgg(4,1)-xgg(1,1))^2+(xgg(4,2)-xgg(1,2))^2);
    onxy(4,1) = (xgg(1,2)-xgg(4,2))/xL5; onxy(4,2) = (xgg(4,1)-xgg(1,1))/xL5;
    % loop on the two segments in cell kcc against node ia       
    
    nnodes=[1 2 3 4];
    for i2 = 1:4 % loop on each subcell
        clear norm phi weight phi1
        nx = onxy(i2,1); ny = onxy(i2,2);
        if i2 ==4 %last edge of cell
            xcent = (xgg(1,:)+xgg(4,:))/2; %Gauss point 
            weight = sqrt((xgg(1,1)-xgg(4,1))^2+(xgg(1,2)-xgg(4,2))^2);
        else 
            xcent = (xgg(i2,:)+xgg(i2+1,:))/2; %Gauss point 
            weight = sqrt((xgg(i2,1)-xgg(i2+1,1))^2+(xgg(i2+1,2)-xgg(i2,2))^2);
        end
         xsupp = supp{neighbour(i)}; % support node numbering
        
        if i2==4
            for j=1:4
                phi1(j)=1/2*(shape(nnodes(i2),j)+shape(nnodes(i2-3),j));
            end
        else
            for j=1:4
                phi1(j)=1/2*(shape(nnodes(i2),j)+shape(nnodes(i2+1),j));
            end
        end           
        
        %norm=([nx 0; 0 ny; ny nx])*weight/quadarea(kcc)/3; % CHange to Garlekin formulation of B matrix
        norm=([nx 0; 0 ny; ny nx])*weight/area; % CHange to Garlekin formulation of B matrix
        %norm =([nx 0 0 0 0; 0 ny 0 0 0;ny nx 0 0 0;0 0 nx 0 ny;0 0 0 ny nx])*weight/area; % CHange to Garlekin formulation of B matrix
        nsf = length(xsupp);
        if i+i2==2
             nodL=supp{neighbour(i)};
             nn=nsf;
            for j=1:nsf;
                BL(1:3,2*j-1:2*j)=norm*phi1(j);
            end
        else  
            i0=0;
            for jj=1:nsf
                nod=supp{neighbour(i)}(jj);
                flag=0;
                for j=1:nn
                   if nodL(j)==nod
                      BL(1:3,2*j-1:2*j)=BL(1:3,2*j-1:2*j)+norm*phi1(jj);
                      flag=1;  break
                    end
                end
                if flag==0
                    i0=i0+1;
                    nodL(nn+i0)=nod;
                    BL(1:3,2*(nn+i0)-1:2*(nn+i0))=norm*phi1(jj);
                end
            end 
             nn=nn+i0;             
       end %end else
     end

end

return
