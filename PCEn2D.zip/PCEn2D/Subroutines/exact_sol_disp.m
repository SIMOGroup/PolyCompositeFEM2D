function [U_analysis]=exact_sol_disp(nnode,node,p,emodu,poisson,d,L)
%-----------------------------------------------------------------------
%  analytical solution:
%  ux=Py/(6EI)*[(6L-3x)*x+(2+poisson)*(y^2-D^2/4)];
%  uy=-P/(6EI)*[3*poisson*y^2*(L-x)+(4+5*poisson)*D^2*x/4+(3*L-x)*x^2];
%-----------------------------------------------------------------------
inert=d*d*d/12;
pei=p/(6*emodu*inert);
U_analysis=[];
for i=1:nnode
    x=node(i,1);
    y=node(i,2);
    ux=pei*y*((6*L-3*x)*x+(2+poisson)*(y*y-d*d/4));
    uy=-pei*(3*poisson*y*y*(L-x)+(4+5*poisson)*d*d*x/4+(3*L-x)*x*x);
    U_analysis=[U_analysis ux uy];
end;
