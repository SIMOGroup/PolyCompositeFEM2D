function [eldisp0,estress0]=analytic_sol_platehole(x,y,emodule,poisson,R)
%-----------------------------------------------------------------------
G=emodule/(1+poisson)/2;
a2=R*R; a4=a2*a2;
x0=x; y0=y;
r2=x0*x0+y0*y0; r4=r2*r2;
r=sqrt(r2);
s1=y0/r; c1=x0/r;        % note that r is always positive (nonzero)!
s2=2*s1*c1; c2=2*c1*c1-1;
c4=c2*c2-s2*s2;
s4=2*s2*c2;
ur=((1-2*poisson+c2)+(1+4*(1-poisson)*c2)*a2/r2-a4*c2/r4)*r/(4*G); % for plane strain
ut=((4*poisson-2)*a2/r2-1-a4/r4)*s2*r/(4*G);
u0=c1*ur-s1*ut;
v0=s1*ur+c1*ut;
sigxx0= 1-a2*(3*c2/2+c4)/r2+3*a4*c4/(2*r4);
sigyy0= -a2*(0.5*c2-c4)/r2-3*a4*c4/(2*r4);
sigxy0= -a2*(0.5*s2+s4)/r2+3*a4*s4/(2*r4);     
eldisp0=[u0;v0];
estress0=[sigxx0;sigyy0;sigxy0];
return