function stressNode = computeStressNodeClassic(numnode, numelem, element, node, Dm, U, LAB)

global thickness

sdof = numnode;
M = sparse(sdof, sdof);
EStressRHS = zeros(3, sdof);

ndof = 2;
NumGPs = 3;
for iel = 1 : numelem
    sctr = element{iel}(:)';  % extract nodes for (iel)-th element
    CoE = node(sctr, :);
    
    Coord = [CoE; polygonCentroid(CoE)];
    nnel = length(sctr);
    
    sctrR = zeros(1, ndof * nnel);
    sctrR(1:ndof:ndof * nnel) = ndof .* sctr - 1;
    sctrR(2:ndof:ndof * nnel) = ndof .* sctr;
    edispl = U(sctrR);
    
    Connect = [(nnel + 1) * ones(nnel, 1), (1:nnel)', [2:nnel, 1]'];
    
    if strcmp(LAB, 'CorrectedWachspress')
        WGC = evalWachspressGradientCorrection(Coord, Connect);
    end
    
    [P, ~, W, ~] = getQuadData(NumGPs);
    EStressGauss = zeros(3, nnel);
    me = zeros(nnel, nnel);
    for icell = 1 : nnel
        CoSubTri = Coord(Connect(icell, :), :);
        for igaus = 1 : NumGPs
            [NT3, dNdsT3] = T3ShapeFnc(P(igaus, :));
            xy = NT3*CoSubTri;
            J = dNdsT3 * CoSubTri;
            dNdxT31 = J \ dNdsT3;
            
            if (strcmp(LAB, 'Wachspress') || strcmp(LAB, 'CorrectedWachspress'))
                [Ng, dNdx] = wachspress2d_Floater_CenterNode(Coord(1:nnel, :), Coord(end, :), xy);
                if strcmp(LAB, 'CorrectedWachspress')
                    dNdx = dNdx + WGC;
                end
            elseif (strcmp(LAB, 'T3'))
                Ng = zeros(nnel, 1);
                dNdx = zeros(nnel, 2);
                dNdx(Connect(icell, 2 : 3), :) = dNdxT31(:, 2 : 3)';
                dNdx = dNdx + repmat(dNdxT31(:, 1)' / nnel, nnel, 1);
                
                Ng(Connect(icell, 2 : 3)) = NT3(2 : 3)';
                Ng = Ng + repmat(NT3(1) / nnel, nnel, 1);
            end
            
            subel = 1:nnel;
            Be = zeros(3, 2 * nnel);
            
            Be(1, 2 * subel - 1) = dNdx(1:nnel, 1);
            Be(2, 2 * subel) = dNdx(1:nnel, 2);
            Be(3, 2 * subel - 1) = dNdx(1:nnel, 2);
            Be(3, 2 * subel) = dNdx(1:nnel, 1);
            
            estressCell = Dm * Be * edispl;
            EStressGauss = EStressGauss + estressCell * Ng(1:nnel)' * W(igaus) * det(J) * thickness;
            
            me = me + Ng(1:nnel) * Ng(1:nnel)' * W(igaus) * det(J) * thickness;
        end
    end
    M(sctr, sctr) = M(sctr, sctr) + me;
    EStressRHS(:, sctr) = EStressRHS(:, sctr) + EStressGauss;
end
stressNode = (M \ EStressRHS')';
end
