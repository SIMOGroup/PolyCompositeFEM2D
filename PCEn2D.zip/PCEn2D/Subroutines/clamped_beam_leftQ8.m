function [bcdof,bcval]=clamped_beam_leftQ8(ndivx,ndivy, ndof) 

bcdof=[];
bcval=[];
for i=1:ndivy+1
    index=(3*ndivx+2)*(i-1)+1;
    bcdof=[bcdof ndof*index-1 ndof*index];
    bcval=[bcval 0 0];
end 
for i=1:ndivy
    index=(3*ndivx+2)*i-ndivx;
    bcdof=[bcdof ndof*index-1 ndof*index];
    bcval=[bcval 0 0];
 end 