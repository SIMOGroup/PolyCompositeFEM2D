function [W,Q] = quadPoints(elemType)
switch elemType  % define quadrature rule
case 'Q8'
  [W,Q]=quadrature(2, 'GAUSS', 1 ); %  four point quadrature   
case 'Q9'
  [W,Q]=quadrature(2, 'GAUSS', 1 ); %  four point quadrature
case 'T6'
  [W,Q]=quadrature(2, 'GAUSS', 1 ); %  four point quadrature
otherwise
  [W,Q]=quadrature(2, 'GAUSS', 1 ); % three point quadrature
end

