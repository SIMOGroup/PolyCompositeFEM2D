function [C, gamma] = Dmaterial(E0, nu0, stressState)
%UNTITLED2 Summary of this function goes here
%   Detailed explanation goes here

% COMPUTE ELASTICITY MATRIX

if (strcmp(stressState, 'PLANE_STRESS'))% Plane Stress case
    C = E0 / (1 - nu0^2) * [1, nu0, 0; ...
        nu0, 1, 0; ...
        0, 0, (1 - nu0) / 2];
    gamma = (1 - 2 * nu0) / (1 - nu0);
else % Plane Strain case
    C = E0 / (1 + nu0) / (1 - 2 * nu0) * [1 - nu0, nu0, 0; ...
        nu0, 1 - nu0, 0; ...
        0, 0, 1/2 - nu0];
    gamma = 1;
end

end
