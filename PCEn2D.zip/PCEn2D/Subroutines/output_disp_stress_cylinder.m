function output_disp_stress_cylinder(nnode,gcoord,emodule,poisson,disp,stress_node,P,R1,R2)

nod_rad_x=[];
cod_rad_x=[];
disp_rad=[];
disp_rad0=[];
stre_rad_r=[];
stre_rad_r0=[];
stre_rad_theta=[];
stre_rad_theta0=[];

for i=1:nnode
    if gcoord(i,2)<1e-10 
        nod_rad_x=[nod_rad_x i];
    end
end

for i=1:length(nod_rad_x)-1
    for j=i+1:length(nod_rad_x)
        if gcoord(nod_rad_x(i),1)>gcoord(nod_rad_x(j),1)
            temp=nod_rad_x(i);
            nod_rad_x(i)=nod_rad_x(j);
            nod_rad_x(j)=temp;
        end
    end
end
%p_o=0;
%p_i=P;
%G=emodule/(2*(1+poisson));
for i=1:length(nod_rad_x)
   cod_rad_x=[cod_rad_x gcoord(nod_rad_x(i),1)];
   disp_rad=[disp_rad disp(2*nod_rad_x(i)-1)];
    x=gcoord(nod_rad_x(i),1);
    y=0;
    if x<10e-6;
         ang=pi/2;
     else      
         ang=atan(y/x);
     end
    r=sqrt(x^2+y^2);
    %ur=((1+v)*(1-2*v)*(a^2*P)*r^2+(1+v)*a^2*b^2*P)/(E*(b^2-a^2)*r);%for strain plane case
    disp_r=((1+poisson)*(1-2*poisson)*(R1^2*P)*r^2+(1+poisson)*R1^2*R2^2*P)/(emodule*(R2^2-R1^2)*r);%for strain plane case
    %disp_r=-1/(2*G*(R2^2-R1^2))*((p_o-p_i)*R1^2*R2^2/r+(1-poisson)*(p_o*R2^2-p_i*R1^2)*r/(1+poisson));
    
    %disp_r=P*R1^2*((1-poisson)*r+(1+poisson)*R2^2/r)/(emodule*(R2^2-R1^2));
    utheta=0;
    pdisp0(1)=disp_r*cos(ang)-utheta*sin(ang);
    %uy=ur*sin(ang)+utheta*cos(ang);
       
    %pdisp0(1)=disp_r*x/r;
    %pdisp0(2)=disp_r*y/r;
    %pdisp0(3)=disp_r*z/r;        
    %disp0(3*i-2,1)=pdisp0(1);
    %disp0(3*i-1,1)=pdisp0(2);
    %disp0(3*i,1)=pdisp0(3);
    %disp_rad0=[disp_rad0 ux];
    disp_rad0=[disp_rad0 pdisp0(1)];
    
    stre_rad_r=[stre_rad_r stress_node(1,nod_rad_x(i))];
    stre_rad_theta=[stre_rad_theta stress_node(2,nod_rad_x(i))];
    sigma_r0=P*R1^2*(1-R2^2/r^2)/(R2^2-R1^2);
    sigma_theta0=P*R1^2*(1+R2^2/r^2)/(R2^2-R1^2);    
    stre_rad_r0=[stre_rad_r0 sigma_r0];
    stre_rad_theta0=[stre_rad_theta0 sigma_theta0];
end

figure 
hold on
plot(cod_rad_x,disp_rad,'b*-.',cod_rad_x,disp_rad0,'r-')
xlabel('Radius');h = get(gca,'Xlabel');
set(h,'FontSize',11); set(h,'FontName','Times New Roman');
ylabel('Radial displacement');h = get(gca,'Ylabel');
set(h,'FontSize',11); set(h,'FontName','Times New Roman');


figure
plot(cod_rad_x,stre_rad_r,'b*-.',cod_rad_x,stre_rad_r0,'r-',...
     cod_rad_x,stre_rad_theta,'m-.',cod_rad_x,stre_rad_theta0,'k-');
xlabel('Radius');h = get(gca,'Xlabel');
set(h,'FontSize',11); set(h,'FontName','Times New Roman');
ylabel('Radial and tangential stresses');h = get(gca,'Ylabel');
set(h,'FontSize',11); set(h,'FontName','Times New Roman');
