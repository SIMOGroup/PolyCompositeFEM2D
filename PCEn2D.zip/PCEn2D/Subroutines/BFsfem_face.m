function [nodL,BL]= BFsfem_face(ivo,elemType,faces,volume,supp,ng)

% written by Hung Nguyen Xuan
% VNU 2011
global node element; 
[W,Q]=quadrature(ng,'TRIANGULAR',3); 
if faces(ivo,5)==0
                neighbour=faces(ivo,4);
 else
                neighbour=faces(ivo,4:5); 
end

nc = length(neighbour); %number of neighbouring cells corresponding to index of element

if (strcmp(elemType,'H4b'))
for i = 1:nc
    kcc = neighbour(i);% index of element
    sctr = element(kcc,:);
    nodes = node(sctr,:);
    gcoord(:,1)=node(sctr,1);
    gcoord(:,2)=node(sctr,2);
    gcoord(:,3)=node(sctr,3);
    node_sc=[1 2 3 5;1 2 4 5; 2 3 4 5; 3 1 4 5];
     
    xsupp = supp{kcc}; % support node numbering
    nsf = length(xsupp);
    bx=zeros(nsf,1);
    by=zeros(nsf,1);
    bz=zeros(nsf,1);
    if sum(faces(ivo,1:3)) == sum(sctr(1:3))
   
       for q=1:length(W)
           pt=Q(q,:);                             % quadrature point
           wt=W(q);                               % quadrature weight
           [Nl,dNl]=lagrange_basis('H4',pt);
           xy_g=gcoord(node_sc(1,:),:)'*Nl;
           J1=gcoord(node_sc(1,:),:)'*dNl;
            if det(J1)<0
               detJ1=-det(J1);
           else
               detJ1=det(J1);
           end 
           xieta=cal_xieta3D('H4',xy_g,nodes);
           [N,dNdxi]=lagrange_basis(elemType,xieta);
           J0=node(sctr,:)'*dNdxi;                % element Jacobian matrix        
           dNdx=dNdxi/J0;
           bx=bx + dNdx(:,1)*wt*detJ1;
           by=by + dNdx(:,2)*wt*detJ1;
           bz=bz + dNdx(:,3)*wt*detJ1;
       end % end loop of gauss points on side
   end % end if
   
   if sum(faces(ivo,1:3)) == sctr(1)+sctr(2)+sctr(4)
   
       for q=1:length(W)
           pt=Q(q,:);                             % quadrature point
           wt=W(q);                               % quadrature weight
           [Nl,dNl]=lagrange_basis('H4',pt);
           xy_g=gcoord(node_sc(2,:),:)'*Nl;
           J1=gcoord(node_sc(2,:),:)'*dNl;
            if det(J1)<0
               detJ1=-det(J1);
           else
               detJ1=det(J1);
           end 
           xieta=cal_xieta3D('H4',xy_g,nodes);
           [N,dNdxi]=lagrange_basis(elemType,xieta);
           J0=node(sctr,:)'*dNdxi;                % element Jacobian matrix        
           dNdx=dNdxi/J0;
           bx=bx + dNdx(:,1)*wt*detJ1;
           by=by + dNdx(:,2)*wt*detJ1;
           bz=bz + dNdx(:,3)*wt*detJ1;
       end % end loop of gauss points on side
   end % end if
   
   if sum(faces(ivo,1:3)) == sctr(2)+sctr(3)+sctr(4)
     
       for q=1:length(W)
           pt=Q(q,:);                             % quadrature point
           wt=W(q);                               % quadrature weight
           [Nl,dNl]=lagrange_basis('H4',pt);
           xy_g=gcoord(node_sc(3,:),:)'*Nl;
           J1=gcoord(node_sc(3,:),:)'*dNl;
           if det(J1)<0
               detJ1=-det(J1);
           else
               detJ1=det(J1);
           end 
           xieta=cal_xieta3D('H4',xy_g,nodes);
           [N,dNdxi]=lagrange_basis(elemType,xieta);
           J0=node(sctr,:)'*dNdxi;                % element Jacobian matrix        
           dNdx=dNdxi/J0;
           bx=bx + dNdx(:,1)*wt*detJ1;
           by=by + dNdx(:,2)*wt*detJ1;
           bz=bz + dNdx(:,3)*wt*detJ1;
       end % end loop of gauss points on side
   end % end if
   
  if sum(faces(ivo,1:3)) == sctr(1)+sctr(3)+sctr(4)
 
       for q=1:length(W)
           pt=Q(q,:);                             % quadrature point
           wt=W(q);                               % quadrature weight
           [Nl,dNl]=lagrange_basis('H4',pt);
           xy_g=gcoord(node_sc(4,:),:)'*Nl;
           J1=gcoord(node_sc(4,:),:)'*dNl;
           if det(J1)<0
               detJ1=-det(J1);
           else
               detJ1=det(J1);
           end 
           xieta=cal_xieta3D('H4',xy_g,nodes);
           [N,dNdxi]=lagrange_basis(elemType,xieta);
           J0=node(sctr,:)'*dNdxi;                % element Jacobian matrix        
           dNdx=dNdxi/J0;
           bx=bx + dNdx(:,1)*wt*detJ1;
           by=by + dNdx(:,2)*wt*detJ1;
           bz=bz + dNdx(:,3)*wt*detJ1;
       end % end loop of gauss points on side
  end % end if
  clear gcoord Nl dNl; 
  
  bx=bx/volume;
  by=by/volume;
  bz=bz/volume;
  
  if i==1
     nodL=element(neighbour(i),:);
     nn=nsf;
     for jj=1:nn
        B_sfem(1,3*jj-2)=bx(jj);
        B_sfem(2,3*jj-1)=by(jj);
        B_sfem(3,3*jj)=bz(jj);
        B_sfem(4,3*jj-2)=by(jj);
        B_sfem(4,3*jj-1)=bx(jj);
        B_sfem(5,3*jj-1)=bz(jj);
        B_sfem(5,3*jj)  =by(jj);
        B_sfem(6,3*jj-2)=bz(jj);
        B_sfem(6,3*jj)  =bx(jj);
     end
   else  
          i0=0;
          for jj=1:nsf
                nod=element(neighbour(i),jj);%supp{neighbour(i)}(jj);
                flag=0;
              for j=1:nn
                  if nodL(j)==nod
                      B_sfem(1,3*j-2)=B_sfem(1,3*j-2)+bx(jj);
                      B_sfem(2,3*j-1)=B_sfem(2,3*j-1)+ by(jj);
                      B_sfem(3,3*j)=B_sfem(3,3*j)+bz(jj);
                      B_sfem(4,3*j-2)=B_sfem(4,3*j-2)+by(jj);
                      B_sfem(4,3*j-1)=B_sfem(4,3*j-1)+bx(jj);
                      B_sfem(5,3*j-1)=B_sfem(5,3*j-1)+bz(jj);
                      B_sfem(5,3*j)  =B_sfem(5,3*j)+by(jj);
                      B_sfem(6,3*j-2)=B_sfem(6,3*j-2)+bz(jj);
                      B_sfem(6,3*j)  =B_sfem(6,3*j)+bx(jj);
                      flag=1;  break
                  end
              end
                if flag==0
                    i0=i0+1;
                    nodL(nn+i0)=nod;
                    B_sfem(1,3*(nn+i0)-2)=bx(jj);
                    B_sfem(2,3*(nn+i0)-1)=by(jj);
                    B_sfem(3,3*(nn+i0))=bz(jj);
                    B_sfem(4,3*(nn+i0)-2)=by(jj);
                    B_sfem(4,3*(nn+i0)-1)=bx(jj);
                    B_sfem(5,3*(nn+i0)-1)=bz(jj);
                    B_sfem(5,3*(nn+i0))  =by(jj);
                    B_sfem(6,3*(nn+i0)-2)=bz(jj);
                    B_sfem(6,3*(nn+i0))  =bx(jj);
        
                end
           end 
           nn=nn+i0;             
   end  %end else
 end %number of neighbouring cells
  BL=B_sfem; 
  clear B_sfem ;
 
elseif (strcmp(elemType,'H4'))
 for i = 1:nc
    kcc = neighbour(i);% index of element
    sctr = element(kcc,:);
    nodes = node(sctr,:);
    gcoord(:,1)=[node(sctr,1); mean(node(sctr,1))];
    gcoord(:,2)=[node(sctr,2); mean(node(sctr,2))];
    gcoord(:,3)=[node(sctr,3); mean(node(sctr,3))];
        
    node_sc=[1 2 3 5;1 2 4 5; 2 3 4 5; 3 1 4 5];
     
    xsupp = supp{kcc}; % support node numbering
    nsf = length(xsupp);
    bx=zeros(nsf,1);
    by=zeros(nsf,1);
    bz=zeros(nsf,1);
    
    if sum(faces(ivo,1:3)) == sum(sctr(1:3))

       for q=1:length(W)
           pt=Q(q,:);                             % quadrature point
           wt=W(q);                               % quadrature weight
           [Nl,dNl]=lagrange_basis('H4',pt);
           xy_g=gcoord(node_sc(1,:),:)'*Nl;
           J1=gcoord(node_sc(1,:),:)'*dNl;
           if det(J1)<0
               detJ1=-det(J1);
           else
               detJ1=det(J1);
           end 
           xieta=cal_xieta3D('H4',xy_g,nodes);
           [N,dNdxi]=lagrange_basis(elemType,xieta);
           J0=node(sctr,:)'*dNdxi;                % element Jacobian matrix    
           
           dNdx=dNdxi/J0;
           bx=bx + dNdx(:,1)*wt*detJ1;
           by=by + dNdx(:,2)*wt*detJ1;
           bz=bz + dNdx(:,3)*wt*detJ1;
       end % end loop of gauss points on side
   end % end if
   
   if sum(faces(ivo,1:3)) == sctr(1)+sctr(2)+sctr(4)
       
       for q=1:length(W)
           pt=Q(q,:);                             % quadrature point
           wt=W(q);                               % quadrature weight
           [Nl,dNl]=lagrange_basis('H4',pt);
           xy_g=gcoord(node_sc(2,:),:)'*Nl;
           J1=gcoord(node_sc(2,:),:)'*dNl;
           if det(J1)<0
               detJ1=-det(J1);
           else
               detJ1=det(J1);
           end   
           xieta=cal_xieta3D('H4',xy_g,nodes);
           [N,dNdxi]=lagrange_basis(elemType,xieta);
           J0=node(sctr,:)'*dNdxi;                % element Jacobian matrix        
           
           dNdx=dNdxi/J0;
           bx=bx + dNdx(:,1)*wt*detJ1;
           by=by + dNdx(:,2)*wt*detJ1;
           bz=bz + dNdx(:,3)*wt*detJ1;
       end % end loop of gauss points on side
   end % end if
   
   if sum(faces(ivo,1:3)) == sctr(2)+sctr(3)+sctr(4)
      
       for q=1:length(W)
           pt=Q(q,:);                             % quadrature point
           wt=W(q);                               % quadrature weight
           [Nl,dNl]=lagrange_basis('H4',pt);
           xy_g=gcoord(node_sc(3,:),:)'*Nl;
           J1=gcoord(node_sc(3,:),:)'*dNl;
           if det(J1)<0
               detJ1=-det(J1);
           else
               detJ1=det(J1);
           end   
           xieta=cal_xieta3D('H4',xy_g,nodes);
           [N,dNdxi]=lagrange_basis(elemType,xieta);
           J0=node(sctr,:)'*dNdxi;                % element Jacobian matrix        
           
           dNdx=dNdxi/J0;
           bx=bx + dNdx(:,1)*wt*detJ1;
           by=by + dNdx(:,2)*wt*detJ1;
           bz=bz + dNdx(:,3)*wt*detJ1;
       end % end loop of gauss points on side
   end % end if
   
  if sum(faces(ivo,1:3)) == sctr(1)+sctr(3)+sctr(4)
      
       for q=1:length(W)
           pt=Q(q,:);                             % quadrature point
           wt=W(q);                               % quadrature weight
           [Nl,dNl]=lagrange_basis('H4',pt);
           xy_g=gcoord(node_sc(4,:),:)'*Nl;
           J1=gcoord(node_sc(4,:),:)'*dNl;
           if det(J1)<0
               detJ1=-det(J1);
           else
               detJ1=det(J1);
           end   
           xieta=cal_xieta3D('H4',xy_g,nodes);
           [N,dNdxi]=lagrange_basis(elemType,xieta);
           J0=node(sctr,:)'*dNdxi;                % element Jacobian matrix     
           
           dNdx=dNdxi/J0;
           bx=bx + dNdx(:,1)*wt*detJ1;
           by=by + dNdx(:,2)*wt*detJ1;
           bz=bz + dNdx(:,3)*wt*detJ1;
       end % end loop of gauss points on side
  end % end if
  clear gcoord Nl dNl;
  
  bx=bx/volume;
  by=by/volume;
  bz=bz/volume;
  
  if i==1
     nodL=element(neighbour(i),:);
     nn=nsf;
     for jj=1:nn
        B_sfem(1,3*jj-2)=bx(jj);
        B_sfem(2,3*jj-1)=by(jj);
        B_sfem(3,3*jj)=bz(jj);
        B_sfem(4,3*jj-2)=by(jj);
        B_sfem(4,3*jj-1)=bx(jj);
        B_sfem(5,3*jj-1)=bz(jj);
        B_sfem(5,3*jj)  =by(jj);
        B_sfem(6,3*jj-2)=bz(jj);
        B_sfem(6,3*jj)  =bx(jj);
     end
   else  
          i0=0;
          for jj=1:nsf
                nod=element(neighbour(i),jj);%supp{neighbour(i)}(jj);
                flag=0;
              for j=1:nn
                  if nodL(j)==nod
                      B_sfem(1,3*j-2)=B_sfem(1,3*j-2)+bx(jj);
                      B_sfem(2,3*j-1)=B_sfem(2,3*j-1)+ by(jj);
                      B_sfem(3,3*j)=B_sfem(3,3*j)+bz(jj);
                      B_sfem(4,3*j-2)=B_sfem(4,3*j-2)+by(jj);
                      B_sfem(4,3*j-1)=B_sfem(4,3*j-1)+bx(jj);
                      B_sfem(5,3*j-1)=B_sfem(5,3*j-1)+bz(jj);
                      B_sfem(5,3*j)  =B_sfem(5,3*j)+by(jj);
                      B_sfem(6,3*j-2)=B_sfem(6,3*j-2)+bz(jj);
                      B_sfem(6,3*j)  =B_sfem(6,3*j)+bx(jj);
                      flag=1;  break
                  end
              end
                if flag==0
                    i0=i0+1;
                    nodL(nn+i0)=nod;
                    B_sfem(1,3*(nn+i0)-2)=bx(jj);
                    B_sfem(2,3*(nn+i0)-1)=by(jj);
                    B_sfem(3,3*(nn+i0))=bz(jj);
                    B_sfem(4,3*(nn+i0)-2)=by(jj);
                    B_sfem(4,3*(nn+i0)-1)=bx(jj);
                    B_sfem(5,3*(nn+i0)-1)=bz(jj);
                    B_sfem(5,3*(nn+i0))  =by(jj);
                    B_sfem(6,3*(nn+i0)-2)=bz(jj);
                    B_sfem(6,3*(nn+i0))  =bx(jj);
        
                end
           end 
             nn=nn+i0;             
   end  %end else
 end %number of neighbouring cells
BL=B_sfem;
clear B_sfem ;
 else
   disp('Number smoothing cells of element are not implemented');
   return
end



   

