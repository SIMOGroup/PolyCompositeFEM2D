%----------------------------------------------------------------------------
% Static analysis of An infinite plne
% four-node quadrilaterials with consistent mass.
% Rev. Date: 04 2006 
% Developed by Nguyen Thoi Trung, NUS
%----------------------------------------------------------------------------            
%------------------------------------
%  input data for control parameters
%------------------------------------

clear all
first_time=cputime;  
format long

ndof=2;                   % number of displacement dofs per node
nnel=3;                   % number of node per element

emodu=1e5;                % elastic modulus
poiss=0.3;               % Poisson's ratio

%---------------------------------------------
% generate sampling poits for discretization
%---------------------------------------------
A=0.2; L=1;
n1=8;                       % number of elements in y-direction. 
nx=2*n1;   ny=nx;           % number of elements in x-direction. 

tol=1e-12;

nnode=(nx+1)*(nx+1)+n1*n1;       % total sampling node number
nel=2*(nx*nx+(n1-1)*(n1-1)+2*n1-1);  % number of element
sdof=nnode*ndof;                 % total system dofs for mechanical displacement
edof=nnel*ndof;

%-------------------------------------------------------------------------
% To generate field nodes and voronoi diagram
%-------------------------------------------------------------------------
    
[xd,yd,nodes,bcnode]=formnode_T3(n1,nx,A,L);
gcoord(:,1)=xd(:);
gcoord(:,2)=yd(:);

%---------------------------------------------------------------------
%  input data for boundary conditions for displacement and potential
%---------------------------------------------------------------------

cmat=fematiso(2,emodu,poiss);                           % elastic stiffness matrix 

p0=-1e6;
c=100;   c1=p0*(1-poiss*poiss)/pi/emodu; c2=(1-2*poiss)/(1-poiss);

nl=length(bcnode{2});
for i=1:nl
    bcdof(1,i)=2*bcnode{2}(i)-1;         % left side
    bcval(1,i)=0;
end

nb=length(bcnode{4});
for i=1:nb
    n=bcnode{4}(i);
    bcdof(1,2*i-1+nl)=2*n-1;               % bottom
    bcdof(1,2*i+nl)=2*n;         
    
    x=xd(n); y=yd(n);
    r1=sqrt((x+A)*(x+A)+y*y);   r2=sqrt((x-A)*(x-A)+y*y);
    theta1=atan(-(x+A)/y);      theta2=atan(-(x-A)/y);
    if abs(r2)<1e-12
    u=c1*(c2*((x+A)*theta1-(x-A)*theta2));
    v=c1*(c2*(y*(theta1-theta2)+2*c*A*atan(1/c))-2*(x+A)*log(r1) ...
        +4*A*log(A)+2*A*log(1+c*c));
    else
    u=c1*(c2*((x+A)*theta1-(x-A)*theta2)+2*y*log(r1/r2));
    v=c1*(c2*(y*(theta1-theta2)+2*c*A*atan(1/c))+2*(x-A)*log(r2)-2*(x+A)*log(r1) ...
        +4*A*log(A)+2*A*log(1+c*c));
    end
    bcval(1,2*i-1+nl)=u;        bcval(1,2*i+nl)=v;
end
%----------------------------------------------
%  initialization of matrices and vectors
%----------------------------------------------
kk=sparse(sdof,sdof);     % system elastic stiffness matrix
disp=sparse(sdof,1);      % system displacement vector
ff=sparse(sdof,1);        % system displacement vector

%----------------------------
%  force vector
%----------------------------

nu=length(bcnode{1});          % upper surface
for i=1:nu
    n=bcnode{1}(i); c3=1;
    if i==1 | i==nu
        c3=0.5;
    end
    ff(2*n)=p0*c3*A/n1;
end

nr=length(bcnode{3});          % right surface
for i=1:nr
    n=bcnode{3}(i); 
    x=xd(n); y=yd(n);
    if i==1
        n2=bcnode{3}(i+1);
        dy=abs(y-yd(n2))/2;
    elseif i==nr
        n0=bcnode{3}(i-1);
        dy=abs(y-yd(n0))/2;
    else
        n0=bcnode{3}(i-1); n2=bcnode{3}(i+1);
        dy=abs(yd(n0)-yd(n2))/2;
    end
    if abs(y)<1e-12
        theta1=pi/2; theta2=pi/2;
    else
        theta1=atan(-(x+A)/y);      theta2=atan(-(x-A)/y);
    end
  
    s11=p0*(2*(theta1-theta2)-sin(2*theta1)+sin(2*theta2))/2/pi;
    s12=p0*(cos(2*theta1)-cos(2*theta2))/2/pi;
    
    ff(2*n-1)=s11*dy;
    ff(2*n)=s12*dy;
end

%save d:\Make_program\FEM_code\FEM_2D_standard\Semi_plane\Mesh gcoord nodes bcdof bcval ff;

%----------------------------------------------------------------- 
%  computation of element matrices and vectors and their assembly 
%----------------------------------------------------------------- 

matmtx=fematiso(2,emodu,poiss);     %constitutive matrice

for iel=1:nel       %loop for the total number of element

    nd(1)=nodes(iel,1);         %1st connected node for (iel)-th element
    nd(2)=nodes(iel,2);         %2nd connected node for (iel)-th element
    nd(3)=nodes(iel,3);         %3rd connected node for (iel)-th element
    
    x1=gcoord(nd(1),1); y1=gcoord(nd(1),2);     %coord values of 1st node
    x2=gcoord(nd(2),1); y2=gcoord(nd(2),2);     %coord values of 2nd node
    x3=gcoord(nd(3),1); y3=gcoord(nd(3),2);     %coord values of 3rd node
    
    index=feeldof(nd,nnel,ndof);        %extract system dofs for the element
    
    %---------------------------------------
    %find the derivatives of shape functions
    %---------------------------------------
    
   	area=0.5*(x1*y2+x2*y3+x3*y1-x1*y3-x2*y1-x3*y2); %area of triangula
	area2=area*2;
	
    dhdx=(1/area2)*[(y2-y3) (y3-y1) (y1-y2)];       %derivatives w.r.t x
    dhdy=(1/area2)*[(x3-x2) (x1-x3) (x2-x1)];       %derivatives w.r.t y
   
 	kinmtx2=fekine2d(nnel,dhdx,dhdy);               %kinematic matrice
   
   	k=kinmtx2'*matmtx*kinmtx2*area;                 %element stiffness matrice
     
   	kk=feasmbl1(kk,k,index);                        %assemble element matrics
end                
%------------------------------------------------------                 

%------------------------
%apply boundary condition
%------------------------
kk1=kk;
[kk,ff]=feaplyc2(kk,ff,bcdof,bcval);

%-------------------------
%solve the matrix equation
%-------------------------

[LL UU]=lu(kk);
utemp=LL\ff;
disp=UU\utemp;

solve_time = cputime-first_time;

EU=0.5*disp'*kk1*disp    
%-------------------------------------------------------------------

clear bcdof bcval kk ff utemp UU LL

%-------------------------------------------
% calculate exact values of displacement.
%-------------------------------------------
 disp0=zeros(sdof,1);
 edisp=0; edisp0=0; dtotsign=0;
 for i=1:nnode
    x=xd(i);       y=yd(i);
    
    r1=sqrt((x+A)*(x+A)+y*y);   r2=sqrt((x-A)*(x-A)+y*y);
    if abs(y)<1e-12 & x<A
        theta1=pi/2; theta2=-pi/2;
    elseif abs(y)<1e-12 & x>=A
        theta1=pi/2; theta2=pi/2;
    else
        theta1=atan(-(x+A)/y);      theta2=atan(-(x-A)/y);
    end
    if abs(y)<1e-12 & x==A
        u=c1*(c2*((x+A)*theta1-(x-A)*theta2));
        v=c1*(c2*(y*(theta1-theta2)+2*c*A*atan(1/c))-2*(x+A)*log(r1) ...
            +4*A*log(A)+2*A*log(1+c*c));
    else        
        u=c1*(c2*((x+A)*theta1-(x-A)*theta2)+2*y*log(r1/r2));
        v=c1*(c2*(y*(theta1-theta2)+2*c*A*atan(1/c))+2*(x-A)*log(r2)-2*(x+A)*log(r1) ...
            +4*A*log(A)+2*A*log(1+c*c));
    end
    disp0(2*i-1)=u; disp0(2*i)=v;
    edisp=edisp+abs(u-disp(2*i-1))+abs(v-disp(2*i));
    edisp0=edisp0+abs(u)+abs(v);
    dtotsign=dtotsign+abs(disp(i))-abs(disp0(i));
 end
     
 err=edisp/edisp0*100
  
nupnode=[(1:n1)+(nx+1)*(ny+1) (ny+1):-1:1];
nu=length(nupnode);

for i=1:nu
    n=nupnode(i);
    xp(i)=xd(n);
    pu0(i)=disp0(2*n-1); pu(i)=disp(2*n-1);
    pv0(i)=disp0(2*n);   pv(i)=disp(2*n);
end

figure(13)
hold on
plot(xp,pu,'bO',xp,pu0,'-');

figure(14)
hold on
plot(xp,pv,'b+',xp,pv0,'-');

%clear

%---------------------------------------
%  element stress computation
%---------------------------------------
% energy0=0;
% denergy=0;
% invcmat=inv(cmat);
% 
% 
% for iel=1:nel               % loop for the total number of elements
%    
% for i=1:nnel
% nd=nodes(iel,i);
% index(2*i-1)=2*nd-1; index(2*i)=2*nd;
% xcoord(i)=xd(nd);              % extract x value of the node
% ycoord(i)=yd(nd);              % extract y value of the node
% end
% 
% %--------------------------------
% %  numerical integration
% %--------------------------------
% 
% kk=0;
% for intx=1:ngl
% x=point(intx,1);                  % sampling point in x-axis
% wtx=weight(intx,1);               % weight in x-axis
% for inty=1:ngl
% y=point(inty,2);                  % sampling point in y-axis
% wty=weight(inty,2) ;              % weight in y-axis
% kk=kk+1;
% 
% [shape,dhdr,dhds]=feisoq4(x,y);   % compute shape functions and
% 				                                % derivatives at sampling point
% 
% jacob2=fejacob2(nnel,dhdr,dhds,xcoord,ycoord);  % compute Jacobian
% 
% detjacob=det(jacob2);                           % determinant of Jacobian
% invjacob=inv(jacob2);                           % inverse of Jacobian matrix
% 
% [dhdx,dhdy]=federiv2(nnel,dhdr,dhds,invjacob); % derivatives w.r.t.
% 					                           % physical coordinate
% 
% kinmtpf=fekine2d(nnel,dhdx,dhdy);              % kinematic matrix
% 
% %-------------------------------------------------------
% %  extract element displacement vector
% %-------------------------------------------------------
% 
% for i=1:edof
% eldisp(i,1)=disp(index(i));
% end
% 
% estrain=kinmtpf*eldisp;              % compute strains
% estress=cmat*estrain;             % compute stresses
% 
% %-----------------------------------------------------------------------
% % Analytical solution
% %-----------------------------------------------------------------------
% x=0;y=0;
% for i=1:nnel                               
%    x=x+shape(i)*xcoord(i);      % Gauss integration point in global coord's
%    y=y+shape(i)*ycoord(i);
% end
% 
%     if abs(x)<1e-12 & abs(y)<1e-12
%         tstre(1:3,i)=[-1e6 -1e6 0];
%         tstre0(1:3,i)=[-1e6 -1e6 0];
%         continue
%     elseif abs(y)<1e-12 & x<A
%         theta1=pi/2; theta2=-pi/2;
%     elseif abs(y)<1e-12 & x>=A
%         theta1=pi/2; theta2=pi/2;
%     else
%         theta1=atan(-(x+A)/y);      theta2=atan(-(x-A)/y);
%     end
%     
%     s11=p0*(2*(theta1-theta2)-sin(2*theta1)+sin(2*theta2))/2/pi;
%     s12=p0*(cos(2*theta1)-cos(2*theta2))/2/pi;
%     s22=p0*(2*(theta1-theta2)+sin(2*theta1)-sin(2*theta2))/2/pi;
%     
%     estress0=[s11 s22 s12]';
%     
%     denergy=denergy+(invcmat*(estress0-estress))'*(estress0-estress)*wtx*wty*detjacob;
%     energy0 = energy0 +(invcmat*estress0)'*estress0*wtx*wty*detjacob;
% end
% end                                 % end of integration loop
% 
% end                                 % end for all elements
% 
% denergy=sqrt(denergy)/2
% energy0
% clear all
%---------------------------------------------------------------
    

