function [stressNode_dev,stressNode_vol]=stressNodeFEMQ4_Selective(element,node,Qd,Qv,U,Ddev,Dvol,mu,km)

Matrix_extrapolation=[1+0.5*sqrt(3) -0.5  1-0.5*sqrt(3) -0.5;
                     -0.5  1+0.5*sqrt(3)  -0.5  1-0.5*sqrt(3);
                     1-0.5*sqrt(3)  -0.5  1+0.5*sqrt(3) -0.5;
                     -0.5  1-0.5*sqrt(3) -0.5  1+0.5*sqrt(3)];
                 
numelem=size(element,1);
nnel=size(element,2);
numnode=size(node,1);

stressNode_dev=zeros(3,numnode);
stressNode_vol=zeros(3,numnode);

index_numb_node=zeros(numnode,1);

for e=1:numelem                          % start of element loop
   sctr=element(e,:);           % element scatter vector
   nn=length(sctr);
   sctrB(1:2:2*nn) = 2.*sctr-1 ;
   sctrB(2:2:2*nn) = 2.*sctr   ;
   Udisp=U(sctrB);
   stress_Gauss_dev=cell(1,size(Qd,1));
     
   n1=0;
   for q=1:size(Qd,1)                        % quadrature loop
     pt=Qd(q,:);                             % quadrature point
     [N,dNdxi]=lagrange_basis('Q4',pt); % element shape functions
     J0=node(sctr,:)'*dNdxi;                % element Jacobian matrix        
     dNdx=dNdxi/J0;
     B(1,1:2:2*nn-1) = dNdx(:,1)';
     B(2,2:2:2*nn)   = dNdx(:,2)';
     B(3,1:2:2*nn-1) = dNdx(:,2)';
     B(3,2:2:2*nn)  = dNdx(:,1)';
     estress_dev=mu*Ddev*B*Udisp;
     n1=n1+1;
     if n1==1
        stress_Gauss_dev{1,3}(1:3)=estress_dev(:,1);            
      elseif n1==2
        stress_Gauss_dev{1,2}(1:3)=estress_dev(:,1);            
      elseif n1==3
        stress_Gauss_dev{1,4}(1:3)=estress_dev(:,1);  
      else
        stress_Gauss_dev{1,1}(1:3)=estress_dev(:,1);  
      end
   end
   clear n1;
   for q=1:size(Qv,1)                        % quadrature loop
     pt=Qv(q,:);                             % quadrature point
     [N,dNdxi]=lagrange_basis('Q4',pt); % element shape functions
     J0=node(sctr,:)'*dNdxi;                % element Jacobian matrix        
     dNdx=dNdxi/J0;
     B(1,1:2:2*nn-1) = dNdx(:,1)';
     B(2,2:2:2*nn)   = dNdx(:,2)';
     B(3,1:2:2*nn-1) = dNdx(:,2)';
     B(3,2:2:2*nn)  = dNdx(:,1)';
     estress_vol=km*Dvol*B*Udisp;
   end
   
    for i=1:nnel        
        temp_M=zeros(3,1);
        for j=1:size(Qd,1)
            temp_M(:) = temp_M(:) + Matrix_extrapolation(i,j) * stress_Gauss_dev{1,j}(:);
        end
        stressNode_dev(:,sctr(i)) = stressNode_dev(:,sctr(i)) + temp_M(:);
        stressNode_vol(:,sctr(i)) = stressNode_vol(:,sctr(i)) + estress_vol(:);
        index_numb_node(sctr(i))=index_numb_node(sctr(i))+1;              
    end
    
end         

for i=1:numnode
    stressNode_dev(:,i)=stressNode_dev(:,i)/index_numb_node(i);  %unweighted average
    stressNode_vol(:,i)=stressNode_vol(:,i)/index_numb_node(i);  %unweighted average
end
