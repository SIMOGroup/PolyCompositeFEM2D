function [leftEdge,rightEdge,edgeElemType] = getBoundaryEdge(elemType,numx,nnx,uln,urn,lrn)
global node L
switch elemType
case 'Q8'
   uln=uln-numelem;
   urn=size(node,1);    % number of nodes
   rightEdge=[ lrn:nnx+numx+1:(uln-1);(lrn+nnx+numx+1):nnx+numx+1:urn;(nnx+numx+1):nnx+numx+1:urn]';
   leftEdge =[ uln:-(nnx+numx+1):(lrn+1);uln-(nnx+numx+1):-(nnx+numx+1):1;(uln-(numx+1)):-(nnx+numx+1):1]';
   edgeElemType='L3';
case 'Q9'
  rightEdge=[ lrn:2*nnx:(uln-1); (lrn+2*nnx):2*nnx:urn; (lrn+nnx):2*nnx:urn ]';
  leftEdge =[ uln:-2*nnx:(lrn+1); (uln-2*nnx):-2*nnx:1; (uln-nnx):-2*nnx:1 ]';
  edgeElemType='L3';
case 'T6'
  rightEdge=[ lrn:2*nnx:(uln-1); (lrn+2*nnx):2*nnx:urn; (lrn+nnx):2*nnx:urn ]';
  leftEdge =[ uln:-2*nnx:(lrn+1); (uln-2*nnx):-2*nnx:1; (uln-nnx):-2*nnx:1 ]';
  edgeElemType='L3';  
case 'CPn'
    tol=1e-3;
    RigthBC = find(node(:,1) > L-tol & node(:,1) < L+tol);
    for i=1:length(RigthBC)-1
        for j=i+1:length(RigthBC)
            if node(RigthBC(i),2)>node(RigthBC(j),2)
                temp=RigthBC(i);
                RigthBC(i)=RigthBC(j);
                RigthBC(j)=temp;
            end
        end
    end
    leftEdge=[];
    rightEdge=[RigthBC(1:end-1),RigthBC(2:end)]; 
    edgeElemType='L2';
    
    case 'Poly'
     rightnode = find(abs(node(:,1)-L)<1e-5);
    [~,idx] = sort(node(rightnode,2),'descend');
    rightnode = rightnode(idx);
    rightEdge = [rightnode(1:end-1),rightnode(2:end)];
    leftnode = find(abs(node(:,1)-0)<1e-5);
    [~,idx] = sort(node(leftnode,2),'descend');
    leftnode = leftnode(idx);
    leftEdge = [leftnode(1:end-1),leftnode(2:end)];
    edgeElemType = 'L2';
    
otherwise  % same discretizations for Q4 and T3 meshes
  rightEdge=[ lrn:nnx:(uln-1); (lrn+nnx):nnx:urn ]';
  leftEdge =[ uln:-nnx:(lrn+1); (uln-nnx):-nnx:1 ]';
  edgeElemType='L2';
end


