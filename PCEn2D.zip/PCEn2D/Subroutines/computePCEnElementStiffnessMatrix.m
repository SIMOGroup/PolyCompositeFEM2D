function Ke = computePCEnElementStiffnessMatrix(Coord, Connect, stressState, Dm, thickness, gamma, LAB, cenDOF)

nn = size(Coord, 1);
nnel = nn - 1;
ndof = 2;
% Kl = zeros(ndof * nn, ndof * nn);

if strcmp(cenDOF, 'yes')
    Kl = zeros(ndof * (nnel + 1), ndof * (nnel + 1));
else
    Ke = zeros(ndof * nnel, ndof * nnel);
end

% d = Connect(:,[1 2 3 1])';
% x = Coord(:, 1);
% y = Coord(:, 2);
% plot(x(d), y(d));

if strcmp(LAB, 'CorrectedWachspress') || strcmp(LAB, 'Wachspress')
    NumQPs = 3;
elseif strcmp(LAB, 'T3')
    NumQPs = 1;
else
    error('Not implemented yet!')
end
[B, MS, WJ] = getStrainDisplacementMatrix(Coord, Connect, NumQPs, LAB, cenDOF);
if (strcmp(stressState, 'PLANE_STRAIN'))
    m = [1; 1; 0];
    Area = polygonArea(Coord(1:end-1, :));    
    if strcmp(cenDOF, 'yes')
        BbarVol = zeros(1, 2 * nn);
    else
        BbarVol = zeros(1, 2 * nnel);
    end
    for jc = 1:nnel
        for jgp = 1:NumQPs
            BbarVol = BbarVol + gamma * m' / Area * B(:, :, jgp, jc) * WJ(jgp, jc);
        end
    end
end
[P, ~, W, ~] = getQuadData(3);
for ic = 1:nnel
    CoordTri = Coord(Connect(ic, :), :);
    for igp = 1 : numel(W)
        [NT3, dNdsT3] = T3ShapeFnc(P(igp, :));
        xy = NT3*CoordTri;
        J = dNdsT3 * CoordTri;
        x = xy(1); y = xy(2);
        AT = det(J)*W(igp);
        S = [1, x, y];
        
        if strcmp(cenDOF, 'yes')
            Bt = zeros(3, ndof * (nnel + 1));
        else
            Bt = zeros(3, ndof * nnel);
        end
        for jc = 1:nnel
            for jgp = 1:NumQPs
                Bt = Bt + (S * MS(:, jgp, jc)) * B(:, :, jgp, jc) * WJ(jgp, jc);
            end
        end
        if (strcmp(stressState, 'PLANE_STRAIN'))
            Bt = 1/3 * m * BbarVol + (eye(3) - (gamma / 3) * (m * m'))*Bt;
        end
        
        if strcmp(cenDOF, 'yes') % element stiffness matrix
            Kl = Kl + Bt' * Dm * Bt * AT * thickness;
        else
            Ke = Ke + Bt' * Dm * Bt * AT * thickness;
        end
    end
end
if strcmp(cenDOF, 'yes')
    Kll = Kl(1:ndof * nnel, 1:ndof * nnel);
    Klq = Kl(1:ndof * nnel, end - 1:end);
    Kql = Kl(end - 1:end, 1:ndof * nnel);
    Kqq = Kl(end - 1:end, end - 1:end);
    Ke = Kll - (Klq / Kqq) * Kql;
end
end