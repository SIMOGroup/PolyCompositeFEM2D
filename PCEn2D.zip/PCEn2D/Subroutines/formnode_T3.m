function [xd,yd,nodes_T3,bcnode]=formnode_square(n1,nx,a,L)


ny=2*n1; 
bcnode=cell(4,1);

dd=0.1; %0.25;       % concentration weight! =0: even distribution!

d1=a/n1;
if (mod(nx,2)==1)
   'NX must be even ...!'
   pause
end

ang=pi/(2*nx);
nk=ny+ny*(ny-1)*dd/2;

nn=0;
for ip=1:nx+1
   
   angi=(ip-1)*ang;
   if (ip<=nx/2+1) 
      xe=L;  ye=-xe*tan(angi);
      xi=a;  yi=-(ip-1)*d1;
   else
      ye=-L;  xe=-ye/tan(angi);
      yi=-a;  xi=a-(ip-nx/2-1)*d1; 
   end
   
   for iq=1:ny+1
      nn=nn+1;
      
      if (iq==1)
         dx=0; dy=0;
      else
       dx=(1+(ny-iq+1)*dd)*(xe-xi)/nk+dx;
       dy=(1+(ny-iq+1)*dd)*(ye-yi)/nk+dy;
      end
       xd(nn)=xe-dx;
       yd(nn)=ye-dy;
    
   end
end
nne=nn;    

nn=0;
for j=1:n1
    for i=1:n1
        nn=nn+1;
        x1(nn)=(i-1)*d1;
        y1(nn)=-(j-1)*d1;
    end
end
nni=nn;

xd(1,nne+1:nne+nni)=x1;
yd(1,nne+1:nne+nni)=y1;

bclf(1,1:n1)=nne+(1:n1:n1*(n1-1)+1);
bclf(1,n1+1:n1+ny+1)=(ny+1)*(nx+1):-1:(ny+1)*nx+1;
bcrt(1,1:n1+1)=1:(ny+1):(ny+1)*n1+1;
bcbt(1,1:n1+1)=(ny+1)*n1+1:(ny+1):(ny+1)*(nx+1);
bcup(1,1:n1+1)=[(1:n1)+nne (ny+1)];
bcnode{1}=bcup; bcnode{2}=bclf; bcnode{3}=bcrt; bcnode{4}=bcbt;

nodes=[];
for i=1:nx
    for j=1:ny
        nodes=[nodes; (ny+1)*(i-1)+j+1 (ny+1)*i+j+1 (ny+1)*i+j (ny+1)*(i-1)+j;];
    end
end

nodes1=[];
for j=1:n1-1
    for i=1:n1-1
        nodes1=[nodes1; n1*j+i n1*j+i+1 n1*(j-1)+i+1 n1*(j-1)+i;];
    end
end
nodes1=nodes1+nne;

nodes2=[];
for i=1:n1-1
    nodes2=[nodes2; n1*(i+1)+nne (ny+1)*(i+1) (ny+1)*i n1*i+nne;];
end
nodes2=[nodes2; (ny+1)*(n1+2) (ny+1)*(n1+1) (ny+1)*(n1) n1*n1+nne;];

for i=1:n1-1
    nodes2=[nodes2; (ny+1)*(n1+2+i) (ny+1)*(n1+1+i) ...
        n1*n1+nne-i+1 n1*n1+nne-i;];
end

nne=nx*ny; nni=(n1-1)*(n1-1);
nodes(nne+1:nne+nni,:)=nodes1;
nodes(nne+nni+1:nne+nni+2*n1-1,:)=nodes2;

nodes_T3=zeros(2*size(nodes,1),3);
for i=1:1/2*(size(nodes,1)-n1^2)
    nodes_T3(2*i-1,1)=nodes(i,1);
    nodes_T3(2*i-1,2)=nodes(i,2);
    nodes_T3(2*i-1,3)=nodes(i,4);
    nodes_T3(2*i,1)=nodes(i,3);
    nodes_T3(2*i,2)=nodes(i,4);
    nodes_T3(2*i,3)=nodes(i,2);
    
end
for i=1/2*(size(nodes,1)-n1^2)+1:size(nodes,1)
    nodes_T3(2*i-1,1)=nodes(i,1);
    nodes_T3(2*i-1,2)=nodes(i,2);
    nodes_T3(2*i-1,3)=nodes(i,3);
    nodes_T3(2*i,1)=nodes(i,1);
    nodes_T3(2*i,2)=nodes(i,3);
    nodes_T3(2*i,3)=nodes(i,4);
end
% for i=size(nodes,1)-nx+1:size(nodes,1)
%      nodes3(2*i-1,1)=nodes(i,1);
%     nodes3(2*i-1,2)=nodes(i,2);
%     nodes3(2*i-1,3)=nodes(i,3);
%     nodes3(2*i,1)=nodes(i,1);
%     nodes3(2*i,2)=nodes(i,3);
%     nodes3(2*i,3)=nodes(i,4);
% end
      