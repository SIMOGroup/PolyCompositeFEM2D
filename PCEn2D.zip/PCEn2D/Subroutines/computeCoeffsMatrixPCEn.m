function MI = computeCoeffsMatrixPCEnNEW(Coord, NumQPs)

nnel = size(Coord, 1) - 1;
Connect = [(nnel + 1) * ones(nnel, 1), (1:nnel)', [2:nnel, 1]'];

M = zeros(3, 3);
[Q, ~, W, ~] = getQuadData(NumQPs);  
for i = 1:nnel    
    CoSubTriPhys = Coord(Connect(i, :), :);    
    for gp = 1:numel(W)% quadrature loop        
        [NT3, dNdsT3] = T3ShapeFnc(Q(gp, :));
        xy = NT3*CoSubTriPhys;
        J0 = dNdsT3 * CoSubTriPhys;
        xi = xy(1); yi = xy(2);
        S = [1, xi, yi];
        M = M + S' * S* det(J0) * W(gp);
    end
end
MI = inv(M);
end
