function sctrB = assembly(e,enrich_node,pos)

global node element

sctr = element(e,:);
nn   = length(sctr);
xsctr = [];
% Enriched elements, need connectivity for enriched nodes
if ( any(enrich_node(sctr)) ~= 0 )    
    for k = 1 : nn
        nk = sctr(k);  
        % split enriched node
        if ( enrich_node(nk) == 1)
            xsctr = [xsctr pos(nk) ];
        % tip enriched node    
        elseif ( enrich_node(nk) == 4)
            xsctr = [xsctr pos(nk) pos(nk)+1 pos(nk)+2 pos(nk)+3];
        end
    end
end

% Appends standard scatter with enriched part
sctr = [sctr xsctr];

% Scatter for assembly
nn = length(sctr);
sctrB(1:2:2*nn) = 2.*sctr-1 ;
sctrB(2:2:2*nn) = 2.*sctr   ;
