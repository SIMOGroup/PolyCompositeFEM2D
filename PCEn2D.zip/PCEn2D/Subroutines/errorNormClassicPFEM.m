function [dnorm, enorm] = errorNormClassicPFEM(problem, stressState, U, LAB)

% assert(strcmp(LAB, 'Wachspress') || strcmp(LAB, 'CorrectedWachspress'))
global node element thickness
% numnode = size(node, 1); % number of nodes
numelem = numel(element);

dnorm = 0;
enorm = 0;
ndof = 2;
NumGPs = 3;
for iel = 1 : numelem
    sctr = element{iel}(:)';  % extract nodes for (iel)-th element
    CoE = node(sctr, :);
    
    Coord = [CoE; mean(CoE)];
    
    nnel = length(sctr);
    
    sctrR = zeros(1, ndof * nnel);
    sctrR(1:ndof:ndof * nnel) = ndof .* sctr - 1;
    sctrR(2:ndof:ndof * nnel) = ndof .* sctr;
    edisp = U(sctrR);
    
    displx = edisp(1 : ndof : end - 1);
    disply = edisp(2 : ndof : end);
    
    Connect = [(nnel + 1) * ones(nnel, 1), (1:nnel)', [2:nnel, 1]'];
    
    if strcmp(LAB, 'CorrectedWachspress')
        WGC = evalWachspressGradientCorrection(Coord, Connect);
    end
    
    [P, ~, W, ~] = getQuadData(NumGPs);
    
    for isub = 1 : nnel
        CoSubTri = Coord(Connect(isub, :), :);
        for igaus = 1 : NumGPs
            [NT3, dNdsT3] = T3ShapeFnc(P(igaus, :));
            xy = NT3*CoSubTri;
            J = dNdsT3 * CoSubTri;
            dNdxT31 = J \ dNdsT3;
            
            if (strcmp(LAB, 'Wachspress') || strcmp(LAB, 'CorrectedWachspress'))
                [Ng, dNdx] = wachspress2d_Floater_CenterNode(Coord(1:nnel, :), Coord(end, :), xy);
                if strcmp(LAB, 'CorrectedWachspress')
                    dNdx = dNdx + WGC;
                end
            elseif (strcmp(LAB, 'T3'))
                Ng = zeros(nnel, 1);
                dNdx = zeros(nnel, 2);
                dNdx(Connect(isub, 2 : 3), :) = dNdxT31(:, 2 : 3)';
                dNdx = dNdx + repmat(dNdxT31(:, 1)' / nnel, nnel, 1);
                
                Ng(Connect(isub, 2 : 3)) = NT3(2 : 3)';
                Ng = Ng + repmat(NT3(1) / nnel, nnel, 1);
            end
            
            subel = 1:nnel;
            Be = zeros(3, 2 * nnel);
            Be(1, 2 * subel - 1) = dNdx(1 : nnel, 1);
            Be(2, 2 * subel) = dNdx(1 : nnel, 2);
            Be(3, 2 * subel - 1) = dNdx(1 : nnel, 2);
            Be(3, 2 * subel) = dNdx(1 : nnel, 1);
            
            if strcmp(problem.LAB, 'CYLINDER')
                [ue, se] = exactsolu_pipe(xy(1), xy(2), problem.a, problem.b, problem.E, problem.nu, problem.P, stressState);
            elseif strcmp(problem.LAB, 'BEAM')
                [ue, se, ~] = analytic_sol_beam(xy(1), xy(2), problem.P, problem.E, problem.nu, problem.D, problem.L);
            elseif strcmp(problem.LAB, 'LINEAR_PATCH_TEST')
                ue = [1e-3*(xy(1) + xy(2)/2); 1e-3*(xy(1)/2 + xy(2))];
                se = [1333; 1333; 400];
            elseif strcmp(problem.LAB, 'QUADRATIC_PATCH_TEST')
                UExact = @(x, y) 0.1 * x .^ 2 + 0.1 * x .* y + 0.2*y .^ 2;
                VExact = @(x, y) 0.05 * x .^ 2 + 0.15 * x .* y + 0.1 * y .^ 2;
                ue = [UExact(xy(1), xy(2)); VExact(xy(1), xy(2))];
                StrainExact =  @(x, y) [0.2*x + 0.1*y; 0.15*x + 0.2*y; 0.1*x + 0.4*y + 0.1*x + 0.15*y];
                se = problem.Dm * StrainExact(xy(1), xy(2));
            else
                error("Not implemented yet!");
            end
            
            % Displacements & stresses at Gauss integration point
            uh = (Ng(1:nnel)' * [displx, disply])';
            sh = problem.Dm * Be * edisp;
            % Error norms
            dnorm = dnorm + (uh - ue)'*(uh - ue) * W(igaus) * det(J) * thickness;
            enorm = enorm + ((sh - se)' / problem.Dm) * (sh - se) * W(igaus) * det(J) * thickness;
        end
    end
end
dnorm = sqrt(dnorm);
enorm = sqrt(enorm);
end
