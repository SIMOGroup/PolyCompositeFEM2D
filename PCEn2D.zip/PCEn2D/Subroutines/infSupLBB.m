function [G, S] = infSupLBB(ivo, elemType, edges, area, supp, Dlamda, ng, G, S)

global node element

if edges(ivo, 3) == 0
    neighbour = [edges(ivo, 4)];
else
    neighbour = edges(ivo, 3:4);
end

nc = length(neighbour); %number of neighbouring cells corresponding to index of element
%QT  =[cos(alpha) sin(alpha); -sin(alpha) cos(alpha)];
%==================================%
%      K_SXFEM stiffness matrix    %
%==================================%
if (strcmp(elemType, 'T3'))
    area_al = 0;
    alpha = 2/3;
    
    for i = 1:nc
        kcc = neighbour(i); % index of element
        sctr = element(kcc, :);
        nodes = node(sctr, :);
        %   n=element(kcc,:);
        gcoord(:, 1) = [node(sctr, 1); mean(node(sctr, 1))];
        gcoord(:, 2) = [node(sctr, 2); mean(node(sctr, 2))];
        node_sc = [1 2 4; 2 3 4; 3 1 4];
        % loop on the two segments in cell kcc against node ia
        % dof_enr=2*sum(enrich_node(sctr));
        %for isc=1:nsc % loop sub cell element
        
        xsupp = supp{kcc}; % support node numbering
        nsf = length(xsupp);
        bx = zeros(nsf, 1);
        by = zeros(nsf, 1);
        
        if sum(edges(ivo, 1:2)) == sum(sctr(1:2))
            gcoord(4, :) = alpha * (gcoord(1, :) + gcoord(2, :)) / 2 + (1 - alpha) * gcoord(3, :);
            xx = gcoord(node_sc(1, :), 1);
            yy = gcoord(node_sc(1, :), 2);
            side = cal_side(xx, yy);
            area_al = area_al + cal_area(xx, yy);
            [nx, ny] = cal_nx_ny(xx, yy, side);
            ns = length(xx); % number side of sub element. T3 ==>ns=3
            
            for is = 1:ns% loop ns-sides of sub cell element-two gauss points per side
                [W, Q] = quadrature(ng, 'GAUSS', 1);
                
                for ig = 1:ng
                    %Bs_enr=[];
                    N_g = lagrange_basis('L2', Q(ig));
                    [xi1, eta1] = xi_eta4xy('T3', is, N_g);
                    N_xy = lagrange_basis('T3', [xi1 eta1]);
                    xy_g = N_xy' * [xx yy];
                    
                    xieta = cal_xieta('T3', xy_g, nodes);
                    N_T = lagrange_basis(elemType, xieta);
                    
                    %               plot_g=[plot_g;xy_g];
                    J2 = side(is) / 2; % Jacobian matrix for L2
                    
                    bx = bx + nx(is) * N_T * J2 * W(ig);
                    by = by + ny(is) * N_T * J2 * W(ig);
                end % end loop of gauss points on side
                
            end %end of side
            
        end % end if
        
        if sum(edges(ivo, 1:2)) == sum(sctr(2:3))
            gcoord(4, :) = alpha * (gcoord(2, :) + gcoord(3, :)) / 2 + (1 - alpha) * gcoord(1, :);
            xx = gcoord(node_sc(2, :), 1);
            yy = gcoord(node_sc(2, :), 2);
            side = cal_side(xx, yy);
            area_al = area_al + cal_area(xx, yy);
            [nx, ny] = cal_nx_ny(xx, yy, side);
            ns = length(xx); % number side of sub element. T3 ==>ns=3
            
            for is = 1:ns% loop ns-sides of sub cell element-two gauss points per side
                [W, Q] = quadrature(ng, 'GAUSS', 1);
                
                for ig = 1:ng
                    %Bs_enr=[];
                    N_g = lagrange_basis('L2', Q(ig));
                    [xi1, eta1] = xi_eta4xy('T3', is, N_g);
                    N_xy = lagrange_basis('T3', [xi1 eta1]);
                    xy_g = N_xy' * [xx yy];
                    xieta = cal_xieta('T3', xy_g, nodes);
                    N_T = lagrange_basis(elemType, xieta);
                    
                    %               plot_g=[plot_g;xy_g];
                    J2 = side(is) / 2; % Jacobian matrix for L2
                    
                    bx = bx + nx(is) * N_T * J2 * W(ig);
                    by = by + ny(is) * N_T * J2 * W(ig);
                end % end loop of gauss points on side
                
            end %end of side
            
        end
        
        if sum(edges(ivo, 1:2)) == sctr(3) + sctr(1)
            gcoord(4, :) = alpha * (gcoord(3, :) + gcoord(1, :)) / 2 + (1 - alpha) * gcoord(2, :);
            xx = gcoord(node_sc(3, :), 1);
            yy = gcoord(node_sc(3, :), 2);
            side = cal_side(xx, yy);
            [nx, ny] = cal_nx_ny(xx, yy, side);
            area_al = area_al + cal_area(xx, yy);
            ns = length(xx); % number side of sub element. T3 ==>ns=3
            
            for is = 1:ns% loop ns-sides of sub cell element-two gauss points per side
                [W, Q] = quadrature(ng, 'GAUSS', 1);
                
                for ig = 1:ng
                    %Bs_enr=[];
                    N_g = lagrange_basis('L2', Q(ig));
                    [xi1, eta1] = xi_eta4xy('T3', is, N_g);
                    N_xy = lagrange_basis('T3', [xi1 eta1]);
                    xy_g = N_xy' * [xx yy];
                    
                    xieta = cal_xieta('T3', xy_g, nodes);
                    N_T = lagrange_basis(elemType, xieta);
                    
                    %  plot_g=[plot_g;xy_g];
                    J2 = side(is) / 2; % Jacobian matrix for L2
                    
                    bx = bx + nx(is) * N_T * J2 * W(ig);
                    by = by + ny(is) * N_T * J2 * W(ig);
                end % end loop of gauss points on side
                
            end %end of side
            
        end
        
        %bx=bx/area;
        %by=by/area;
        if i == 1
            nodL = element(neighbour(i), :);
            nn = nsf;
            
            for jj = 1:nn
                B_sfem(1, 2 * jj - 1) = bx(jj);
                B_sfem(2, 2 * jj) = by(jj);
                B_sfem(3, 2 * jj - 1) = by(jj);
                B_sfem(3, 2 * jj) = bx(jj);
                %
                L1_sfem(1, 2 * jj - 1) = bx(jj);
                L1_sfem(2, 2 * jj) = by(jj);
                
                L2_sfem(1, 2 * jj - 1) = by(jj);
                L2_sfem(2, 2 * jj) = bx(jj);
            end
            
        else
            i0 = 0;
            
            for jj = 1:nsf
                nod = element(neighbour(i), jj); %supp{neighbour(i)}(jj);
                flag = 0;
                
                for j = 1:nn
                    
                    if nodL(j) == nod
                        B_sfem(1, 2 * j - 1) = B_sfem(1, 2 * j - 1) + bx(jj);
                        B_sfem(2, 2 * j) = B_sfem(2, 2 * j) + by(jj);
                        B_sfem(3, 2 * j - 1) = B_sfem(3, 2 * j - 1) + by(jj);
                        B_sfem(3, 2 * j) = B_sfem(3, 2 * j) + bx(jj);
                        %
                        L1_sfem(1, 2 * jj - 1) = L1_sfem(1, 2 * jj - 1) + bx(jj);
                        L1_sfem(2, 2 * jj) = L1_sfem(2, 2 * jj) + by(jj);
                        
                        L2_sfem(1, 2 * jj - 1) = L2_sfem(1, 2 * jj - 1) + by(jj);
                        L2_sfem(2, 2 * jj) = L2_sfem(2, 2 * jj) + bx(jj);
                        flag = 1; break
                    end
                    
                end
                
                if flag == 0
                    i0 = i0 + 1;
                    nodL(nn + i0) = nod;
                    B_sfem(1, 2 * (nn + i0) - 1) = bx(jj);
                    B_sfem(2, 2 * (nn + i0)) = by(jj);
                    B_sfem(3, 2 * (nn + i0) - 1) = by(jj);
                    B_sfem(3, 2 * (nn + i0)) = bx(jj);
                    %
                    L1_sfem(1, 2 * (nn + i0) - 1) = bx(jj);
                    L1_sfem(2, 2 * (nn + i0)) = by(jj);
                    
                    L2_sfem(1, 2 * (nn + i0) - 1) = by(jj);
                    L2_sfem(2, 2 * (nn + i0)) = bx(jj);
                end
                
            end
            
            nn = nn + i0;
        end %end else
        
    end %number of neighbouring cells
    
    area = area_al;
    B_sfem = B_sfem / area;
    G_sc = B_sfem' * Dlamda * B_sfem * area;
    S_sc = (L1_sfem' * L1_sfem + L2_sfem' * L2_sfem) * area;
    numnod = length(nodL);
    sctrB(1:2:2 * numnod) = 2 .* nodL - 1;
    sctrB(2:2:2 * numnod) = 2 .* nodL;
    
    G(sctrB, sctrB) = G(sctrB, sctrB) + G_sc;
    S(sctrB, sctrB) = S(sctrB, sctrB) + S_sc;
    clear B_sfem G_sc S_sc nodL sctrB;
    
elseif (strcmp(elemType, 'T4'))
    
    for i = 1:nc
        kcc = neighbour(i); % index of element
        sctr = element(kcc, :);
        nodes = node(sctr, :);
        gcoord(:, 1) = node(sctr, 1);
        gcoord(:, 2) = node(sctr, 2);
        node_sc = [1 2 4; 2 3 4; 3 1 4];
        % loop on the two segments in cell kcc against node ia
        xsupp = supp{kcc}; % support node numbering
        nsf = length(xsupp);
        bx = zeros(nsf, 1);
        by = zeros(nsf, 1);
        
        if sum(edges(ivo, 1:2)) == sum(sctr(1:2))
            xx = gcoord(node_sc(1, :), 1);
            yy = gcoord(node_sc(1, :), 2);
            side = cal_side(xx, yy);
            [nx, ny] = cal_nx_ny(xx, yy, side);
            ns = length(xx); % number side of sub element. T3 ==>ns=3
            
            for is = 1:ns% loop ns-sides of sub cell element-two gauss points per side
                [W, Q] = quadrature(ng, 'GAUSS', 1);
                
                for ig = 1:ng
                    %Bs_enr=[];
                    N_g = lagrange_basis('L2', Q(ig));
                    [xi1, eta1] = xi_eta4xy('T3', is, N_g);
                    N_xy = lagrange_basis('T3', [xi1 eta1]);
                    xy_g = N_xy' * [xx yy];
                    
                    xieta = cal_xieta('T3', xy_g, nodes);
                    N_T = lagrange_basis(elemType, xieta);
                    
                    %               plot_g=[plot_g;xy_g];
                    J2 = side(is) / 2; % Jacobian matrix for L2
                    
                    bx = bx + nx(is) * N_T * J2 * W(ig);
                    by = by + ny(is) * N_T * J2 * W(ig);
                end % end loop of gauss points on side
                
            end %end of side
            
        end % end if
        
        if sum(edges(ivo, 1:2)) == sum(sctr(2:3))
            xx = gcoord(node_sc(2, :), 1);
            yy = gcoord(node_sc(2, :), 2);
            side = cal_side(xx, yy);
            [nx, ny] = cal_nx_ny(xx, yy, side);
            ns = length(xx); % number side of sub element. T3 ==>ns=3
            
            for is = 1:ns% loop ns-sides of sub cell element-two gauss points per side
                [W, Q] = quadrature(ng, 'GAUSS', 1);
                
                for ig = 1:ng
                    %Bs_enr=[];
                    N_g = lagrange_basis('L2', Q(ig));
                    [xi1, eta1] = xi_eta4xy('T3', is, N_g);
                    N_xy = lagrange_basis('T3', [xi1 eta1]);
                    xy_g = N_xy' * [xx yy];
                    xieta = cal_xieta('T3', xy_g, nodes);
                    N_T = lagrange_basis(elemType, xieta);
                    
                    %               plot_g=[plot_g;xy_g];
                    J2 = side(is) / 2; % Jacobian matrix for L2
                    
                    bx = bx + nx(is) * N_T * J2 * W(ig);
                    by = by + ny(is) * N_T * J2 * W(ig);
                end % end loop of gauss points on side
                
            end %end of side
            
        end
        
        if sum(edges(ivo, 1:2)) == sctr(3) + sctr(1)
            xx = gcoord(node_sc(3, :), 1);
            yy = gcoord(node_sc(3, :), 2);
            side = cal_side(xx, yy);
            [nx, ny] = cal_nx_ny(xx, yy, side);
            ns = length(xx); % number side of sub element. T3 ==>ns=3
            
            for is = 1:ns% loop ns-sides of sub cell element-two gauss points per side
                [W, Q] = quadrature(ng, 'GAUSS', 1);
                
                for ig = 1:ng
                    %Bs_enr=[];
                    N_g = lagrange_basis('L2', Q(ig));
                    [xi1, eta1] = xi_eta4xy('T3', is, N_g);
                    N_xy = lagrange_basis('T3', [xi1 eta1]);
                    xy_g = N_xy' * [xx yy];
                    
                    xieta = cal_xieta('T3', xy_g, nodes);
                    N_T = lagrange_basis(elemType, xieta);
                    
                    %  plot_g=[plot_g;xy_g];
                    J2 = side(is) / 2; % Jacobian matrix for L2
                    
                    bx = bx + nx(is) * N_T * J2 * W(ig);
                    by = by + ny(is) * N_T * J2 * W(ig);
                end % end loop of gauss points on side
                
            end %end of side
            
        end
        
        bx = bx / area;
        by = by / area;
        
        if i == 1
            nodL = element(neighbour(i), :);
            nn = nsf;
            
            for jj = 1:nn
                B_sfem(1, 2 * jj - 1) = bx(jj);
                B_sfem(2, 2 * jj) = by(jj);
                B_sfem(3, 2 * jj - 1) = by(jj);
                B_sfem(3, 2 * jj) = bx(jj);
                %
                L1_sfem(1, 2 * jj - 1) = bx(jj);
                L1_sfem(2, 2 * jj) = by(jj);
                
                L2_sfem(1, 2 * jj - 1) = by(jj);
                L2_sfem(2, 2 * jj) = bx(jj);
            end
            
        else
            i0 = 0;
            
            for jj = 1:nsf
                nod = element(neighbour(i), jj); %supp{neighbour(i)}(jj);
                flag = 0;
                
                for j = 1:nn
                    
                    if nodL(j) == nod
                        B_sfem(1, 2 * j - 1) = B_sfem(1, 2 * j - 1) + bx(jj);
                        B_sfem(2, 2 * j) = B_sfem(2, 2 * j) + by(jj);
                        B_sfem(3, 2 * j - 1) = B_sfem(3, 2 * j - 1) + by(jj);
                        B_sfem(3, 2 * j) = B_sfem(3, 2 * j) + bx(jj);
                        %
                        L1_sfem(1, 2 * jj - 1) = L1_sfem(1, 2 * jj - 1) + bx(jj);
                        L1_sfem(2, 2 * jj) = L1_sfem(2, 2 * jj) + by(jj);
                        
                        L2_sfem(1, 2 * jj - 1) = L2_sfem(1, 2 * jj - 1) + by(jj);
                        L2_sfem(2, 2 * jj) = L2_sfem(2, 2 * jj) + bx(jj);
                        flag = 1; break
                    end
                    
                end
                
                if flag == 0
                    i0 = i0 + 1;
                    nodL(nn + i0) = nod;
                    B_sfem(1, 2 * (nn + i0) - 1) = bx(jj);
                    B_sfem(2, 2 * (nn + i0)) = by(jj);
                    B_sfem(3, 2 * (nn + i0) - 1) = by(jj);
                    B_sfem(3, 2 * (nn + i0)) = bx(jj);
                    %
                    L1_sfem(1, 2 * (nn + i0) - 1) = bx(jj);
                    L1_sfem(2, 2 * (nn + i0)) = by(jj);
                    
                    L2_sfem(1, 2 * (nn + i0) - 1) = by(jj);
                    L2_sfem(2, 2 * (nn + i0)) = bx(jj);
                end
                
            end
            
            nn = nn + i0;
        end %end else
        
    end %number of neighbouring cells
    
    %nodL
    clear xx yy x y n;
    
    if length(nodL) == 6
        B_sfem = [B_sfem(:, 1:6) B_sfem(:, 9:10) B_sfem(:, 7:8) B_sfem(:, 11:12)];
        L1_sfem = [L1_sfem(:, 1:6) L1_sfem(:, 9:10) L1_sfem(:, 7:8) L1_sfem(:, 11:12)];
        L2_sfem = [L2_sfem(:, 1:6) L2_sfem(:, 9:10) L2_sfem(:, 7:8) L2_sfem(:, 11:12)];
        
        %    Ke_sc = B_sm'*D*B_sm*area;
        %    kee=Ke_sc(1:8,1:8);
        %    kei=Ke_sc(1:8,9:12);
        %    kie=Ke_sc(9:12,1:8);
        %    kii=Ke_sc(9:12,9:12);
        %    det(kii)
        %    Ksc=kee-(kei/kii)*kie;
        %    nodL=[nodL(1:3) nodL(5)];
        nodL = [nodL(1:3) nodL(5) nodL(4) nodL(6)];
        %   elseif length(nodL)==4
        %    Ke_sc = B_sm'*D*B_sm*area;
        %    kee=Ke_sc(1:6,1:6);
        %    kei=Ke_sc(1:6,7:8);
        %    kie=Ke_sc(7:8,1:6);
        %    kii=Ke_sc(7:8,7:8);
        %    Ksc=kee-(kei/kii)*kie;
        %    nodL=nodL(1:3);
    end
    
    G_sc = B_sfem' * Dlamda * B_sfem * area;
    S_sc = (L1_sfem' * L1_sfem + L2_sfem' * L2_sfem) * area;
    numnod = length(nodL);
    sctrB(1:2:2 * numnod) = 2 .* nodL - 1;
    sctrB(2:2:2 * numnod) = 2 .* nodL;
    
    % eliminate condensation (way 1)
    %K(sctrB,sctrB) = K(sctrB,sctrB) + Ksc;
    % no eliminate condensation (way 2)
    G(sctrB, sctrB) = G(sctrB, sctrB) + G_sc;
    S(sctrB, sctrB) = S(sctrB, sctrB) + S_sc;
    %  rank(Ke_sc)
    clear B_sfem G_sc L1_sfem L2_sfem S_sc nodL sctrB;
else
    disp('Number smoothing cells of element are not implemented');
    return
end
end
