function Mass=Lumped_mass(n,area,rho)

Mass=zeros(n,n);
switch n
    case 8
        for i=1:n
            Mass(i,i)=0.25*area*rho;
        end
    case 16
        for i=1:16
            Mass(i,i)=0.2*area*rho;
        end
        for i=1:4:13
            Mass(i,i)=0.25*Mass(3,3);
        end
        for i=2:4:14
            Mass(i,i)=0.25*Mass(3,3);
        end
    otherwise 
        disp([num2str(toc),'   Wrong number of nodes for rectangular element'])
end