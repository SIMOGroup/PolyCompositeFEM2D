function [Ac]=area_sc(x,y)


if length(x)==3    
    
    Ac=0.5*(x(1)*y(2)+x(2)*y(3)+x(3)*y(1)-...
        x(1)*y(3)-x(2)*y(1)-x(3)*y(2));               

elseif length(x)==4
    dis_1=sqrt((x(3)-x(1))^2+(y(3)-y(1))^2);
    dis_2=sqrt((x(4)-x(2))^2+(y(4)-y(2))^2);
    [angleA,angleB,angleC,angleD]=cal_angle(x,y);
    if angleA >= pi | angleC >= pi   
        area1=0.5*(x(1)*y(2)+x(2)*y(3)+x(3)*y(1)-...
            x(1)*y(3)-x(2)*y(1)-x(3)*y(2));               %area of 1st triangula 
        area2=0.5*(x(1)*y(3)+x(3)*y(4)+x(4)*y(1)-...
            x(1)*y(4)-x(3)*y(1)-x(4)*y(3));               %area of 2rd triangula 
        Ac=area1+area2;
        clear area1 area2
    elseif angleB >= pi | angleD >= pi
        area1=0.5*(x(1)*y(2)+x(2)*y(4)+x(4)*y(1)-...
            x(1)*y(4)-x(2)*y(1)-x(4)*y(2));               %area of 1st triangula 
        area2=0.5*(x(2)*y(3)+x(3)*y(4)+x(4)*y(2)-...
            x(2)*y(4)-x(3)*y(2)-x(4)*y(3));               %area of 2rd triangula 
        Ac=area1+area2;
        clear area1 area2
    elseif angleA < pi & angleB < pi & angleC < pi & angleD < pi & dis_1 <= dis_2 
        area1=0.5*(x(1)*y(2)+x(2)*y(3)+x(3)*y(1)-...
            x(1)*y(3)-x(2)*y(1)-x(3)*y(2));               %area of 1st triangula 
        area2=0.5*(x(1)*y(3)+x(3)*y(4)+x(4)*y(1)-...
            x(1)*y(4)-x(3)*y(1)-x(4)*y(3));               %area of 2rd triangula 
        Ac=area1+area2;
        clear area1 area2
    elseif angleA < pi & angleB < pi & angleC < pi & angleD < pi & dis_1 > dis_2 
        area1=0.5*(x(1)*y(2)+x(2)*y(4)+x(4)*y(1)-...
            x(1)*y(4)-x(2)*y(1)-x(4)*y(2));               %area of 1st triangula 
        area2=0.5*(x(2)*y(3)+x(3)*y(4)+x(4)*y(2)-...
            x(2)*y(4)-x(3)*y(2)-x(4)*y(3));               %area of 2rd triangula 
        Ac=area1+area2;
        clear area1 area2
    end
elseif length(x)==5
    
    area1=0.5*(x(1)*y(2)+x(2)*y(3)+x(3)*y(1)-...
        x(1)*y(3)-x(2)*y(1)-x(3)*y(2));               %area of 1st triangula 
    
    area2=0.5*(x(1)*y(3)+x(3)*y(4)+x(4)*y(1)-...
        x(1)*y(4)-x(3)*y(1)-x(4)*y(3));               %area of 2rd triangula 
    
    area3=0.5*(x(1)*y(4)+x(4)*y(5)+x(5)*y(1)-...
        x(1)*y(5)-x(4)*y(1)-x(5)*y(4));               %area of 3nd triangula 
    
    Ac=area1+area2+area3;
    clear area1 area2 area3
    
elseif length(x)==6
    
    area1=0.5*(x(1)*y(2)+x(2)*y(3)+x(3)*y(1)-...
        x(1)*y(3)-x(2)*y(1)-x(3)*y(2));               %area of 1st triangula 
    
    area2=0.5*(x(1)*y(3)+x(3)*y(4)+x(4)*y(1)-...
        x(1)*y(4)-x(3)*y(1)-x(4)*y(3));               %area of 2rd triangula 
    
    area3=0.5*(x(1)*y(4)+x(4)*y(5)+x(5)*y(1)-...
        x(1)*y(5)-x(4)*y(1)-x(5)*y(4));               %area of 3nd triangula 
    
    area4=0.5*(x(1)*y(5)+x(5)*y(6)+x(6)*y(1)-...
        x(1)*y(6)-x(5)*y(1)-x(6)*y(5));               %area of 4th triangula 
    
    Ac=area1+area2+area3+area4;
    clear area1 area2 area3 area4
end


