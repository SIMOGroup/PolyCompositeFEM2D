function [nodL,B_sfem]= stress_salphaFEM(ivo,elemType,neighbour,area,supp,ng)
                          
global node element
nc = length(neighbour); %number of neighbouring cells corresponding to index of element (No of element)
if (strcmp(elemType,'T3'))
  for i = 1:nc % num of element
    kcc = neighbour(i);% index of element
    sctr = element(kcc,:);
    nodes = node(sctr,:);
    
    for inode=1:3
        n(inode) = element(kcc,inode);
        x(inode) = node(n(inode),1);
        y(inode) = node(n(inode),2); 
    end    
    xm1 = (node(n(1),1)+node(n(2),1))/2; ym1 = (node(n(1),2)+node(n(2),2))/2;
    xm2 = (node(n(2),1)+node(n(3),1))/2; ym2 = (node(n(2),2)+node(n(3),2))/2;
    xm3 = (node(n(3),1)+node(n(1),1))/2; ym3 = (node(n(3),2)+node(n(1),2))/2;
    xm4 = (node(n(1),1)+node(n(2),1)+node(n(3),1))/3;
    ym4 = (node(n(1),2)+node(n(2),2)+node(n(3),2))/3;
    x_sc=[x';xm1;xm2;xm3;xm4];
    y_sc=[y';ym1;ym2;ym3;ym4];
        
    gcoord(:,1)=x_sc;
    gcoord(:,2)=y_sc;
    node_sc1=[1 4 7; 1 7 6];
    node_sc2=[2 5 7; 2 7 4];
    node_sc3=[3 6 7; 3 7 5];% corner nodes
    
    % loop on the two segments in cell kcc against node ia 
    % dof_enr=2*sum(enrich_node(sctr));
    %for isc=1:nsc % loop sub cell element
    xsupp = supp{neighbour(i)}; % support node numbering
    nsf = length(xsupp);
    %B_sfem=[];%zeros(3,2*nsf);
    %B_enr=zeros(3,dof_enr);
    bx=zeros(nsf,1);
    by=zeros(nsf,1);
    if (ivo == n(1))
     for icel=1:2
       xx=gcoord(node_sc1(icel,:),1);
       yy=gcoord(node_sc1(icel,:),2);
       side=cal_side(xx,yy);
       [nx,ny]=cal_nx_ny(xx,yy,side);
       ns=length(xx); % number side of sub element. T3 ==>ns=3
       for is=1:ns % loop ns-sides of sub cell element-two gauss points per side
            [W,Q]=quadrature(ng,'GAUSS',1);
            for ig=1:ng
                %Bs_enr=[];
                N_g=lagrange_basis('L2',Q(ig));
                [xi1,eta1]=xi_eta4xy('T3',is,N_g);
                N_xy=lagrange_basis('T3',[xi1 eta1]);
                xy_g=N_xy'*[xx yy];

                xieta=cal_xieta('T3',xy_g,nodes);
                N_T=lagrange_basis(elemType,xieta);

%               plot_g=[plot_g;xy_g];
                J2=side(is)/2; % Jacobian matrix for L2 
                
                bx=bx + nx(is)*N_T*J2*W(ig);
                by=by + ny(is)*N_T*J2*W(ig);
            end % end loop of gauss points on side
       end %end of side
     end 
    end
  if (ivo == n(2))
     for icel=1:2
       xx=gcoord(node_sc2(icel,:),1);
       yy=gcoord(node_sc2(icel,:),2);
       side=cal_side(xx,yy);
       [nx,ny]=cal_nx_ny(xx,yy,side);
       ns=length(xx); % number side of sub element. T3 ==>ns=3
       for is=1:ns % loop ns-sides of sub cell element-two gauss points per side
            [W,Q]=quadrature(ng,'GAUSS',1);
            for ig=1:ng
                %Bs_enr=[];
                N_g=lagrange_basis('L2',Q(ig));
                [xi1,eta1]=xi_eta4xy('T3',is,N_g);
                N_xy=lagrange_basis('T3',[xi1 eta1]);
                xy_g=N_xy'*[xx yy];
                xieta=cal_xieta('T3',xy_g,nodes);
                N_T=lagrange_basis(elemType,xieta);

%               plot_g=[plot_g;xy_g];
                J2=side(is)/2; % Jacobian matrix for L2 
                
                bx=bx + nx(is)*N_T*J2*W(ig);
                by=by + ny(is)*N_T*J2*W(ig);
            end % end loop of gauss points on side
       end %end of side
     end
   end  
   if (ivo == n(3))
      for icel=1:2
       xx=gcoord(node_sc3(icel,:),1);
       yy=gcoord(node_sc3(icel,:),2);
       side=cal_side(xx,yy);
       [nx,ny]=cal_nx_ny(xx,yy,side);
       ns=length(xx); % number side of sub element. T3 ==>ns=3
       for is=1:ns % loop ns-sides of sub cell element-two gauss points per side
            [W,Q]=quadrature(ng,'GAUSS',1);
            for ig=1:ng
                %Bs_enr=[];
                N_g=lagrange_basis('L2',Q(ig));
                [xi1,eta1]=xi_eta4xy('T3',is,N_g);
                N_xy=lagrange_basis('T3',[xi1 eta1]);
                xy_g=N_xy'*[xx yy];

                xieta=cal_xieta('T3',xy_g,nodes);
                N_T=lagrange_basis(elemType,xieta);

%               plot_g=[plot_g;xy_g];
                J2=side(is)/2; % Jacobian matrix for L2 
                
                bx=bx + nx(is)*N_T*J2*W(ig);
                by=by + ny(is)*N_T*J2*W(ig);
            end % end loop of gauss points on side
       end %end of side
      end
   end
   clear W Q;
   bx=bx/area;
   by=by/area;
   if i==1
           nodL=element(neighbour(i),:);%supp{neighbour(i)};
           nn=nsf;% num of node of each element
           for jj=1:nn
            B_sfem(1,2*jj-1)=bx(jj);
            B_sfem(2,2*jj)=by(jj);
            B_sfem(3,2*jj-1)=by(jj);
            B_sfem(3,2*jj)=bx(jj);
           end
     else  
          i0=0;
          for jj=1:nsf
                nod=element(neighbour(i),jj);%supp{neighbour(i)}(jj);
                flag=0;
              for j=1:nn
                  if nodL(j)==nod
                      B_sfem(1,2*j-1)=B_sfem(1,2*j-1)+bx(jj);
                      B_sfem(2,2*j)=B_sfem(2,2*j)+ by(jj);
                      B_sfem(3,2*j-1)=B_sfem(3,2*j-1)+by(jj);
                      B_sfem(3,2*j)=B_sfem(3,2*j)+bx(jj);
                      flag=1;  break
                  end
              end
                if flag==0
                    i0=i0+1;
                    nodL(nn+i0)=nod;
                    B_sfem(1,2*(nn+i0)-1)=bx(jj);
                    B_sfem(2,2*(nn+i0))=by(jj);
                    B_sfem(3,2*(nn+i0)-1)=by(jj);
                    B_sfem(3,2*(nn+i0))=bx(jj);
                end
           end 
             nn=nn+i0;             
     end  %end else
 end %number of neighbouring cells
 % nodL   
%   if ( any(enrich_node(sctr)) == 0 ) % Non-enriched elements
%                 B_sm=B_sfem;
%   else
%                 B_sm=[B_sfem B_enr];
%   end
    
 elseif (strcmp(elemType,'Q4'))
 for i = 1:nc  
    kcc = neighbour(i);% index of element
    sctr = element(kcc,:);
    nodes = node(sctr,:);
    
    for inode=1:4
        n(inode) = element(kcc,inode);
        x(inode) = node(n(inode),1);
        y(inode) = node(n(inode),2); 
    end 
    x_sc=[x';1/2*(x(1)+x(2));1/2*(x(2)+x(3));...
            1/2*(x(3)+x(4));1/2*(x(4)+x(1));1/4*(x(1)+x(2)+x(3)+x(4))];
    y_sc=[y';1/2*(y(1)+y(2));1/2*(y(2)+y(3));...
            1/2*(y(3)+y(4));1/2*(y(4)+y(1));1/4*(y(1)+y(2)+y(3)+y(4))];
        
    gcoord(:,1)=x_sc;
    gcoord(:,2)=y_sc;
    
    %       4------7-----3
    %       | sc4  | sc3 |
    %       8------9-----6
    %       | sc1  | sc2 | 
    %       1------5-----2    
        
        node_sc=[1 5 9 8;
                 2 6 9 5;
                 3 7 9 6;
                 4 8 9 7];
    
    xsupp = supp{neighbour(i)}; % support node numbering
    nsf = length(xsupp);
    %B_sfem=[];%zeros(3,2*nsf);
    % B_enr=zeros(3,dof_enr);
    bx=zeros(nsf,1);
    by=zeros(nsf,1);
    
   if (ivo == n(1))
       xx=gcoord(node_sc(1,:),1);
       yy=gcoord(node_sc(1,:),2);
       %Ac=area_sc(xx,yy);
       side=cal_side(xx,yy);
       [nx,ny]=cal_nx_ny(xx,yy,side);
       ns=length(xx); % number side of sub element. T3 ==>ns=3
       for is=1:ns % loop ns-sides of sub cell element-two gauss points per side
            [W,Q]=quadrature(ng,'GAUSS',1);
            for ig=1:ng
                %Bs_enr=[];
                N_g=lagrange_basis('L2',Q(ig));
                [xi1,eta1]=xi_eta4xy('Q4',is,N_g);
                N_xy=lagrange_basis('Q4',[xi1 eta1]);
                xy_g=N_xy'*[xx yy];

                xieta=cal_xieta('Q4',xy_g,nodes);
                N_T=lagrange_basis(elemType,xieta);

%               plot_g=[plot_g;xy_g];
                J2=side(is)/2; % Jacobian matrix for L2 
                
                bx=bx + nx(is)*N_T*J2*W(ig);
                by=by + ny(is)*N_T*J2*W(ig);
            end % end loop of gauss points on side
       end %end of side
   end
    if (ivo == n(2))
      xx=gcoord(node_sc(2,:),1);
       yy=gcoord(node_sc(2,:),2);
       %Ac=area_sc(xx,yy);
       side=cal_side(xx,yy);
       [nx,ny]=cal_nx_ny(xx,yy,side);
       ns=length(xx); % number side of sub element. T3 ==>ns=3
       for is=1:ns % loop ns-sides of sub cell element-two gauss points per side
            [W,Q]=quadrature(ng,'GAUSS',1);
            for ig=1:ng
                %Bs_enr=[];
                N_g=lagrange_basis('L2',Q(ig));
                [xi1,eta1]=xi_eta4xy('Q4',is,N_g);
                N_xy=lagrange_basis('Q4',[xi1 eta1]);
                xy_g=N_xy'*[xx yy];
                xieta=cal_xieta('Q4',xy_g,nodes);
                N_T=lagrange_basis(elemType,xieta);

%               plot_g=[plot_g;xy_g];
                J2=side(is)/2; % Jacobian matrix for L2 
                
                bx=bx + nx(is)*N_T*J2*W(ig);
                by=by + ny(is)*N_T*J2*W(ig);
            end % end loop of gauss points on side
       end %end of side
   end
   if (ivo == n(3))
       xx=gcoord(node_sc(3,:),1);
       yy=gcoord(node_sc(3,:),2);
       %Ac=area_sc(xx,yy);
       side=cal_side(xx,yy);
       [nx,ny]=cal_nx_ny(xx,yy,side);
       ns=length(xx); % number side of sub element. T3 ==>ns=3
       for is=1:ns % loop ns-sides of sub cell element-two gauss points per side
            [W,Q]=quadrature(ng,'GAUSS',1);
            for ig=1:ng
                %Bs_enr=[];
                N_g=lagrange_basis('L2',Q(ig));
                [xi1,eta1]=xi_eta4xy('Q4',is,N_g);
                N_xy=lagrange_basis('Q4',[xi1 eta1]);
                xy_g=N_xy'*[xx yy];

                xieta=cal_xieta('Q4',xy_g,nodes);
                N_T=lagrange_basis(elemType,xieta);

%               plot_g=[plot_g;xy_g];
                J2=side(is)/2; % Jacobian matrix for L2 
                
                bx=bx + nx(is)*N_T*J2*W(ig);
                by=by + ny(is)*N_T*J2*W(ig);
            end % end loop of gauss points on side
       end %end of side
    end
      
   if (ivo == n(4))
      xx=gcoord(node_sc(4,:),1);
       yy=gcoord(node_sc(4,:),2);
       %Ac=area_sc(xx,yy);
       side=cal_side(xx,yy);
       [nx,ny]=cal_nx_ny(xx,yy,side);
       ns=length(xx); % number side of sub element. T3 ==>ns=3
       for is=1:ns % loop ns-sides of sub cell element-two gauss points per side
            [W,Q]=quadrature(ng,'GAUSS',1);
            for ig=1:ng
                %Bs_enr=[];
                N_g=lagrange_basis('L2',Q(ig));
                [xi1,eta1]=xi_eta4xy('Q4',is,N_g);
                N_xy=lagrange_basis('Q4',[xi1 eta1]);
                xy_g=N_xy'*[xx yy];

                xieta=cal_xieta('Q4',xy_g,nodes);
                N_T=lagrange_basis(elemType,xieta);

%               plot_g=[plot_g;xy_g];
                J2=side(is)/2; % Jacobian matrix for L2 
                
                bx=bx + nx(is)*N_T*J2*W(ig);
                by=by + ny(is)*N_T*J2*W(ig);
            end % end loop of gauss points on side
       end %end of side
   end
     bx=bx/area;
     by=by/area;
     if i==1
           nodL=supp{neighbour(i)};
           nn=nsf;
           for jj=1:nn
           B_sfem(1,2*jj-1)=bx(jj);
           B_sfem(2,2*jj)=by(jj);
           B_sfem(3,2*jj-1)=by(jj);
           B_sfem(3,2*jj)=bx(jj);
           end
     else  
          i0=0;
          for jj=1:nsf
                nod=supp{neighbour(i)}(jj);
                flag=0;
              for j=1:nn
                  if nodL(j)==nod
                      B_sfem(1,2*j-1)=B_sfem(1,2*j-1)+bx(jj);
                      B_sfem(2,2*j)=B_sfem(2,2*j)+ by(jj);
                      B_sfem(3,2*j-1)=B_sfem(3,2*j-1)+by(jj);
                      B_sfem(3,2*j)=B_sfem(3,2*j)+bx(jj);
                      flag=1;  break
                  end
              end
                if flag==0
                    i0=i0+1;
                    nodL(nn+i0)=nod;
                    B_sfem(1,2*(nn+i0)-1)=bx(jj);
                    B_sfem(2,2*(nn+i0))=by(jj);
                    B_sfem(3,2*(nn+i0)-1)=by(jj);
                    B_sfem(3,2*(nn+i0))=bx(jj);
                end
           end 
             nn=nn+i0;             
     end  %end else
 end %number of neighbouring cells
     %nodL
%  if ( any(enrich_node(sctr)) == 0 ) % Non-enriched elements
%                 B_sm=B_sfem;
%   else
%                 B_sm=[B_sfem B_enr];
%   end
%       clear B_sfem xx yy x y n;
else
   disp('Number smoothing cells of element are not implemented');
   return
end



   

