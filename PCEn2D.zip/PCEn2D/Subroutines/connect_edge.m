
function [edges,area_cell]=connect_edge(elemType,numelem,index_edge)
global node element
% compute area of sup domain
if (strcmp(elemType,'T3'))
edge_list=zeros(3*numelem,4);
for iel=1:numelem
    if index_edge(iel,4)==-1
        edge_list(3*iel-2,:) = [index_edge(iel,1) index_edge(iel,2) iel 0];  
    else
        edge_list(3*iel-2,:) = [index_edge(iel,1) index_edge(iel,2) iel index_edge(iel,4)];          
    end   
   if index_edge(iel,5)==-1
        edge_list(3*iel-1,:) = [index_edge(iel,2) index_edge(iel,3) iel 0];  
    else
        edge_list(3*iel-1,:) = [index_edge(iel,2) index_edge(iel,3) iel index_edge(iel,5)];          
   end   
   if index_edge(iel,6)==-1
        edge_list(3*iel,:) = [index_edge(iel,3) index_edge(iel,1) iel 0];  
    else
        edge_list(3*iel,:) = [index_edge(iel,3) index_edge(iel,1) iel index_edge(iel,6)];          
   end   
end    
for i=1:size(edge_list,1)
edge_list(i,1:2)=unique(edge_list(i,1:2));    
edge_list(i,3:4)=unique(edge_list(i,3:4));
end

nn=size(edge_list);
for i=1:nn
    for j=i+1:nn
        if (edge_list(i,1)==edge_list(j,1))&(edge_list(i,2)==edge_list(j,2))&(edge_list(i,3)==edge_list(j,3))
            edge_list(j,:)=zeros(1,4);
        end
    end
end    

edges=[];
for i=1:nn
      if sum(edge_list(i,:))~=0
          edges=[edges;edge_list(i,:)];      
      end
end    
clear index_edge edge_list;
elseif (strcmp(elemType,'Q4'))
    edge_list=zeros(3*numelem,4);
for iel=1:numelem
    if index_edge(iel,4)==-1
        edge_list(3*iel-2,:) = [index_edge(iel,1) index_edge(iel,2) iel 0];  
    else
        edge_list(3*iel-2,:) = [index_edge(iel,1) index_edge(iel,2) iel index_edge(iel,4)];          
    end   
   if index_edge(iel,5)==-1
        edge_list(3*iel-1,:) = [index_edge(iel,2) index_edge(iel,3) iel 0];  
    else
        edge_list(3*iel-1,:) = [index_edge(iel,2) index_edge(iel,3) iel index_edge(iel,5)];          
   end   
   if index_edge(iel,6)==-1
        edge_list(3*iel,:) = [index_edge(iel,3) index_edge(iel,1) iel 0];  
    else
        edge_list(3*iel,:) = [index_edge(iel,3) index_edge(iel,1) iel index_edge(iel,6)];          
   end   
end    
for i=1:size(edge_list,1)
edge_list(i,1:2)=unique(edge_list(i,1:2));    
edge_list(i,3:4)=unique(edge_list(i,3:4));
end

nn=size(edge_list);
for i=1:nn
    for j=i+1:nn
        if (edge_list(i,1)==edge_list(j,1))&(edge_list(i,2)==edge_list(j,2))&(edge_list(i,3)==edge_list(j,3))
            edge_list(j,:)=zeros(1,4);
        end
    end
end    

edges=[];
for i=1:nn
      if sum(edge_list(i,:))~=0
          edges=[edges;edge_list(i,:)];      
      end
end    
clear index_edge edge_list;
elseif (strcmp(elemType,'T4'))
edge_list=zeros(3*numelem,4);
for iel=1:numelem
    if index_edge(iel,4)==-1
        edge_list(3*iel-2,:) = [index_edge(iel,1) index_edge(iel,2) iel 0];  
    else
        edge_list(3*iel-2,:) = [index_edge(iel,1) index_edge(iel,2) iel index_edge(iel,4)];          
    end   
   if index_edge(iel,5)==-1
        edge_list(3*iel-1,:) = [index_edge(iel,2) index_edge(iel,3) iel 0];  
    else
        edge_list(3*iel-1,:) = [index_edge(iel,2) index_edge(iel,3) iel index_edge(iel,5)];          
   end   
   if index_edge(iel,6)==-1
        edge_list(3*iel,:) = [index_edge(iel,3) index_edge(iel,1) iel 0];  
    else
        edge_list(3*iel,:) = [index_edge(iel,3) index_edge(iel,1) iel index_edge(iel,6)];          
   end   
end    
for i=1:size(edge_list,1)
edge_list(i,1:2)=unique(edge_list(i,1:2));    
edge_list(i,3:4)=unique(edge_list(i,3:4));
end
nn=size(edge_list);
for i=1:nn
    for j=i+1:nn
        if (edge_list(i,1)==edge_list(j,1))&(edge_list(i,2)==edge_list(j,2))&(edge_list(i,3)==edge_list(j,3))
            edge_list(j,:)=zeros(1,4);
        end
    end
end    
edges=[];
for i=1:nn
      if sum(edge_list(i,:))~=0
          edges=[edges;edge_list(i,:)];      
      end
end    
clear index_edge edge_list;
else % T6
edge_list=zeros(3*numelem,4);
for iel=1:numelem
    if index_edge(iel,4)==-1
        edge_list(3*iel-2,:) = [index_edge(iel,1) index_edge(iel,2) iel 0];  
    else
        edge_list(3*iel-2,:) = [index_edge(iel,1) index_edge(iel,2) iel index_edge(iel,4)];          
    end   
   if index_edge(iel,5)==-1
        edge_list(3*iel-1,:) = [index_edge(iel,2) index_edge(iel,3) iel 0];  
    else
        edge_list(3*iel-1,:) = [index_edge(iel,2) index_edge(iel,3) iel index_edge(iel,5)];          
   end   
   if index_edge(iel,6)==-1
        edge_list(3*iel,:) = [index_edge(iel,3) index_edge(iel,1) iel 0];  
    else
        edge_list(3*iel,:) = [index_edge(iel,3) index_edge(iel,1) iel index_edge(iel,6)];          
   end   
end    
for i=1:size(edge_list,1)
edge_list(i,1:2)=unique(edge_list(i,1:2));    
edge_list(i,3:4)=unique(edge_list(i,3:4));
end

nn=size(edge_list);
 for i=1:nn
    for j=i+1:nn
        if (edge_list(i,1)==edge_list(j,1))&(edge_list(i,2)==edge_list(j,2))&(edge_list(i,3)==edge_list(j,3))
            edge_list(j,:)=zeros(1,4);
        end
    end
 end
edges=[];
for i=1:nn
      if sum(edge_list(i,:))~=0
          edges=[edges;edge_list(i,:)];      
      end
end    
end
clear index_edge edge_list;
% compute area of sup domain
area_cell=zeros(1,length(edges));
for ie=1:length(edges)
   for je=3:4
       if edges(ie,je)~=0
         enode = element(edges(ie,je),1:3);  
         x=node(enode,1);
         y=node(enode,2);
         area_cell(ie)=area_cell(ie)+ abs(cal_area(x,y))/3;   
       end
   end   
end    
