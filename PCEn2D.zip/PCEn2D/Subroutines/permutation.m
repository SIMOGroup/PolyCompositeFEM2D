function [A,B]=permutation(A,B) 
   t=A;
   A =B; 
   B=t;
   return;
   