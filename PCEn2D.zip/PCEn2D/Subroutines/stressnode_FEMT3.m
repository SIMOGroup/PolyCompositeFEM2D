function stress_node=stressnode_FEMT3(nnode,nel,nodes,area_ele,stress_el)
stress_node=zeros(3,nnode);
% find neighouring cell of each node
neigh_node = cell(nnode,1);
for i=1:nnode   
    ind=0;
    for j=1:nel
       if (find(i==nodes(j,:)))>=1  
           ind = ind+1;
           neigh_node{i}(ind) = j; 
       end
    end
end
for i=1:nnode   
    node_area=0;
    for j=1:size(neigh_node{i},2)
        stress_node(:,i)= stress_node(:,i)+ stress_el(:,neigh_node{i}(j))* ...
                                              area_ele(neigh_node{i}(j));
        node_area = node_area + area_ele(neigh_node{i}(j));                                 
    end
    stress_node(:,i)= stress_node(:,i)/node_area;
end

