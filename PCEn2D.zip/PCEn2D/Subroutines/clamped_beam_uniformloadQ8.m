function [ff]=clamped_beam_uniformloadQ8(ndivx,ndivy,ndof,ff,p,D,caseload) 

delta_load=p*D/ndivy;
nodes_boundload=[]; 
for i=1:ndivy
    nodes_boundload=[nodes_boundload;(3*ndivx+2)*(i-1)+2*ndivx+1 (3*ndivx+2)*i (3*ndivx+2)*i+2*ndivx+1]
end   
if caseload==1 % Tai ngang
for i=1:ndivy
ff(ndof*nodes_boundload(i,1)-1)=ff(ndof*nodes_boundload(i,1)-1)+delta_load/6;
ff(ndof*nodes_boundload(i,2)-1)=ff(ndof*nodes_boundload(i,2)-1)+2*delta_load/3;
ff(ndof*nodes_boundload(i,3)-1)=ff(ndof*nodes_boundload(i,3)-1)+delta_load/6;
end
else % tai dung
for i=1:ndivy
ff(ndof*nodes_boundload(i,1))=ff(ndof*nodes_boundload(i,1))+delta_load/6;
ff(ndof*nodes_boundload(i,2))=ff(ndof*nodes_boundload(i,2))+2*delta_load/3;
ff(ndof*nodes_boundload(i,3))=ff(ndof*nodes_boundload(i,3))+delta_load/6;
end
end
