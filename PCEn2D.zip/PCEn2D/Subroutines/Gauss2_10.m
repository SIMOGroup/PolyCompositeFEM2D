%--------------------------------------------------------------------
function [point1 weight1]=Gauss2_10(ngl)
%--------------------------------------------------------------------
%  Purpose:
%     determine the integration points and weighting coefficients
%     of Gauss-Legendre quadrature for one-dimensional integration
%
%  Synopsis:
%     [point1,weight1]=Gauss10(ngl) 
%
%  Variable Description:
%     ngl - number of integration points
%     point1 - vector containing integration points   
%     weight1 - vector containing weighting coefficients 
%-------------------------------------------------------------------

%  find corresponding integration points and weights

 if ngl==1           % 1-point quadrature rule
    point1(1)=0.0;
    weight1(1)=2.0;

 elseif ngl==2       % 2-point quadrature rule
    point1(1)=-0.577350269189626;
    point1(2)=-point1(1);
    weight1(1)=1.0;
    weight1(2)=weight1(1);

 elseif ngl==3       % 3-point quadrature rule
    point1(1)=-0.774596669241483;
    point1(2)=0.0;
    point1(3)=-point1(1);
    weight1(1)=0.555555555555556;
    weight1(2)=0.888888888888889;
    weight1(3)=weight1(1);

 elseif ngl==4       % 4-point quadrature rule
    point1(1)=-0.861136311594053;
    point1(2)=-0.339981043584856;
    point1(3)=-point1(2);
    point1(4)=-point1(1);
    weight1(1)=0.347854845137454;
    weight1(2)=0.652145154862546;
    weight1(3)=weight1(2);
    weight1(4)=weight1(1);
elseif ngl==5       % 5-point quadrature rule
    point1(1)=-0.906179845938664;
    point1(2)=-0.538469310105683;
    point1(3)=0.0;
    point1(4)=-point1(2);
    point1(5)=-point1(1);
    weight1(1)=0.236926885056189;
    weight1(2)=0.478628670499366;
    weight1(3)=0.568888888888889;
    weight1(4)=weight1(2);
    weight1(5)=weight1(1);

elseif  ngl==6           % 6-point quadrature rule
    point1(1)=-0.932469514203152;
    point1(2)=-0.661209386466264;
    point1(3)=-0.238619186083197;
    point1(4)=-point1(3);
    point1(5)=-point1(2);
    point1(6)=-point1(1);
  
    weight1(1)=0.171324492379170;
    weight1(2)=0.360761573048139;
    weight1(3)=0.467913934572691;
    weight1(4)=weight1(3);
    weight1(5)=weight1(2);
    weight1(6)=weight1(1);
elseif ngl==7            % 7-point quadrature rule
   point1(1)=-0.9491079123427585245261897;
   point1(2)=-0.7415311855993944398638648;
   point1(3)=-0.4058451513773971669066064;
   point1(4)= 0.0000000000000000000000000;
   point1(5)=-point1(3);
   point1(6)=-point1(2);
   point1(7)=-point1(1);
   %
   weight1(1)=0.1294849661688696932760114;
   weight1(2)=0.2797053914892766679014678;
   weight1(3)=0.3818300505051189449503698;
   weight1(4)=0.4179591836734693877551020;
   weight1(5)=weight1(3);
   weight1(6)=weight1(2);
   weight1(7)=weight1(1);
   
elseif ngl==8            % 8-point quadrature rule
   point1(1)=-0.9602898564975362316835609;
   point1(2)=-0.7966664774136267395915539;
   point1(3)=-0.5255324099163289858177390;
   point1(4)=-0.1834346424956498049394761;
   point1(5)=-point1(4);
   point1(6)=-point1(3);
   point1(7)=-point1(2);
   point1(8)=-point1(1);
   %
   weight1(1)=0.1012285362903762591525314;
   weight1(2)=0.2223810344533744705443560;
   weight1(3)=0.3137066458778872873379622;
   weight1(4)=0.3626837833783619829651504;
   weight1(5)=weight1(4);
   weight1(6)=weight1(3);
   weight1(7)=weight1(2);
   weight1(8)=weight1(1);
   
elseif ngl==9            % 9-point quadrature rule
   point1(1)=-0.9681602395076260898355762;
   point1(2)=-0.8360311073266357942994298;
   point1(3)=-0.6133714327005903973087020;
   point1(4)=-0.3242534234038089290385380;
   point1(5)= 0.0000000000000000000000000;
   point1(6)=-point1(4);
   point1(7)=-point1(3);
   point1(8)=-point1(2);
   point1(9)=-point1(1);
   %
   weight1(1)=0.0812743883615744119718922;
   weight1(2)=0.1806481606948574040584720;
   weight1(3)=0.2606106964029354623187429;
   weight1(4)=0.3123470770400028400686304;
   weight1(5)=0.3302393550012597631645251;
   weight1(6)=weight1(4);
   weight1(7)=weight1(3);
   weight1(8)=weight1(2);
   weight1(9)=weight1(1);
   
elseif ngl==10       % 10-point quadrature rule
   point1(1)=-0.9739065285171717200779640;
   point1(2)=-0.8650633666889845107320967;
   point1(3)=-0.6794095682990244062343274;
   point1(4)=-0.4333953941292471907992659;
   point1(5)=-0.1488743389816312108848260;
   point1(6)=-point1(5);
   point1(7)=-point1(4);
   point1(8)=-point1(3);
   point1(9)=-point1(2);
   point1(10)=-point1(1);
   %
   weight1(1)=0.0666713443086881375935688;
   weight1(2)=0.1494513491505805931457763;
   weight1(3)=0.2190863625159820439955349;
   weight1(4)=0.2692667193099963550912269;
   weight1(5)=0.2955242247147528701738930;
   weight1(6)=weight1(5);
   weight1(7)=weight1(4);
   weight1(8)=weight1(3);
   weight1(9)=weight1(2);
   weight1(10)=weight1(1);
  else
   disp('Used number of integration points not implemented');
  return
end
%v=[point1;weight1];
%-------------------------end--------------------------------------



