function L= load_t(time,omega)
% Calculating the vibration load cos(omega*t)
L=cos(omega*time);