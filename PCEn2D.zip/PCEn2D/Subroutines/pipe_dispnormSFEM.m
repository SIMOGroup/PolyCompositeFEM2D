function [norm_dis]= pipe_dispnormSFEM(node,a,b,E,v,P,U)

% compute polar info
norm1=0;
norm2=0;
for i=1:size(node,1)
    x=node(i,1);
    y=node(i,2);
    if x<10e-6;
        ang=pi/2;
    else      
        ang=atan(y/x);
    end
    r=sqrt(x^2+y^2);
ur=((1+v)*(1-2*v)*(a^2*P)*r^2+(1+v)*a^2*b^2*P)/(E*(b^2-a^2)*r);
% up(i,1)=((1-v)*(a^2*P)*r(i)^2+(1+v)*a^2*b^2*P)/(E*(b^2-a^2)*r(i));
utheta=0;
ux=ur*cos(ang)-utheta*sin(ang);
uy=ur*sin(ang)+utheta*cos(ang);
norm1=norm1 + abs(ux)+abs(uy);
norm2=norm2 + abs(ux-U(2*i-1))+abs(uy-U(2*i));
end
norm_dis=norm2/norm1*100;



