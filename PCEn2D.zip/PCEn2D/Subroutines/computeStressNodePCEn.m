function varargout = computeStressNodePCEn(stressState, numnode, numelem, element, node, Dm, gamma, U, LAB, E0, nu0, cenDOF)

assert(strcmp(LAB, 'T3') || strcmp(LAB, 'Wachspress') || strcmp(LAB, 'CorrectedWachspress'))
global thickness;
% stressNode = zeros(3, numnode);
% pressNode = zeros(numnode, 1);
% stressNodeVol = zeros(3, numnode);
% stressNodeDev = zeros(3, numnode);

stressElem = cell(1, numelem);
% stressElemTotal = cell(1, numelem);
pressElem = zeros(numelem, 1);
% stressElemVol = cell(1, numelem);
% stressElemDev = cell(1, numelem);
% index_numb_node = zeros(numnode, 1);
% totalArea = zeros(numnode, 1);
ndof = 2;

NumQPsA = 3;

if strcmp(cenDOF, 'yes')
    M = sparse((numnode + numelem), (numnode + numelem));
    EStressRHS = zeros(3, (numnode + numelem));
    EPressRHS = zeros(1, (numnode + numelem));
else
    M = sparse(numnode, numnode);
    EStressRHS = zeros(3, numnode);
    EPressRHS = zeros(1, numnode);
end

if strcmp(LAB, 'CorrectedWachspress') || strcmp(LAB, 'Wachspress')
    NumQPsB = 3;
elseif strcmp(LAB, 'T3')
    NumQPsB = 1;
else
    error('Not implemented yet!')
end
lambda = (E0*nu0) / ((1 + nu0)*(1 - 2*nu0));
for iel = 1:numelem% start of element loop
    sctr = element{iel}(:)'; % element scatter vector
    
    nnel = length(sctr);
    sctrC = [sctr, numnode + iel];
    ni = 1; % addtional nodes
    nn = nnel + ni;
    
    sctrR = zeros(1, ndof * nnel);
    sctrR(1:ndof:ndof * nnel) = ndof .* sctr - 1;
    sctrR(2:ndof:ndof * nnel) = ndof .* sctr;
    edispl = U(sctrR);
    
    Connect = [(nnel + 1) * ones(nnel, 1), (1:nnel)', [2:nnel, 1]'];
    
    CoE = node(sctr, :);
    Coord = [CoE; polygonCentroid(CoE)];
    Area = polygonArea(CoE);
    
    [B, MS, WJ] = getStrainDisplacementMatrix(Coord, Connect, NumQPsB, LAB, cenDOF);
    
    if (strcmp(stressState, 'PLANE_STRAIN'))
        m = [1; 1; 0];
        BbarVol = zeros(1, 2 * nn);
        for jc = 1:nnel
            for jgp = 1:NumQPsB
                BbarVol = BbarVol + gamma * m' / Area * B(:, :, jgp, jc) * WJ(jgp, jc);
            end
        end
    end
    [P, ~, W, ~] = getQuadData(NumQPsA);
    
    AreaCell = zeros(NumQPsA, nnel);
    
    if strcmp(cenDOF, 'yes')
        Bt = zeros(3, ndof * nn, NumQPsA, nnel);
        Kl = zeros(ndof * nn, ndof * nn);
        me = zeros(nn, nn);
        Ne = zeros(nn, NumQPsA, nnel);
    else
        Bt = zeros(3, ndof * nnel, NumQPsA, nnel);
        Kl = zeros(ndof * nnel, ndof * nnel);
        me = zeros(nnel, nnel);
        Ne = zeros(nnel, NumQPsA, nnel);
    end
   
    % se = zeros(3, NumQPsA, nnel);
    for ic = 1:nnel
        CoordTri = Coord(Connect(ic, :), :);
        for igp = 1 : NumQPsA
            [NT3, dNdsT3] = T3ShapeFnc(P(igp, :));
            xy = NT3*CoordTri;
            J = dNdsT3 * CoordTri;
            x = xy(1); y = xy(2);
            AreaCell(igp, ic) = det(J)*W(igp);
            S = [1, x, y];
            
            if strcmp(cenDOF, 'yes')
                if (strcmp(LAB, 'Wachspress') || strcmp(LAB, 'CorrectedWachspress'))
                    [NW, ~] = wachspress2d_Floater_CenterNode(Coord(1:nnel, :), Coord(end, :), xy);
                    Ne(:, igp, ic) = NW;
                elseif (strcmp(LAB, 'T3'))
                    Ne(Connect(ic, :), igp, ic) = NT3;
                end
            else
                if (strcmp(LAB, 'Wachspress') || strcmp(LAB, 'CorrectedWachspress'))
                    [NW, ~] = wachspress2d_Floater_CenterNode(Coord(1:nnel, :), Coord(end, :), xy);
                    Ne(:, igp, ic) = NW(1:end-1);
                elseif (strcmp(LAB, 'T3'))
                    Ne(Connect(ic, 2 : 3), igp, ic) = NT3(2:3);
                    Ne(:, igp, ic) = Ne(:, igp, ic) + repmat(NT3(1) / nnel, nnel, 1);
                end
            end
            
            for jc = 1:nnel
                for jgp = 1:NumQPsB
                    Bt(:, :, igp, ic) = Bt(:, :, igp, ic) + (S * MS(:, jgp, jc)) * B(:, :, jgp, jc) * WJ(jgp, jc);
                end
            end
            
            if (strcmp(stressState, 'PLANE_STRAIN'))
                Bt(:, :, igp, ic) = 1/3 * m * BbarVol + (eye(3) - (gamma / 3) * (m * m'))*Bt(:, :, igp, ic);
            end
            if strcmp(cenDOF, 'yes')
                Kl = Kl + Bt(:, :, igp, ic)' * Dm * Bt(:, :, igp, ic) * AreaCell(igp, ic) * thickness; % element stiffness matrix
            end
            % [~, se(:, igp, ic)] = exactsolu_pipe(x, y, 1, 2, 21e3, 0.4999999, 8, 'PLANE_STRAIN');
            % [~, se(:, igp, ic), ~] = analytic_sol_beam(x, y, 1000, 3e7 / (1 - 0.4999999*0.4999999), 0.4999999 / (1 - 0.4999999), 12, 48);
        end
    end
    
    if strcmp(cenDOF, 'yes')
        Kie = Kl(end - 1 : end, 1:ndof*nnel);
        Kii = Kl(end - 1 : end, end - 1 : end);
        uii = -(Kii \ Kie) * edispl; % retrieve displacements of center node
        udispl = [edispl; uii];
        EStressGauss = zeros(3, nn);
        EPressGauss = zeros(1, nn);
    else
        udispl = edispl;
        EStressGauss = zeros(3, nnel);
        EPressGauss = zeros(1, nnel);
    end
    
    estress = zeros(3, 1);
    pressure = 0;
    
    if (strcmp(stressState, 'PLANE_STRAIN'))
        pn = lambda * BbarVol * udispl;
    end
    for kc = 1 : nnel % loop over subcell
        for kgp = 1 : NumQPsA
            %             econn = Connect(kc, :);
            % estressCell = se(:, kgp, kc);
            estressCell = Dm * Bt(:, :, kgp, kc) * udispl;
            estress = estress + estressCell * AreaCell(kgp, kc) * thickness;
            me = me + Ne(:, kgp, kc) * Ne(:, kgp, kc)' * AreaCell(kgp, kc) * thickness;
            EStressGauss = EStressGauss + estressCell * Ne(:, kgp, kc)' * AreaCell(kgp, kc) * thickness;
            %             CoordSubTRI = Coord(econn, :);
            %             [QW, QP] = quadrature(3, 'TRIANGULAR', 2);
            %             for jgp = 1 : numel(QW)
            %                 [NS, dNdxiS] = lagrange_basis('T3', QP(jgp, :)); % element shape functions
            %                 jac = CoordSubTRI' * dNdxiS; % element Jacobian matrix
            %                 me(econn, econn) = me(econn, econn) + NS * NS' * det(jac)*QW(jgp) * thickness;
            %                 EStressGauss(:, econn) = EStressGauss(:, econn) + estressCell * det(jac)*QW(jgp) * thickness * NS';
            %             end
            if (strcmp(stressState, 'PLANE_STRAIN'))
                % pe = (1 + 0.4999999) * (se(1, kgp, kc) + se(2, kgp, kc)) / 3;
                % pn = (1 + 0.4999999) * (estressCell(1) + estressCell(2)) / 3;
                epressCell = pn * AreaCell(kgp, kc) * thickness;
                pressure = pressure + epressCell;
                EPressGauss = EPressGauss + epressCell * Ne(:, kgp, kc)';
            end
        end
    end
    
    if strcmp(cenDOF, 'yes')
        M(sctrC, sctrC) = M(sctrC, sctrC) + me;
        EStressRHS(:, sctrC) = EStressRHS(:, sctrC) + EStressGauss;
        EPressRHS(:, sctrC) = EPressRHS(:, sctrC) + EPressGauss;
    else
        M(sctr, sctr) = M(sctr, sctr) + me;
        EStressRHS(:, sctr) = EStressRHS(:, sctr) + EStressGauss;
        EPressRHS(:, sctr) = EPressRHS(:, sctr) + EPressGauss;
    end
    
    pressElem(iel) = pressure / Area;
    stressElem{iel} = estress / Area;
end % of element loop

stressNode = (M \ EStressRHS')';
stressNode = stressNode(:, 1:numnode);

pressNode = (M \ EPressRHS')';
pressNode = pressNode(:, 1:numnode);

varargout{1} = stressNode;
varargout{2} = stressElem;
if (nargout > 2)
    varargout{3}  = pressNode;
    varargout{4}  = pressElem;
end
end
