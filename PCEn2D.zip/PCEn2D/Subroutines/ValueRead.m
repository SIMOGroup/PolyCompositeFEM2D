function Idcs = ValueRead(filename)

fid = fopen(filename, 'r');

Idcs = [];
i = 0;
while ~feof(fid)
    currentLine = fgetl(fid);
    if ~strcmp(currentLine(1), '#')
        i = i + 1;
        id = sscanf(currentLine, '%g')';
        Idcs = cat(1, Idcs, id);
    end
end
end