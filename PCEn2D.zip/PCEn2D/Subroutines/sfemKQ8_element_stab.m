function K= sfemKQ8_element_stab(e,elemType,enrich_node,x,y,D,Dbar,al,nsc,ng,sctrB)
                          
global node element K 

if nargin == 13
    sub_elem = 1;
    num_sub = 1;
end
%ng=1;   % number gauss point on boundary subcell element
%QT  =[cos(alpha) sin(alpha); -sin(alpha) cos(alpha)];
%==================================%
%      K_SXFEM stiffness matrix    %
%==================================%
if (strcmp(elemType,'T6'))
    sctr = element(e,:);
    nodes = node(sctr,:);
    nn   = length(sctr);
    %---------------
    % type of subcell : T3 element
    %---------------
    if nsc==1
        
    %       3
    %       | -       
    %       |    - 
    %       |       -
    %       |   sc1    -
    %       |             -
    %       1----------------2
        gcoord(:,1)=x(1:3,1);
        gcoord(:,2)=y(1:3,1);
        node_sc=[1 2 3];
    elseif nsc==2
    %       3
    %       | -       
    %       |    - 
    %       | sc2   4
    %       |     -    -
    %       |  -   sc1    -
    %       1----------------2
    
        x_sc=[x(1);x(2);x(3);x(5)];
        y_sc=[y(1);y(2);y(3);y(5)];
        gcoord(:,1)=x_sc;
        gcoord(:,2)=y_sc;
        node_sc=[1 2 4 ; 1 4 3];
    elseif nsc==3
    %       3
    %       | -       
    %       |    - 
    %       | sc3   5
    %       |     - |  -
    %       |  -sc1 |sc2  -
    %       1-------4--------2
        x_sc=[x(1);x(2);x(3);x(4);x(5)];
        y_sc=[y(1);y(2);y(3);y(4);y(5)];
        gcoord(:,1)=x_sc;
        gcoord(:,2)=y_sc;
        node_sc=[1 4 5;
              4 2 5;
              1 5 3];
    elseif nsc==4
    %       3
    %       | -       
    %       |sc3 - 
    %       6-------5
    %       |  -sc4 |  -
    %       |sc1 -  |sc2  -
    %       1-------4--------2
     
        x_sc=x;
        y_sc=y;
        node_sc=[1 4 6;
                 2 5 4;
                 3 6 5;
                 4 5 6];
        gcoord(:,1)=x_sc;
        gcoord(:,2)=y_sc;

    elseif nsc==6
    %       3
    %       | -       
    %       |    - 
    %       |       -
    %       | sc6      -
    %       |             -
    %       6----------------5
    %       |   -   sc5    - | -
    %       |      -    -    |    -
    %       | sc4    7   sc2 |       -
    %       |     -     -    |   sc3    -
    %       |  -    sc1   -  |             -
    %       1----------------4----------------2
    
        x_sc=[x(1);x(2);x(3);1/2*(x(1)+x(2));1/2*(x(2)+x(3));1/2*(x(3)+x(1));2/8*(2*x(1)+x(2)+x(3))];

        y_sc=[y(1);y(2);y(3);1/2*(y(1)+y(2));1/2*(y(2)+y(3));1/2*(y(3)+y(1));2/8*(2*y(1)+y(2)+y(3))];

        node_sc=[1 4 7;
                 4 5 7;
                 4 2 5;
                 1 7 6;
                 7 5 6;
                 6 5 3];
        gcoord(:,1)=x_sc;
        gcoord(:,2)=y_sc;
    elseif nsc==8
    %       3
    %       | -       
    %       |    - 
    %       |  sc8  8
    %       |    -     -
    %       |  -   sc7    -
    %       6----------------5
    %       |   -   sc6    - | -
    %       |      -    -    |    -
    %       | sc5    9   sc2 | sc3   7
    %       |     -     -    |    -     -
    %       |  -    sc1   -  |  -   sc4    -
    %       1----------------4----------------2
    
        x_sc=[x(1);x(2);x(3);1/2*(x(1)+x(2));1/2*(x(2)+x(3));1/2*(x(3)+x(1));1/4*(3*x(2)+x(3));1/4*(x(2)+3*x(3));2/8*(2*x(1)+x(2)+x(3))];

        y_sc=[y(1);y(2);y(3);1/2*(y(1)+y(2));1/2*(y(2)+y(3));1/2*(y(3)+y(1));1/4*(3*y(2)+y(3));1/4*(y(2)+3*y(3));2/8*(2*y(1)+y(2)+y(3))];

        node_sc=[1 4 9;
                 4 5 9;
                 4 7 5;
                 4 2 7;
                 1 9 6;
                 9 5 6;
                 6 5 8;
                 6 8 3];
        gcoord(:,1)=x_sc;
        gcoord(:,2)=y_sc;

    end
    
    dof_enr=2*sum(enrich_node(sctr));
    Ke_sc=zeros(2*nn+dof_enr,2*nn+dof_enr);
    for isc=1:nsc % loop sub cell element
        B_sfem=zeros(3,2*nn);
        B_sm=[];
        B_enr=zeros(3,dof_enr);
        bx=zeros(nn,1);
        by=zeros(nn,1);

        xx=gcoord(node_sc(isc,:),1);
        yy=gcoord(node_sc(isc,:),2);
        Ac=area_sc(xx,yy);
        side=cal_side(xx,yy);
        [nx,ny]=cal_nx_ny(xx,yy,side);
        ns=length(xx); % number side of sub element. T3 ==>ns=3
        xm=mean(xx);
        ym=mean(yy);

        for is=1:ns % loop 3 sides of sub cell element-two gauss points per side
            [W,Q]=quadrature(ng,'GAUSS',1);
            for ig=1:ng
                Bs_enr=[];
                N_g=lagrange_basis('L2',Q(ig));
                [xi1,eta1]=xi_eta4xy('T3',is,N_g);
                N_xy=lagrange_basis('T3',[xi1 eta1]);
                xy_g=N_xy'*[xx yy];

                xieta=cal_xieta('T3',xy_g,nodes);
                N_T=lagrange_basis(elemType,xieta);

%                 plot_g=[plot_g;xy_g];
                J2=side(is)/2; % Jacobian matrix for L2 
%                 bx_test=nx(is)*N_T*J2*W(ig)/Ac;
%                 by_test=ny(is)*N_T*J2*W(ig)/Ac;
                bx=bx + nx(is)*N_T*J2*W(ig)/Ac;
                by=by + ny(is)*N_T*J2*W(ig)/Ac;
            end % end loop of gauss points on side
        end %end of side
            B_sfem(1,1:2:2*nn)=bx;
            B_sfem(2,2:2:2*nn)=by;
            B_sfem(3,1:2:2*nn)=by;
            B_sfem(3,2:2:2*nn)=bx;

            if ( any(enrich_node(sctr)) == 0 ) % Non-enriched elements
                B_sm=B_sfem;
            else
                B_sm=[B_sfem B_enr];
            end
            clear B_sfem;
            Ksc = B_sm'*D*B_sm*Ac;
            Ke_sc = Ke_sc + Ksc;
            clear Ksc B_sm;
    end %end of subcell
    K(sctrB,sctrB) = K(sctrB,sctrB) + Ke_sc;
    %rank(Ke_sc)
    clear Ke_sc;
else
if (strcmp(elemType,'Q8'))
    sctr = element(e,:);
    nodes = node(sctr,:);
    nn   = length(sctr);%=8
    %-----------------------------
    % type of subcell : Q8 element
    %-----------------------------
    if nsc==1
        gcoord(:,1)=x;
        gcoord(:,2)=y;
        node_sc=[1 2 3 4];
    elseif nsc==2
    %       4------6-----3
    %       |      |     |
    %       |  sc1 | sc2 |
    %       |      |     | 
    %       1------5-----2
        x_sc=[x;node(sctr(5),1);node(sctr(7),1)];
        y_sc=[y;node(sctr(5),2);node(sctr(7),2)];
%         x_sc=[x;1/2*(x(1)+x(2));1/2*(x(3)+x(4))];
%         y_sc=[y;1/2*(y(1)+y(2));1/2*(y(3)+y(4))];
        
        gcoord(:,1)=x_sc;
        gcoord(:,2)=y_sc;
        node_sc=[1 5 6 4;5 2 3 6];
    elseif nsc==3
    %       4------8-----3
    %       |      | sc3 |
    %       |  sc1 6-----7
    %       |      | sc2 | 
    %       1------5-----2
        x_sc=[x;1/2*(x(1)+x(2));1/4*(x(1)+x(2)+x(3)+x(4));...
            1/2*(x(2)+x(3));1/2*(x(3)+x(4))];
        y_sc=[y;1/2*(y(1)+y(2));1/4*(y(1)+y(2)+y(3)+y(4));...
            1/2*(y(2)+y(3));1/2*(y(3)+y(4))];
        gcoord(:,1)=x_sc;
        gcoord(:,2)=y_sc;
        node=[1 5 8 4;5 2 6 7;6 7 3 8];
    elseif nsc==4
    %       4------7-----3
    %       | sc4  | sc3 |
    %       8------9-----6
    %       | sc1  | sc2 | 
    %       1------5-----2    
        x_sc=[x;1/2*(x(1)+x(2));1/2*(x(2)+x(3));...
            1/2*(x(3)+x(4));1/2*(x(4)+x(1));1/4*(x(1)+x(2)+x(3)+x(4))];
        y_sc=[y;1/2*(y(1)+y(2));1/2*(y(2)+y(3));...
            1/2*(y(3)+y(4));1/2*(y(4)+y(1));1/4*(y(1)+y(2)+y(3)+y(4))];
        node_sc=[1 5 9 8;
                 5 2 6 9;
                 9 6 3 7;
                 8 9 7 4];
        gcoord(:,1)=x_sc;
        gcoord(:,2)=y_sc;
% 
%         x_sc=[x;1/4*(x(1)+x(2)+x(3)+x(4))];
%         y_sc=[y;1/4*(y(1)+y(2)+y(3)+y(4))];
%         node_sc=[1 2 5;
%                  2 3 5;
%                  3 4 5;
%                  4 1 5];
%         gcoord(:,1)=x_sc;
%         gcoord(:,2)=y_sc;     
 

    else%if nsc==8
    %       04------11-----10------09-----03  
    %       |  sc5  |  sc6 |  sc7  |  sc8  |
    %       12------13-----14------15-----08
    %       |  sc1  |  sc2 |  sc3  |  sc4  |
    %       01------05-----06------07-----02  
            x_sc=[x;1/4*(3*x(1)+x(2));2/4*(x(1)+x(2));1/4*(x(1)+3*x(2));...
                1/2*(x(2)+x(3));1/4*(3*x(3)+x(4));2/4*(x(3)+x(4));...
                1/4*(x(3)+3*x(4));2/4*(x(1)+x(4));1/8*(3*x(1)+x(2)+x(3)+3*x(4));...
                2/8*(x(1)+x(2)+x(3)+x(4));1/8*(x(1)+3*x(2)+3*x(3)+x(4))];

        y_sc=[y;1/4*(3*y(1)+y(2));2/4*(y(1)+y(2));1/4*(y(1)+3*y(2));...
                1/2*(y(2)+y(3));1/4*(3*y(3)+y(4));2/4*(y(3)+y(4));...
                1/4*(y(3)+3*y(4));1/2*(y(1)+y(4));1/8*(3*y(1)+y(2)+y(3)+3*y(4));...
                2/8*(y(1)+y(2)+y(3)+y(4));1/8*(y(1)+3*y(2)+3*y(3)+y(4))];

        node_sc=[1 5 13 12;
                 5 6 14 13;
                 6 7 15 14;
                 7 2 8 15;
                 12 13 11 4;
                 13 14 10 11;
                 14 15 9 10;
                 15 8 3 9];
        gcoord(:,1)=x_sc;
        gcoord(:,2)=y_sc;
    end
    
  elseif (strcmp(elemType,'Q9'))
    sctr = element(e,:);
    nodes = node(sctr,:);
    nn   = length(sctr);%=8
    if nsc==1
        gcoord(:,1)=x;
        gcoord(:,2)=y;
        node_sc=[1 2 3 4];
    elseif nsc==2
    %       4------6-----3
    %       |      |     |
    %       |  sc1 | sc2 |
    %       |      |     | 
    %       1------5-----2
        x_sc=[x;node(sctr(5),1);node(sctr(7),1)];
        y_sc=[y;node(sctr(5),2);node(sctr(7),2)];
%         x_sc=[x;1/2*(x(1)+x(2));1/2*(x(3)+x(4))];
%         y_sc=[y;1/2*(y(1)+y(2));1/2*(y(3)+y(4))];
        
        gcoord(:,1)=x_sc;
        gcoord(:,2)=y_sc;
        node_sc=[1 5 6 4;5 2 3 6];
    elseif nsc==3
    %       4------8-----3
    %       |      | sc3 |
    %       |  sc1 6-----7
    %       |      | sc2 | 
    %       1------5-----2
        x_sc=[x;1/2*(x(1)+x(2));1/4*(x(1)+x(2)+x(3)+x(4));...
            1/2*(x(2)+x(3));1/2*(x(3)+x(4))];
        y_sc=[y;1/2*(y(1)+y(2));1/4*(y(1)+y(2)+y(3)+y(4));...
            1/2*(y(2)+y(3));1/2*(y(3)+y(4))];
        gcoord(:,1)=x_sc;
        gcoord(:,2)=y_sc;
        node=[1 5 8 4;5 2 6 7;6 7 3 8];
    elseif nsc==4
    %       4------7-----3
    %       | sc4  | sc3 |
    %       8------9-----6
    %       | sc1  | sc2 | 
    %       1------5-----2    
%         x_sc=[x;1/2*(x(1)+x(2));1/2*(x(2)+x(3));...
%             1/2*(x(3)+x(4));1/2*(x(4)+x(1));1/4*(x(1)+x(2)+x(3)+x(4))];
%         y_sc=[y;1/2*(y(1)+y(2));1/2*(y(2)+y(3));...
%             1/2*(y(3)+y(4));1/2*(y(4)+y(1));1/4*(y(1)+y(2)+y(3)+y(4))];
%         node_sc=[1 5 9 8;
%                  5 2 6 9;
%                  9 6 3 7;
%                  8 9 7 4];
%         gcoord(:,1)=x_sc;
%         gcoord(:,2)=y_sc;
 
        x_sc=[x;1/4*(x(1)+x(2)+x(3)+x(4))];
        y_sc=[y;1/4*(y(1)+y(2)+y(3)+y(4))];
        node_sc=[1 2 5;
                 2 3 5;
                 3 4 5;
                 4 1 5];
        gcoord(:,1)=x_sc;
        gcoord(:,2)=y_sc;     
 
        
    else %nsc==8
    %       04------11-----10------09-----03  
    %       |  sc5  |  sc6 |  sc7  |  sc8  |
    %       12------13-----14------15-----08
    %       |  sc1  |  sc2 |  sc3  |  sc4  |
    %       01------05-----06------07-----02  
            x_sc=[x;1/4*(3*x(1)+x(2));2/4*(x(1)+x(2));1/4*(x(1)+3*x(2));...
                1/2*(x(2)+x(3));1/4*(3*x(3)+x(4));2/4*(x(3)+x(4));...
                1/4*(x(3)+3*x(4));2/4*(x(1)+x(4));1/8*(3*x(1)+x(2)+x(3)+3*x(4));...
                2/8*(x(1)+x(2)+x(3)+x(4));1/8*(x(1)+3*x(2)+3*x(3)+x(4))];

        y_sc=[y;1/4*(3*y(1)+y(2));2/4*(y(1)+y(2));1/4*(y(1)+3*y(2));...
                1/2*(y(2)+y(3));1/4*(3*y(3)+y(4));2/4*(y(3)+y(4));...
                1/4*(y(3)+3*y(4));1/2*(y(1)+y(4));1/8*(3*y(1)+y(2)+y(3)+3*y(4));...
                2/8*(y(1)+y(2)+y(3)+y(4));1/8*(y(1)+3*y(2)+3*y(3)+y(4))];

        node_sc=[1 5 13 12;
                 5 6 14 13;
                 6 7 15 14;
                 7 2 8 15;
                 12 13 11 4;
                 13 14 10 11;
                 14 15 9 10;
                 15 8 3 9];
        gcoord(:,1)=x_sc;
        gcoord(:,2)=y_sc;
    end
  elseif (strcmp(elemType,'Q4'))
      sctr = element(e,:);
      nodes = node(sctr,:);
      nn   = length(sctr);
    %-----------------------------
    % type of subcell : Q4 element
    %-----------------------------
    if nsc==1
        gcoord(:,1)=x;
        gcoord(:,2)=y;
        node_sc=[1 2 3 4];
    elseif nsc==2
    %       4------6-----3
    %       |      |     |
    %       |  sc1 | sc2 |
    %       |      |     | 
    %       1------5-----2
        x_sc=[x;1/2*(x(1)+x(2));1/2*(x(3)+x(4))];
        y_sc=[y;1/2*(y(1)+y(2));1/2*(y(3)+y(4))];
        gcoord(:,1)=x_sc;
        gcoord(:,2)=y_sc;
        node_sc=[1 5 6 4;5 2 3 6];
    elseif nsc==3
    %       4------8-----3
    %       |      | sc3 |
    %       |  sc1 6-----7
    %       |      | sc2 | 
    %       1------5-----2
        x_sc=[x;1/2*(x(1)+x(2));1/4*(x(1)+x(2)+x(3)+x(4));...
            1/2*(x(2)+x(3));1/2*(x(3)+x(4))];
        y_sc=[y;1/2*(y(1)+y(2));1/4*(y(1)+y(2)+y(3)+y(4));...
            1/2*(y(2)+y(3));1/2*(y(3)+y(4))];
        gcoord(:,1)=x_sc;
        gcoord(:,2)=y_sc;
        node=[1 5 8 4;5 2 6 7;6 7 3 8];
    elseif nsc==4
    %       4------7-----3
    %       | sc4  | sc3 |
    %       8------9-----6
    %       | sc1  | sc2 | 
    %       1------5-----2    
        x_sc=[x;1/2*(x(1)+x(2));1/2*(x(2)+x(3));...
            1/2*(x(3)+x(4));1/2*(x(4)+x(1));1/4*(x(1)+x(2)+x(3)+x(4))];
        y_sc=[y;1/2*(y(1)+y(2));1/2*(y(2)+y(3));...
            1/2*(y(3)+y(4));1/2*(y(4)+y(1));1/4*(y(1)+y(2)+y(3)+y(4))];
        node_sc=[1 5 9 8;
                 5 2 6 9;
                 9 6 3 7;
                 8 9 7 4];
        gcoord(:,1)=x_sc;
        gcoord(:,2)=y_sc;
    % triangular type 
%    x_sc=[x;1/4*(x(1)+x(2)+x(3)+x(4))];
%         y_sc=[y;1/4*(y(1)+y(2)+y(3)+y(4))];
%         node_sc=[1 2 5;
%                  2 3 5;
%                  3 4 5;
%                  4 1 5];
%         gcoord(:,1)=x_sc;
%         gcoord(:,2)=y_sc;     
    elseif nsc==8
    %       04------11-----10------09-----03  
    %       |  sc5  |  sc6 |  sc7  |  sc8  |
    %       12------13-----14------15-----08
    %       |  sc1  |  sc2 |  sc3  |  sc4  |
    %       01------05-----06------07-----02  
        x_sc=[x;1/4*(3*x(1)+x(2));2/4*(x(1)+x(2));1/4*(x(1)+3*x(2));...
                1/2*(x(2)+x(3));1/4*(3*x(3)+x(4));2/4*(x(3)+x(4));...
                1/4*(x(3)+3*x(4));2/4*(x(1)+x(4));1/8*(3*x(1)+x(2)+x(3)+3*x(4));...
                2/8*(x(1)+x(2)+x(3)+x(4));1/8*(x(1)+3*x(2)+3*x(3)+x(4))];

        y_sc=[y;1/4*(3*y(1)+y(2));2/4*(y(1)+y(2));1/4*(y(1)+3*y(2));...
                1/2*(y(2)+y(3));1/4*(3*y(3)+y(4));2/4*(y(3)+y(4));...
                1/4*(y(3)+3*y(4));1/2*(y(1)+y(4));1/8*(3*y(1)+y(2)+y(3)+3*y(4));...
                2/8*(y(1)+y(2)+y(3)+y(4));1/8*(y(1)+3*y(2)+3*y(3)+y(4))];

        node_sc=[1 5 13 12;
                 5 6 14 13;
                 6 7 15 14;
                 7 2 8 15;
                 12 13 11 4;
                 13 14 10 11;
                 14 15 9 10;
                 15 8 3 9];
        gcoord(:,1)=x_sc;
        gcoord(:,2)=y_sc;
    else
      disp('Number smoothing cells of element are not implemented');
      return    
    end
 else
   disp('Number smoothing cells of element are not implemented');
   return
 end
 
    dof_enr=2*sum(enrich_node(sctr));
    Ke_sc1=zeros(2*nn+dof_enr,2*nn+dof_enr);
    Ke_sc2=zeros(2*nn+dof_enr,2*nn+dof_enr);
    for isc=1:nsc % loop sub cell element for general cell
        B_sfem=zeros(3,2*nn);
        B_enr=zeros(3,dof_enr);
        
        bx=zeros(nn,1);
        by=zeros(nn,1);

        xx=gcoord(node_sc(isc,:),1);
        yy=gcoord(node_sc(isc,:),2);
        Ac=area_sc(xx,yy);
        side=cal_side(xx,yy);
        [nx,ny]=cal_nx_ny(xx,yy,side);
        ns=length(xx); % number side of sub element. Q4 (Q8)==>ns=4
    
        for is=1:ns % loop 4 sides of sub cell element-ng gauss points per side
            [W,Q]=quadrature(ng,'GAUSS',1); % ng is the quadrature order, dim=1 is the number of spacial
                                            % dimentions of the problem
            for ig=1:ng
                Bs_enr=[];
                N_g=lagrange_basis('L2',Q(ig));
                [xi1,eta1]=xi_eta4xy('Q4',is,N_g);
                N_xy=lagrange_basis('Q4',[xi1 eta1]);
                xy_g=N_xy'*[xx yy];
                xieta=cal_xieta('Q4',xy_g,nodes);% return (xi, eta) for isoparametric element 4-node
%                 
%               N_g=lagrange_basis('L2',Q(ig));
%               [xi1,eta1]=xi_eta4xy('T3',is,N_g);
%               N_xy=lagrange_basis('T3',[xi1 eta1]);
%               xy_g=N_xy'*[xx yy];
%               xieta=cal_xieta('Q4',xy_g,nodes);% return (xi, eta) for isoparametric element 4-node
                %xieta=cal_xieta(elemType,xy_g,nodes);% chung ta cung co
                %the dung Q8 de tinh (xi, eta)
                
                N_Q=lagrange_basis(elemType,xieta);
%                 plot_g=[plot_g;xy_g];
                J2=side(is)/2; % Jacobian matrix for L2 
%               bx_test=nx(is)*N_Q8*J2*W(ig)/Ac;
%               by_test=ny(is)*N_Q8*J2*W(ig)/Ac;
                bx=bx + nx(is)*N_Q*J2*W(ig)/Ac;
                by=by + ny(is)*N_Q*J2*W(ig)/Ac;
            end % end loop of gauss points on side
         end %end of side        
                B_sfem(1,1:2:2*nn)=bx;
                B_sfem(2,2:2:2*nn)=by;
                B_sfem(3,1:2:2*nn)=by;
                B_sfem(3,2:2:2*nn)=bx;

            if (any(enrich_node(sctr)) == 0 ) % Non-enriched elements
                B_sm=B_sfem;
            else
                B_sm=[B_sfem B_enr];
            end
            clear B_sfem;
            clear B_enr;
            Ke_sc1 = Ke_sc1 + B_sm'*al*Dbar*B_sm*Ac; 
            clear B_sm;
    end %end of subcell
        
    nsc=1;   %only one subcell per element
    for isc=1:nsc % loop sub cell element
        B_sfem=zeros(3,2*nn);
        B_enr=zeros(3,dof_enr);
        
        bx=zeros(nn,1);
        by=zeros(nn,1);

        xx=gcoord(node_sc(isc,:),1);
        yy=gcoord(node_sc(isc,:),2);
        Ac=area_sc(xx,yy);
        side=cal_side(xx,yy);
        [nx,ny]=cal_nx_ny(xx,yy,side);
        ns=length(xx); % number side of sub element. Q4 (Q8)==>ns=4
       

        for is=1:ns % loop 4 sides of sub cell element-ng gauss points per side
            [W,Q]=quadrature(ng,'GAUSS',1); % ng is the quadrature order, dim=1 is the number of spacial
                                            % dimentions of the problem
            for ig=1:ng
                Bs_enr=[];
                N_g=lagrange_basis('L2',Q(ig));
                [xi1,eta1]=xi_eta4xy('Q4',is,N_g);
                N_xy=lagrange_basis('Q4',[xi1 eta1]);
                xy_g=N_xy'*[xx yy];
                xieta=cal_xieta('Q4',xy_g,nodes);% return (xi, eta) for isoparametric element 4-node
%                 
%               N_g=lagrange_basis('L2',Q(ig));
%               [xi1,eta1]=xi_eta4xy('T3',is,N_g);
%               N_xy=lagrange_basis('T3',[xi1 eta1]);
%               xy_g=N_xy'*[xx yy];
%               xieta=cal_xieta('Q4',xy_g,nodes);% return (xi, eta) for isoparametric element 4-node
                %xieta=cal_xieta(elemType,xy_g,nodes);% chung ta cung co
                %the dung Q8 de tinh (xi, eta)
                
                N_Q=lagrange_basis(elemType,xieta);
%               plot_g=[plot_g;xy_g];
                J2=side(is)/2; % Jacobian matrix for L2 
%               bx_test=nx(is)*N_Q8*J2*W(ig)/Ac;
%               by_test=ny(is)*N_Q8*J2*W(ig)/Ac;
                bx=bx + nx(is)*N_Q*J2*W(ig)/Ac;
                by=by + ny(is)*N_Q*J2*W(ig)/Ac;
            end % end loop of gauss points on side
         end %end of side        
                B_sfem(1,1:2:2*nn)=bx;
                B_sfem(2,2:2:2*nn)=by;
                B_sfem(3,1:2:2*nn)=by;
                B_sfem(3,2:2:2*nn)=bx;

            if (any(enrich_node(sctr)) == 0 ) % Non-enriched elements
                B_sm=B_sfem;
            else
                B_sm=[B_sfem B_enr];
            end
            clear B_sfem;
            clear B_enr;
            Ke_sc2 = Ke_sc2 + B_sm'*(D-al*Dbar)*B_sm*Ac;
            clear B_sm;
    end %end of subcell
    K(sctrB,sctrB) = K(sctrB,sctrB) + Ke_sc1 + Ke_sc2;
%    rank(Ke_sc)
    clear Ke_sc1 Ke_sc2;
end



   

