function [dnorm, enorm, pnorm] = evalErrorNormPCEn(problem, stressState, U, LAB, cenDOF)
global node element thickness;
% numnode = size(node, 1); % number of nodes
numelem = numel(element);

mu = problem.E / (2*(1 + problem.nu));
lambda = (problem.E * problem.nu) / ((1 + problem.nu)*(1 - 2*problem.nu));
if (strcmp(stressState, 'PLANE_STRESS'))
    lambda = 2*lambda*mu/(lambda + 2*mu);
end

ndof = 2;
dnorm = 0;
enorm = 0;
pnorm = 0;

NumQPsA = 3;
if strcmp(LAB, 'CorrectedWachspress') || strcmp(LAB, 'Wachspress')
    NumQPsB = 3;
elseif strcmp(LAB, 'T3')
    NumQPsB = 1;
else
    error('Not implemented yet!')
end
% lambda = (problem.E*problem.nu) / ((1 + problem.nu)*(1 - 2*problem.nu));
for iel = 1:numelem
    sctr = element{iel}(:)'; % element scatter vector
    
    nnel = length(sctr);
    % sctrC = [sctr numnode + iel];
    ni = 1; % addtional nodes
    nn = nnel + ni;
    
    sctrR = zeros(1, ndof * nnel);
    sctrR(1:ndof:ndof * nnel) = ndof .* sctr - 1;
    sctrR(2:ndof:ndof * nnel) = ndof .* sctr;
    uelem = U(sctrR);
    
    Connect = [(nnel + 1) * ones(nnel, 1), (1:nnel)', [2:nnel, 1]'];
    CoE = node(sctr, :);
    if strcmp(cenDOF, 'yes')
        Coord = [CoE; polygonCentroid(CoE)];
    else
        Coord = [CoE; mean(CoE)];
    end
    
    [B, MS, WJ] = getStrainDisplacementMatrix(Coord, Connect, NumQPsB, LAB, cenDOF);
    
    if (strcmp(stressState, 'PLANE_STRAIN'))
        m = [1; 1; 0];
        Area = polygonArea(Coord(1:end-1, :));
        if strcmp(cenDOF, 'yes')
            BbarVol = zeros(1, 2 * nn);
        else
            BbarVol = zeros(1, 2 * nnel);
        end
        for jc = 1:nnel
            for jgp = 1:NumQPsB
                BbarVol = BbarVol + problem.gamma * m' / Area * B(:, :, jgp, jc) * WJ(jgp, jc);
            end
        end
    end
    [P, ~, W, ~] = getQuadData(NumQPsA);
    
    % Kl = zeros(ndof * nn, ndof * nn);
    if strcmp(cenDOF, 'yes')
        Kl = zeros(ndof * (nnel + 1), ndof * (nnel + 1));
        Ne = zeros(nnel + 1, NumQPsA, nnel);
    else
        Ne = zeros(nnel, NumQPsA, nnel);
    end
    
    ue = zeros(2, NumQPsA, nnel);
    se = zeros(3, NumQPsA, nnel);
    if strcmp(cenDOF, 'yes')
        Bt = zeros(3, ndof * nn, NumQPsA, nnel);
    else
        Bt = zeros(3, ndof * nnel, NumQPsA, nnel);
    end
    AreaCell = zeros(NumQPsA, nnel);
    for ic = 1 : nnel
        CoordTri = Coord(Connect(ic, :), :);
        for igp = 1 : NumQPsA
            [NT3, dNdsT3] = T3ShapeFnc(P(igp, :));
            xy = NT3*CoordTri;
            J = dNdsT3 * CoordTri;
            x = xy(1); y = xy(2);
            AreaCell(igp, ic) = det(J)*W(igp);
            S = [1, x, y];
            
            if (strcmp(LAB, 'Wachspress') || strcmp(LAB, 'CorrectedWachspress'))
                [NW, ~] = wachspress2d_Floater_CenterNode(Coord(1:nnel, :), Coord(end, :), xy);
                if strcmp(cenDOF, 'yes')
                    Ne(:, igp, ic) = NW;
                else
                    Ne(:, igp, ic) = NW(1:end-1);
                end
            elseif (strcmp(LAB, 'T3'))
                if strcmp(cenDOF, 'yes')
                    Ne(Connect(ic, :), igp, ic) = NT3;
                else
                    Ne(Connect(ic, 2 : 3), igp, ic) = NT3(2 : 3)';
                    Ne(:, igp, ic) = Ne(:, igp, ic) + repmat(NT3(1) / nnel, nnel, 1);
                end
            end
            
            for jc = 1:nnel
                for jgp = 1:NumQPsB
                    Bt(:, :, igp, ic) = Bt(:, :, igp, ic) + (S * MS(:, jgp, jc)) * B(:, :, jgp, jc) * WJ(jgp, jc);
                end
            end
            
%             if (strcmp(stressState, 'PLANE_STRAIN'))
%                 Bt(:, :, igp, ic) = 1/3 * m * BbarVol + (eye(3) - (problem.gamma / 3) * (m * m'))*Bt(:, :, igp, ic);
%             end
            
            if strcmp(cenDOF, 'yes')
                Kl = Kl + Bt(:, :, igp, ic)' * problem.Dm * Bt(:, :, igp, ic) * AreaCell(igp, ic) * thickness; % element stiffness matrix
            end
            
            if strcmp(problem.LAB, 'CYLINDER')
                [ue(:, igp, ic), se(:, igp, ic)] = exactsolu_pipe(x, y, problem.a, problem.b, problem.E, problem.nu, problem.P, stressState);
            elseif strcmp(problem.LAB, 'BEAM')
                if (strcmp(stressState, 'PLANE_STRAIN'))
                    [ue(:, igp, ic), se(:, igp, ic), ~] = analytic_sol_beam(x, y, problem.P, problem.E / (1 - problem.nu*problem.nu), problem.nu / (1 - problem.nu), problem.D, problem.L);
                elseif (strcmp(stressState, 'PLANE_STRESS'))
                    [ue(:, igp, ic), se(:, igp, ic), ~] = analytic_sol_beam(x, y, problem.P, problem.E, problem.nu, problem.D, problem.L);
                end
            elseif strcmp(problem.LAB, 'LINEAR_PATCH_TEST')
                ue(:, igp, ic) = [1e-3*(x + y/2); 1e-3*(x/2 + y)];
                se(:, igp, ic) = [1333; 1333; 400];
            elseif strcmp(problem.LAB, 'QUADRATIC_PATCH_TEST')
                UExact = @(x, y) 0.1 * x .^ 2 + 0.1 * x .* y + 0.2*y .^ 2;
                VExact = @(x, y) 0.05 * x .^ 2 + 0.15 * x .* y + 0.1 * y .^ 2;
                ue(:, igp, ic) = [UExact(x, y); VExact(x, y)];
                StrainExact =  @(x, y) [0.2*x + 0.1*y; 0.15*x + 0.2*y; 0.1*x + 0.4*y + 0.1*x + 0.15*y];
                se(:, igp, ic) = problem.Dm * StrainExact(x, y);
            else
                error("Not implemented yet!");
            end
        end
    end
    
    if strcmp(cenDOF, 'yes')
        Kie = Kl(end - 1 : end, 1:ndof*nnel);
        Kii = Kl(end - 1 : end, end - 1 : end);
        uii = -(Kii \ Kie) * uelem; % retrieve displacements of center node
        
        udispl = [uelem; uii];
    else
        udispl = uelem;
    end
    
    displx = udispl(1 : ndof : end - 1);
    disply = udispl(2 : ndof : end);
    
    for kc = 1 : nnel
        for kgp = 1 : NumQPsA
            uh = [displx, disply]' * Ne(:, kgp, kc);
            auxdnorm = uh - ue(:, kgp, kc);
            dnorm = dnorm + auxdnorm' * auxdnorm * AreaCell(kgp, kc) * thickness;
            estressCell = problem.Dm * Bt(:, :, kgp, kc) * udispl;
            aux_enorm = se(:, kgp, kc) - estressCell;
            enorm = enorm + aux_enorm' / problem.Dm * aux_enorm * AreaCell(kgp, kc) * thickness;
            if (strcmp(stressState, 'PLANE_STRAIN'))
                pe = (1 + problem.nu) * (se(1, kgp, kc) + se(2, kgp, kc)) / 3;
                pn = lambda * BbarVol * udispl;
                % pn = (1 + problem.nu) * (estressCell(1) + estressCell(2)) / 3;
                pnorm = pnorm + (pn - pe)^2 * AreaCell(kgp, kc) * thickness;
            end
        end
    end
end % of element loop

dnorm = sqrt(dnorm);
enorm = sqrt(enorm);
pnorm = sqrt(pnorm);
end