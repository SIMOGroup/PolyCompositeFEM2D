function WGC = evalWachspressGradientCorrection(Coord, Connect)

nn = size(Coord, 1);
nnel = nn - 1;
Cs = zeros(nn, 2);
Cv = zeros(nn, 2);
Area = polygonArea(Coord(1 : (end - 1), :));
[Ps, Ws] = GaussLegendreRule1D(4);
[Pv, ~, Wv, ~] = getQuadData(3);
for i = 1 : nnel % loop over polygon's edges
    CoordTri = Coord(Connect(i, :), :);
    CoordEdge = Coord(Connect(i, 2:end), :);
    l = norm(CoordEdge(2, :) - CoordEdge(1, :));
    nx = (CoordEdge(2, 2) - CoordEdge(1, 2)) / l;
    ny = -(CoordEdge(2, 1) - CoordEdge(1, 1)) / l;
    normal = [nx, ny];
    for js = 1 : numel(Ws)
        xi = Ps(js);
        Nb = [1 - xi, 1 + xi] / 2;
        dNb = [-1, 1] / 2;
        
        Js = dNb*CoordEdge;
        xy = Nb*CoordEdge;
        
        [N, ~] = wachspress2d_Floater_CenterNode(Coord(1:nnel, :), Coord(end, :), xy);
        
        %quiver(xy(1), xy(2), nx, ny, 0.5, 'k');
        Cs = Cs + N * normal * sqrt(Js * Js') * Ws(js);
    end
    for jv = 1 : length(Wv)
        [NT3, dNdsT3] = T3ShapeFnc(Pv(jv, :));
        xy = NT3 * CoordTri;
        Jv = dNdsT3 * CoordTri;
        [~, dNdx] = wachspress2d_Floater_CenterNode(Coord(1:nnel, :), Coord(end, :), xy);
        Cv = Cv + dNdx * Wv(jv) * det(Jv);
    end
end
WGC = 1/Area*(Cs - Cv);
end