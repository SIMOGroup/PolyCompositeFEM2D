function [B, H, WJ] = getStrainDisplacementMatrix(Coord, Connect, NumQPs, LAB, cenDOF)

assert(~(strcmp(LAB, 'Wachspress') && strcmp(cenDOF, 'yes')), 'Wachspress bases does not support central DOFs')

RM = computeCoeffsMatrixPCEn(Coord, 3);

if strcmp(LAB, 'CorrectedWachspress')
    WGC = evalWachspressGradientCorrection(Coord, Connect);
end

nn = size(Coord, 1);
nnel = nn - 1;

if strcmp(cenDOF, 'yes')
    B = zeros(3, 2 * nn, NumQPs, nnel);
else
    B = zeros(3, 2 * nnel, NumQPs, nnel);
end
H = zeros(3, NumQPs, nnel);
WJ = zeros(NumQPs, nnel);

[P, ~, W, ~] = getQuadData(NumQPs);
for isub = 1:nnel    
    CoordTri = Coord(Connect(isub, :), :);
    for gp = 1:NumQPs
        [NT3, dNdsT3] = T3ShapeFnc(P(gp, :));
        xy = NT3*CoordTri;
        jac = dNdsT3 * CoordTri;
        dNdxT31 = jac \ dNdsT3;
        S = [1, xy(1), xy(2)];
        H(:, gp, isub) = RM * S';
        
        if (strcmp(LAB, 'Wachspress') || strcmp(LAB, 'CorrectedWachspress'))
            [~, dNdx] = wachspress2d_Floater_CenterNode(Coord(1:nnel, :), Coord(end, :), xy);
            if strcmp(LAB, 'CorrectedWachspress')
                dNdx = dNdx + WGC;
            end
            if ~strcmp(cenDOF, 'yes')
                dNdx = dNdx(1:nnel, :);
            end
        elseif (strcmp(LAB, 'T3'))
            if strcmp(cenDOF, 'yes')
                dNdx = zeros(nn, 2);
                dNdx(Connect(isub, :), :) = dNdxT31';
            else
                dNdx = zeros(nnel, 2);
                dNdx(Connect(isub, 2 : 3), :) = dNdxT31(:, 2 : 3)';
                dNdx = dNdx + repmat(dNdxT31(:, 1)' / nnel, nnel, 1);                
            end
        end
        
        if strcmp(cenDOF, 'yes')
            subel = 1:(nnel + 1);
            Be = zeros(3, 2 * (nnel + 1));
        elseif strcmp(cenDOF, 'no')
            subel = 1:nnel;
            Be = zeros(3, 2 * nnel);
        else
            error('Not implemented yet!')
        end
        
        Be(1, 2 * subel - 1) = dNdx(:, 1);
        Be(2, 2 * subel) = dNdx(:, 2);
        Be(3, 2 * subel - 1) = dNdx(:, 2);
        Be(3, 2 * subel) = dNdx(:, 1);
        
        B(:, :, gp, isub) = Be;
        WJ(gp, isub) = det(jac)*W(gp);
    end
end

end