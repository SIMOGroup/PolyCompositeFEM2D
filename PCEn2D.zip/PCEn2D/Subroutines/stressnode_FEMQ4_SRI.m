function stress_node=stressnode_FEMQ4_SRI(numnode,numelem,nnel,element,node,Q,U,C,elemType)

stress_node=zeros(3,numnode);
index_numb_node=zeros(numnode,1);
for e=1:numelem                          % start of element loop
   sctr=element(e,:);           % element scatter vector
   nn=length(sctr);
   sctrB(1:2:2*nn) = 2.*sctr-1 ;
   sctrB(2:2:2*nn) = 2.*sctr   ;
   Udisp=U(sctrB);
  
   for q=1:size(Q,1)                        % quadrature loop
    pt=Q(q,:);                             % quadrature point
    [N,dNdxi]=lagrange_basis(elemType,pt); % element shape functions
    J0=node(sctr,:)'*dNdxi;                % element Jacobian matrix        
    dNdx=dNdxi/J0;
    B(1,1:2:2*nn-1) = dNdx(:,1)';
    B(2,2:2:2*nn)   = dNdx(:,2)';
    B(3,1:2:2*nn-1) = dNdx(:,2)';
    B(3,2:2:2*nn)  = dNdx(:,1)';
    estress=C*B*Udisp;
   end
   
    for i=1:nnel        
        stress_node(:,sctr(i)) = stress_node(:,sctr(i)) + estress(:);
        index_numb_node(sctr(i))=index_numb_node(sctr(i))+1;              
    end
end         

for i=1:numnode
    stress_node(:,i)=stress_node(:,i)/index_numb_node(i);  %unweighted average
end
