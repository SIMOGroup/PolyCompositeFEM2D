function K= femKQ8(e,elemType,enrich_node,...
               x,y,D,nsc,ng,total_unknown,sctrB)
                          
global node element K plot_g

if nargin == 13
    sub_elem = 1;
    num_sub = 1;
end
%ng=1;   % number gauss point on boundary subcell element
%QT  =[cos(alpha) sin(alpha); -sin(alpha) cos(alpha)];
%==================================%
%      K_SXFEM stiffness matrix    %
%==================================%
if (strcmp(elemType,'Q8'))
    sctr = element(e,:);
    nodes = node(sctr,:);
    nn   = length(sctr);%=8
    %-----------------------------
    % type of subcell : Q8 element
    %-----------------------------
    dof_enr=2*sum(enrich_node(sctr));
    Ke_sc=zeros(2*nn+dof_enr,2*nn+dof_enr);
    for isc=1:nsc % loop sub cell element
        B_fem=zeros(3,2*nn);
        B_sm=[];
        B_enr=zeros(3,dof_enr);
        
        bx=zeros(nn,1);
        by=zeros(nn,1);

        xx=gcoord(node_sc(isc,:),1);
        yy=gcoord(node_sc(isc,:),2);
        Ac=area_sc(xx,yy);
        side=cal_side(xx,yy);
        [nx,ny]=cal_nx_ny(xx,yy,side);
        ns=length(xx); % number side of sub element. Q4 (Q8)==>ns=4
        xm=mean(xx);
        ym=mean(yy);

        for is=1:ns % loop 4 sides of sub cell element-ng gauss points per side
            [W,Q]=quadrature(ng,'GAUSS',1); % ng is the quadrature order, dim=1 is the number of spacial
                                            % dimentions of the problem
            for ig=1:ng
                Bs_enr=[];
                N_g=lagrange_basis('L2',Q(ig));
                [xi1,eta1]=xi_eta4xy('Q4',is,N_g);
                N_Q4xy=lagrange_basis('Q4',[xi1 eta1]);
                xy_g=N_Q4xy'*[xx yy];
                xieta=cal_xieta('Q4',xy_g,nodes);% return (xi, eta) for isoparametric element 4-node
                %xieta=cal_xieta(elemType,xy_g,nodes);% chung ta cung co
                %the dung Q8 de tinh (xi, eta)
                
                N_Q8=lagrange_basis(elemType,xieta);
                plot_g=[plot_g;xy_g];
                J2=side(is)/2; % Jacobian matrix for L2 
%               bx_test=nx(is)*N_Q8*J2*W(ig)/Ac;
%               by_test=ny(is)*N_Q8*J2*W(ig)/Ac;
                bx=bx + nx(is)*N_Q8*J2*W(ig)/Ac;
                by=by + ny(is)*N_Q8*J2*W(ig)/Ac;
            end % end loop of gauss points on side
         end %end of side        
                B_sfem(1,1:2:2*nn)=bx;
                B_sfem(2,2:2:2*nn)=by;
                B_sfem(3,1:2:2*nn)=by;
                B_sfem(3,2:2:2*nn)=bx;

            if (any(enrich_node(sctr)) == 0 ) % Non-enriched elements
                B_sm=B_sfem;
            else
                B_sm=[B_sfem B_enr];
            end
            clear B_sfem;
            clear B_enr;
            Ksc = B_sm'*D*B_sm*Ac;
            Ke_sc = Ke_sc + Ksc;
            clear Ksc;
    end %end of subcell
    K(sctrB,sctrB) = K(sctrB,sctrB) + Ke_sc;
%     rank(Ke_sc);
    clear Ke_sc;
elseif (strcmp(elemType,'T6'))
    sctr = element(e,:);
    nodes = node(sctr,:);
    nn   = length(sctr);
    %---------------
    % type of subcell : T3 element
    %---------------
    if nsc==1
        
    %       3
    %       | -       
    %       |    - 
    %       |       -
    %       |   sc1    -
    %       |             -
    %       1----------------2
        gcoord(:,1)=x;
        gcoord(:,2)=y;
        node_sc=[1 2 3];
    elseif nsc==2
    %       3
    %       | -       
    %       |    - 
    %       | sc2   4
    %       |     -    -
    %       |  -   sc1    -
    %       1----------------2
    
        x_sc=[x;1/2*(x(2)+x(3))];
        y_sc=[y;1/2*(y(2)+y(3))];
        gcoord(:,1)=x_sc;
        gcoord(:,2)=y_sc;
        node_sc=[1 2 4 ; 1 4 3];
    elseif nsc==3
    %       3
    %       | -       
    %       |    - 
    %       | sc3   5
    %       |     - |  -
    %       |  -sc1 |sc2  -
    %       1-------4--------2
        x_sc=[x;1/2*(x(1)+x(2));1/2*(x(2)+x(3))];
        y_sc=[y;1/2*(y(1)+y(2));1/2*(y(2)+y(3))];
        gcoord(:,1)=x_sc;
        gcoord(:,2)=y_sc;
        node_sc=[1 4 5;
              4 2 5;
              1 5 3];
    elseif nsc==4
    %       3
    %       | -       
    %       |sc4 - 
    %       6-------5
    %       |sc3  - |  -
    %       |  -sc1 |sc2  -
    %       1-------4--------2
    
        x_sc=[x;1/2*(x(1)+x(2));1/2*(x(2)+x(3));1/2*(x(3)+x(1))];
        y_sc=[y;1/2*(y(1)+y(2));1/2*(y(2)+y(3));1/2*(y(3)+y(1))];
        node_sc=[1 4 5;
                 4 2 5;
                 1 5 6;
                 6 5 3];
        gcoord(:,1)=x_sc;
        gcoord(:,2)=y_sc;

    elseif nsc==6
    %       3
    %       | -       
    %       |    - 
    %       |       -
    %       | sc6      -
    %       |             -
    %       6----------------5
    %       |   -   sc5    - | -
    %       |      -    -    |    -
    %       | sc4    7   sc2 |       -
    %       |     -     -    |   sc3    -
    %       |  -    sc1   -  |             -
    %       1----------------4----------------2
    
        x_sc=[x;1/2*(x(1)+x(2));1/2*(x(2)+x(3));1/2*(x(3)+x(1));2/8*(2*x(1)+x(2)+x(3))];

        y_sc=[y;1/2*(y(1)+y(2));1/2*(y(2)+y(3));1/2*(y(3)+y(1));2/8*(2*y(1)+y(2)+y(3))];

        node_sc=[1 4 7;
                 4 5 7;
                 4 2 5;
                 1 7 6;
                 7 5 6;
                 6 5 3];
        gcoord(:,1)=x_sc;
        gcoord(:,2)=y_sc;
    elseif nsc==8
    %       3
    %       | -       
    %       |    - 
    %       |  sc8  8
    %       |    -     -
    %       |  -   sc7    -
    %       6----------------5
    %       |   -   sc6    - | -
    %       |      -    -    |    -
    %       | sc5    9   sc2 | sc3   7
    %       |     -     -    |    -     -
    %       |  -    sc1   -  |  -   sc4    -
    %       1----------------4----------------2
    
        x_sc=[x;1/2*(x(1)+x(2));1/2*(x(2)+x(3));1/2*(x(3)+x(1));1/4*(3*x(2)+x(3));1/4*(x(2)+3*x(3));2/8*(2*x(1)+x(2)+x(3))];

        y_sc=[y;1/2*(y(1)+y(2));1/2*(y(2)+y(3));1/2*(y(3)+y(1));1/4*(3*y(2)+y(3));1/4*(y(2)+3*y(3));2/8*(2*y(1)+y(2)+y(3))];

        node_sc=[1 4 9;
                 4 5 9;
                 4 7 5;
                 4 2 7;
                 1 9 6;
                 9 5 6;
                 6 5 8;
                 6 8 3];
        gcoord(:,1)=x_sc;
        gcoord(:,2)=y_sc;

    end
    
    dof_enr=2*sum(enrich_node(sctr));
    Ke_sc=zeros(2*nn+dof_enr,2*nn+dof_enr);
    for isc=1:nsc % loop sub cell element
        B_sfem=zeros(3,2*nn);
        B_sm=[];
        B_enr=zeros(3,dof_enr);
        bx=zeros(nn,1);
        by=zeros(nn,1);

        xx=gcoord(node_sc(isc,:),1);
        yy=gcoord(node_sc(isc,:),2);
        Ac=area_sc(xx,yy);
        side=cal_side(xx,yy);
        [nx,ny]=cal_nx_ny(xx,yy,side);
        ns=length(xx); % number side of sub element. Q4 ==>ns=4
        xm=mean(xx);
        ym=mean(yy);

        for is=1:ns % loop 4 sides of sub cell element-two gauss points per side
            [W,Q]=quadrature(ng,'GAUSS',1);
            for ig=1:ng
                Bs_enr=[];
                N_g=lagrange_basis('L2',Q(ig));
                [xi1,eta1]=xi_eta4xy(elemType,is,N_g);
                N_Q4xy=lagrange_basis(elemType,[xi1 eta1]);
                xy_g=N_Q4xy'*[xx yy];

                xieta=cal_xieta(elemType,xy_g,nodes);
                N_Q4=lagrange_basis(elemType,xieta);

                plot_g=[plot_g;xy_g];
                J2=side(is)/2; % Jacobian matrix for L2 
                bx_test=nx(is)*N_Q4*J2*W(ig)/Ac;
                by_test=ny(is)*N_Q4*J2*W(ig)/Ac;
                bx=bx + nx(is)*N_Q4*J2*W(ig)/Ac;
                by=by + ny(is)*N_Q4*J2*W(ig)/Ac;

                % compute branch functions at Gauss point
                dist = signed_distance(xCr,[xm ym]);
%                 dist1 = signed_distance(xCr,[xx(1) yy(1)]);
%                 dist2 = signed_distance(xCr,[xx(2) yy(2)]);
%                 dist3 = signed_distance(xCr,[xx(3) yy(3)]);
%                 if (dist1<=0)&(dist2<=0)&(dist3<=0)
%                     dist=-1;
%                 else
%                     dist=1;
%                 end
                H=heaviside(dist);
                xp    = QT*(xy_g-xTip)';        % local coordinates

                r     = sqrt(xp(1)*xp(1)+xp(2)*xp(2));

                if( r ~=0 )
                    r2 = sqrt(r);
                else
                    r2    = 0.1d-4;
                    theta = 0.0d0 ;
                end
                theta = atan2(xp(2),xp(1));
                if theta==atan2(0,-1)
                    theta=H*theta;
                end

                st2  = sin(theta/2.);
                ct2  = cos(theta/2.);
                st   = sin(theta);
                ct   = cos(theta);

                Br(1) = r2 * st2 ;
                Br(2) = r2 * ct2;
                Br(3) = r2 * st2 * ct;
                Br(4) = r2 * ct2 * ct;

                % loop on nodes, check node is enriched ...

                for in = 1 : nn
                    if ( enrich_node(sctr(in)) == 1)     % H(x) enriched node
                        % Enrichment function, H(x) at global center of subcell
                        dist = signed_distance(xCr,[xm ym]);
%                         dist1 = signed_distance(xCr,[xx(1) yy(1)]);
%                         dist2 = signed_distance(xCr,[xx(2) yy(2)]);
%                         dist3 = signed_distance(xCr,[xx(3) yy(3)]);
%                         if (dist1<=0)&(dist2<=0)&(dist3<=0)
%                             dist=-1;
%                         else
%                             dist=1;
%                         end
                        Hg  = heaviside(dist);
                        % Enrichment function, H(x) at node "in"
                        dist = signed_distance(xCr,node(sctr(in),:));
                        Hi   = heaviside(dist);
                        % B_sxfem at node "in"
                        bx_h=nx(is)*N_Q4(in)*(Hg-Hi)*J2*W(ig)/Ac;
                        by_h=ny(is)*N_Q4(in)*(Hg-Hi)*J2*W(ig)/Ac;

                        B_H =[bx_h  0;
                             0     by_h;
                             by_h  bx_h];

                        Bs_enr=[Bs_enr B_H];

                    elseif ( enrich_node(sctr(in)) == 4) % B(x) enriched node

                        % compute branch functions at node "in"
                        xp    = QT*(node(sctr(in),:)-xTip)';
                        r     = sqrt(xp(1)*xp(1)+xp(2)*xp(2));
                        if( r ~=0 )
                            r2 = sqrt(r);
                        else
                            r2    = 0.1d-4;
                            theta = 0.0d0 ;
                        end
                        
                        theta = atan2(xp(2),xp(1));

                        if theta==atan2(0,-1)
                            theta=H*theta;
                        end

                        st2  = sin(theta/2.);
                        ct2  = cos(theta/2.);
                        st   = sin(theta);
                        ct   = cos(theta);

                        BrI(1) = r2 * st2 ;
                        BrI(2) = r2 * ct2;
                        BrI(3) = r2 * st2 * ct;
                        BrI(4) = r2 * ct2 * ct;

                        % composants of Benr matrix
                        bx_br = nx(is)*N_Q4(in)*(Br(1)-BrI(1))*J2*W(ig)/Ac;
                        by_br = ny(is)*N_Q4(in)*(Br(1)-BrI(1))*J2*W(ig)/Ac;

                        B1_enr = [bx_br 0 ;
                                 0   by_br;
                                 by_br bx_br];

                        bx_br = nx(is)*N_Q4(in)*(Br(2)-BrI(2))*J2*W(ig)/Ac;
                        by_br = ny(is)*N_Q4(in)*(Br(2)-BrI(2))*J2*W(ig)/Ac;

                        B2_enr = [bx_br 0 ;
                                  0  by_br;
                                  by_br bx_br];
                        bx_br = nx(is)*N_Q4(in)*(Br(3)-BrI(3))*J2*W(ig)/Ac;
                        by_br = ny(is)*N_Q4(in)*(Br(3)-BrI(3))*J2*W(ig)/Ac;

                        B3_enr = [bx_br 0 ;
                                  0  by_br;
                                  by_br bx_br];

                        bx_br = nx(is)*N_Q4(in)*(Br(4)-BrI(4))*J2*W(ig)/Ac;
                        by_br = ny(is)*N_Q4(in)*(Br(4)-BrI(4))*J2*W(ig)/Ac;

                        B4_enr = [bx_br 0 ;
                                  0  by_br;
                                  by_br bx_br];

                        B_Br =[B1_enr B2_enr B3_enr B4_enr];
                        Bs_enr=[Bs_enr B_Br];
                        clear B_Br;
                        clear B1_enr;
                        clear B2_enr;
                        clear B3_enr;
                        clear B4_enr;
                    end %end of enrich node
                end % end of node "in"
                if any(enrich_node(sctr))
                    B_enr= B_enr + Bs_enr;
                end
                clear Bs_enr;
            end % end loop of gauss points on side
        end %end of side
            B_sfem(1,1:2:2*nn)=bx;
            B_sfem(2,2:2:2*nn)=by;
            B_sfem(3,1:2:2*nn)=by;
            B_sfem(3,2:2:2*nn)=bx;

            if ( any(enrich_node(sctr)) == 0 ) % Non-enriched elements
                B_sm=B_sfem;
            else
                B_sm=[B_sfem B_enr];
            end
            clear B_sfem;
            clear B_enr;
            Ksc = B_sm'*D*B_sm*Ac;
            Ke_sc = Ke_sc + Ksc;
            clear Ksc;

    end %end of subcell
    K(sctrB,sctrB) = K(sctrB,sctrB) + Ke_sc;
end
end % end of function


