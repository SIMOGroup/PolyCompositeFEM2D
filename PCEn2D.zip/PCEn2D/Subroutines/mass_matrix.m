function N_shape=mass_matrix(N,nn)
for i=1:nn
    N_shape=zeros(2*nn,2*nn);
      N_shape(1,1:2:2*nn-1)=N';
      N_shape(2,2:2:2*nn)=N';
end
      