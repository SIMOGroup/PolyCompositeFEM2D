function [xd,yd,nodes,mnodes,bcnode,mbcnode]=formnode_square(n1,nx,a,L)

ny=2*n1; 
bcnode=cell(4,1);

dd=0.1; %0.25;       % concentration weight! =0: even distribution!

d1=a/n1;
if (mod(nx,2)==1)
   'NX must be even ...!'
   pause
end

ang=pi/(2*nx);
nk=ny+ny*(ny-1)*dd/2;

nn=0;
for ip=1:nx+1
   
   angi=(ip-1)*ang;
   if (ip<=nx/2+1) 
      xe=L;  ye=-xe*tan(angi);
      xi=a;  yi=-(ip-1)*d1;
   else
      ye=-L;  xe=-ye/tan(angi);
      yi=-a;  xi=a-(ip-nx/2-1)*d1; 
   end
   
   for iq=1:ny+1
      nn=nn+1;
      
      if (iq==1)
         dx=0; dy=0;
      else
       dx=(1+(ny-iq+1)*dd)*(xe-xi)/nk+dx;
       dy=(1+(ny-iq+1)*dd)*(ye-yi)/nk+dy;
      end
       xd(nn)=xe-dx;
       yd(nn)=ye-dy;
    
   end
end
nne=nn;    

nn=0;
for j=1:n1
    for i=1:n1
        nn=nn+1;
        x1(nn)=(i-1)*d1;
        y1(nn)=-(j-1)*d1;
    end
end
nni=nn;

xd(1,nne+1:nne+nni)=x1;
yd(1,nne+1:nne+nni)=y1;
mnode1=(2*ny+1)*nx+ny;

bclf(1,1:n1)=nne+(1:n1:n1*(n1-1)+1);
bclf(1,n1+1:n1+ny+1)=(ny+1)*(nx+1):-1:(ny+1)*nx+1; % left boundary
bcrt(1,1:n1+1)=1:(ny+1):(ny+1)*n1+1;               % right  
bcbt(1,1:n1+1)=(ny+1)*n1+1:(ny+1):(ny+1)*(nx+1);   % below
bcup(1,1:n1+1)=[(1:n1)+nne (ny+1)];                % up  
bcnode{1}=bcup; bcnode{2}=bclf; bcnode{3}=bcrt; bcnode{4}=bcbt;

mbclf(1,1:n1)=mnode1+(n1+1:2*n1:(2*n1-1)*n1+1);
mbclf(1,n1+1:n1+ny)=mnode1:-1:(mnode1-ny+1); % left boundary
mbcrt(1,1:n1)=ny+1:(2*ny+1):(2*ny-1)*n1;     % right  
mbcbt(1,1:n1)=(2*ny-1)*n1+(2*ny+1):(2*ny+1):(2*ny)*(2*n1);   % below
mbcup(1,1:n1)=[(1:n1)+ mnode1];                % up  
mbcnode{1}=mbcup; mbcnode{2}=mbclf; mbcnode{3}=mbcrt; mbcnode{4}=mbcbt;

nodes=[];
mnodes=[];
% for i=1:nx
%     for j=1:ny
%         nodes=[nodes; (ny+1)*(i-1)+j+1 (ny+1)*i+j+1 (ny+1)*i+j (ny+1)*(i-1)+j;];
%     end
% end

for i=1:nx
    for j=1:ny
        nodes=[nodes; (ny+1)*(i-1)+j+1 (ny+1)*i+j+1 (ny+1)*i+j (ny+1)*(i-1)+j;];
        mnodes=[mnodes;j+(2*(ny+1)-1)*(i-1)+ny+1  j+(2*(ny+1)-1)*i  j+(2*(ny+1)-1)*(i-1)+ny  j+(2*(ny+1)-1)*(i-1)];
    end
end

nodes1=[];
mnodes1=[];
for j=1:n1-1
    for i=1:n1-1
        nodes1=[nodes1; n1*j+i n1*j+i+1 n1*(j-1)+i+1 n1*(j-1)+i;];
        mnodes1=[mnodes1;2*n1*j+i n1*(j-1)+(n1*j+i+1) n1*(j-1)+ n1*(j-1)+i n1*(j-1)+ n1*j+i;];
    end
end
nodes1=nodes1+nne;
mnodes1=mnodes1+mnode1;
%nne
nodes2=[];
mnodes2=[];
for i=1:n1-1
    nodes2=[nodes2; n1*(i+1)+nne (ny+1)*(i+1) (ny+1)*i n1*i+nne;];
    mnodes2=[mnodes2;(2*i+1)*n1+mnode1 (2*ny+1)*i  2*n1*(i-1)+n1+mnode1  2*n1*i+mnode1;]; 
end

nodes2=[nodes2; (ny+1)*(n1+2) (ny+1)*(n1+1) (ny+1)*(n1) n1*n1+nne;];
mnodes2=[mnodes2;(2*ny+1)*(n1+1) (2*ny+1)*n1  (2*n1-1)*n1+mnode1  2*n1*n1+mnode1;]; 

for i=1:n1-1
    nodes2=[nodes2; (ny+1)*(n1+2+i) (ny+1)*(n1+1+i)  n1*n1+nne-i+1 n1*n1+nne-i;];
    mnodes2=[mnodes2;(2*ny+1)*(n1+1+i) (1-i)+ 2*n1*n1+mnode1 (2*n1-1)*n1+mnode1-i  2*n1*n1-i + mnode1;];
end

nne=nx*ny; nni=(n1-1)*(n1-1);
nodes(nne+1:nne+nni,:)=nodes1;
nodes(nne+nni+1:nne+nni+2*n1-1,:)=nodes2;
mnodes(nne+1:nne+nni,:)=mnodes1;
mnodes(nne+nni+1:nne+nni+2*n1-1,:)=mnodes2;


      