clear all
colordef black
clc
state = 0;
tic;
% ---------------------------------------

% ++++++++++++++++++++++
%   GLOBAL VARIABLES
% ++++++++++++++++++++++
% Use of global variables help the info sharing
% between functions easier. Also makes the list of
% function parameters shorter

global node element 

% +++++++++++++++++++++++++++++
%             INPUT
% +++++++++++++++++++++++++++++

% ---------------------------------------
% Dimension of the domain
% (it is simply a rectangular region D x L)
L = 1.2 ;
D = 2.5 ;

% Material properties
E  = 1e3 ;
nu = 0.3 ;
stressState='PLANE_STRAIN';

% Crack properties
% Crack is represented as straight segments
% with points stored in matrix xCr
% Array xTip contains coordinates of the crack tip
% Array seg is the segment containg the tip
% It serves in computing alpha, the inclination angle
% of the crack w.r.t the X axis
a = 0.45 ;                     % crack length
xCr   = [0 D/2; a D/1.8];
xTip  = [a D/1.8];
seg   = xCr(2,:) - xCr(1,:);   % tip segment
alpha = atan2(seg(2),seg(1));  % inclination angle -radian
QT    =[cos(alpha) sin(alpha); -sin(alpha) cos(alpha)];

% Loading
sigmato = 1  ;

% ---------------------------------------

% +++++++++++++++++++++++++++++
%            MESHING
% +++++++++++++++++++++++++++++

% ---------------------------------------
disp([num2str(toc),'   MESH GENERATION'])
% Number of nodes along two directions
nnx = 4 ;
nny = 6 ;

% Four corner points
pt1 = [0 0] ;
pt2 = [L 0] ;
pt3 = [L D] ;
pt4 = [0 D] ;

% Uniform meshing with Q4 elements
% Data structures for nodes and elements
% Node = [x1 y1
%         x2 y2
%         ...
%         xn yn]
% element = [1 3   5 7
%            4 20 35 78
%            ...
%           ]
elemType = 'Q4' ;
[node,element] = meshRectangularRegion(...
    pt1, pt2, pt3, pt4, nnx,nny,elemType);

% compute number of nodes, of elements
numnode = size(node,1);
numelem = size(element,1);

% define essential boundaries
uln = nnx*(nny-1)+1;       % upper left node number
urn = nnx*nny;             % upper right node number
lrn = nnx;                 % lower right node number
lln = 1;                   % lower left node number
cln = nnx*(nny-1)/2+1;     % node number at (0,0)

topEdge  = [ uln:1:(urn-1); (uln+1):1:urn ]';
botEdge  = [ lln:1:(lrn-1); (lln+1):1:lrn ]';

% GET NODES ON DIRICHLET BOUNDARY AND ESSENTIAL BOUNDARY
botNodes   = unique(botEdge);
topNodes   = unique(topEdge);

dispNodes = [botNodes];
tracNodes = topNodes;

% ---------------------------------------

% +++++++++++++++++++++++++++++
%           PROCESSING
% +++++++++++++++++++++++++++++
% Procedure:
%  1. Level set intialization
%  2. Set up enriched nodes, elements cut by crack
%  3. Initialize stiffness matrix, force vector
%  4. Loop on elements and compute stiffness matrix
%     and assemble into the global ones
%  5. Forming the force vector
%  6. Imposing essential boundary conditions
%  7. Solution of linear equations

% -------------------------------------------------------------
% ***************************************
% Level set initialization for all nodes
% ***************************************

% Level sets (normal and tangent) are stored in matrix ls
% whose the first column is normal LS and the second column contains
% the tangent LS. The i-th row is for node I
disp([num2str(toc),'   LEVEL SET INITIALIZATION'])
x0  = xCr(1,1); 
y0 = xCr(1,2);
x1  = xCr(2,1); 
y1 = xCr(2,2);
t   = 1/norm(seg)*seg;
for i = 1 : numnode
    x = node(i,1);
    y = node(i,2);
    l   = sqrt((x1-x0)*(x1-x0)+(y1-y0)*(y1-y0)); 
    phi = (y0-y1)*x + (x1-x0)*y + (x0*y1-x1*y0);
    ls(i,1) = phi/l;           % normal LS
    ls(i,2) = ([x y]-xTip)*t';  % tangent LS
end

% Choose enriched nodes...

% for one element, if max(phi)*min(phi) < 0
% and max(psi) < 0, then it is a split element
% If max(phi)*min(phi) < 0 and max(psi)*min(psi) < 0, it is
% tip element

% Data structures for elements cut by crack
% Array split_elem contains the number of elements which are completely
% cut by crack. Similarly, array tip_elem stores number of tip element

enrich_node = zeros(numnode,1);

count1 = 0;
count2 = 0;
for iel = 1 : numelem
    sctr = element(iel,:);
    phi  = ls(sctr,1);
    psi  = ls(sctr,2);
    if ( max(phi)*min(phi) < 0 )
        if max(psi) < 0
            count1 = count1 + 1;  % ah, one split element
            split_elem(count1) = iel;
            disp('one split element')
            enrich_node(sctr)   = 1;
        elseif max(psi)*min(psi) < 0
            count2 = count2 + 1;  % ah, one tip element
            disp('one tip element')
            tip_elem(count2) = iel;
            enrich_node(sctr)   = 2;
        end
    end
end
split_nodes = find(enrich_node == 1);
tip_nodes   = find(enrich_node == 2);


total_unknown = numnode*2 + size(split_nodes,1)*1*2 + ...
    size(tip_nodes,1)*4*2;

K = sparse(total_unknown,total_unknown);
KKK = sparse(total_unknown,total_unknown);
f = zeros(total_unknown,1);
% -------------------------------------------

% ***********************************
%    Stiffness matrix computation
% ***********************************

% Compliance matrix C
if ( strcmp(stressState,'PLANE_STRESS') )
    C = E/(1-nu^2)*[ 1   nu 0;
        nu  1  0 ;
        0   0  0.5*(1-nu) ];
else
    C = E/(1+nu)/(1-2*nu)*[ 1-nu  nu  0;
        nu    1-nu 0;
        0     0  0.5-nu ];
end

pos = zeros(numnode,1);
nsnode = 0 ;
ntnode = 0 ;
for i = 1 : numnode
    if (enrich_node(i) == 1)
        pos(i) = (numnode + nsnode*1 + ntnode*4) + 1 ;
        nsnode = nsnode + 1 ;
    elseif (enrich_node(i) == 2)
        pos(i) = (numnode + nsnode*1 + ntnode*4) + 1; 
        ntnode = ntnode + 1 ;
    end
end

q = [];
disp([num2str(toc),'   STIFFNESS MATRIX COMPUTATION'])

%for iel = 1 : numelem
    iel=3;
    sctr = element(iel,:); % element connectivity
    sctrB = assembly(iel,enrich_node,pos);
    nn   = length(sctr);   % number of nodes per element
%end
xd=node(sctr,1);
yd=node(sctr,2);
[Ke,KKKe1,KKKe2]=sfemKe_matrix(xd,yd,C,2);
% [K,B_sxfem,B_fem]=sxfemBmatrix_new(iel,enrich_node,xCr,xTip,alpha,xd,yd,C,2,total_unknown,sctrB)

 K(sctrB,sctrB) = K(sctrB,sctrB) + Ke;
% KKK(sctrB,sctrB) = KKK(sctrB,sctrB)+KKKe1+KKKe2;








