function shp = shapeFunction1d(ennodes, x)
% shp(l,j): shape function Nj(eta) of j-th node
% shp(2,j): derivative of shape function Nj (eta), eta
% ennodes: number of nodes of element, x:	local coordinate eta
shp = zeros(2, ennodes);
switch ennodes
    case (2) % 2-node line element
        shp = [0.5d0 * (1.d0 - x), 0.5d0 * (1.d0 + x); -0.5d0, 0.5d0];
    case (3) % 3-node line element
        shp = [0.5d0 * (-1.d0 + x) * x, 1.d0 - x * x, 0.5d0 * (1.d0 + x) * x; -0.5d0 + x, -2 * x, 0.5d0 + x];
    case (4)
        % Shape functions of 4-node line element
        shp(1, 1) = -0.125d0 * (-1.d0 + x) * (-1.d0 + 5.d0 * x * x);
        shp(1, 2) = 0.625d0 * (-1.d0 + x * x) * (-1.d0 + 2.2360679774997897d0 * x);
        shp(1, 3) = -0.27950849718747371d0 * (-1.d0 + x * x) * (2.2360679774997897d0 + 5.d0 * x);
        shp(1, 4) = 0.125d0 * (1.d0 + x) * (-1.d0 + 5.d0 * x * x);
        shp(2, 1) = 0.125d0 * (1.d0 + (10.d0 - 15.d0 * x) * x);
        shp(2, 2) = 0.625d0 * (-2.2360679774997897d0 + (-2.d0 + 6.7082039324993691d0 * x) * x);
        shp(2, 3) = -0.279508497187473712d0 * (-5.d0 + (4.472135954999579393d0 + 15.d0 * x) * x);
        shp(2, 4) = 0.125d0 * (-1.d0 + (10.d0 + 15.d0 * x) * x);
end
end