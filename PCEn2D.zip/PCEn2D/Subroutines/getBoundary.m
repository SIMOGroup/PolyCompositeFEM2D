function [fixedNodeX,fixedNodeY] = getBoundary(elemType,numx,nnx,uln)
global node
switch elemType
case 'Q8'
   fixedNodeX=[uln:-(nnx+numx+1):1 (uln-(numx+1)):-(nnx+numx+1):1]';  
   fixedNodeY=[uln:-(nnx+numx+1):1 (uln-(numx+1)):-(nnx+numx+1):1]';          
case 'Q9'
  fixedNodeX=[uln:-2*nnx:1 (uln-nnx):-2*nnx:1]';   
  fixedNodeY=[uln:-2*nnx:1 (uln-nnx):-2*nnx:1]';     
  
case 'T6'
  fixedNodeX=[uln:-2*nnx:1 (uln-nnx):-2*nnx:1]';  
  fixedNodeY=[uln:-2*nnx:1 (uln-nnx):-2*nnx:1]';        

case 'CPn'
    tol=1e-3;
    fixedNodeX = find(node(:,1) > 0-tol & node(:,1) < 0+tol);
    fixedNodeY = find(node(:,1) > 0-tol & node(:,1) < 0+tol);

case 'Poly'
    tol=1e-3;
    fixedNodeX = find(node(:,1) > 0-tol & node(:,1) < 0+tol);
    fixedNodeY = find(node(:,1) > 0-tol & node(:,1) < 0+tol);
    
otherwise 
  fixedNodeX=[uln:-nnx:1]';  
  fixedNodeY=[uln:-nnx:1]';          
end

    