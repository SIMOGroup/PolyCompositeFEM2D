function [ue,estress0]=analyticsol_semiplate(x,y,A,c,E0,nu0,P)
  
   c1=P*(1-nu0*nu0)/pi/E0; c2=(1-2*nu0)/(1-nu0);
   r1=sqrt((x+A)*(x+A)+y*y);   r2=sqrt((x-A)*(x-A)+y*y);
   if abs(y)<1e-12 & x<A
        theta1=pi/2; theta2=-pi/2;
   elseif abs(y)<1e-12 & x>=A
        theta1=pi/2; theta2=pi/2;
   else
        theta1=atan(-(x+A)/y);      theta2=atan(-(x-A)/y);
   end
   if abs(y)<1e-12 & x==A
        u=c1*(c2*((x+A)*theta1-(x-A)*theta2));
        v=c1*(c2*(y*(theta1-theta2)+2*c*A*atan(1/c))-2*(x+A)*log(r1) ...
            +4*A*log(A)+2*A*log(1+c*c));
   else        
        u=c1*(c2*((x+A)*theta1-(x-A)*theta2)+2*y*log(r1/r2));
        v=c1*(c2*(y*(theta1-theta2)+2*c*A*atan(1/c))+2*(x-A)*log(r2)-2*(x+A)*log(r1) ...
            +4*A*log(A)+2*A*log(1+c*c));
   end
   ue=[u;v];
   
   % compute stress
   if abs(y)<1e-12
        theta1=pi/2; theta2=pi/2;
    else
        theta1=atan(-(x+A)/y);      theta2=atan(-(x-A)/y);
   end
    
   sigmax=P*(2*(theta1-theta2)-sin(2*theta1)+sin(2*theta2))/2/pi;
   sigmay=P*(2*(theta1-theta2)+sin(2*theta1)-sin(2*theta2))/2/pi;
   sigmaxy=P*(cos(2*theta1)-cos(2*theta2))/2/pi;
   estress0=[sigmax; sigmay; sigmaxy];
 
