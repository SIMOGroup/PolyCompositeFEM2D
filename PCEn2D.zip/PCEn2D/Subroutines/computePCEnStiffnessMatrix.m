function K = computePCEnStiffnessMatrix(stressState, Material, gamma, ndof, LAB, MethodLAB, cenDOF)

assert(strcmp(LAB, 'T3') || strcmp(LAB, 'Wachspress') || strcmp(LAB, 'CorrectedWachspress'))
global node element thickness;
numnode = size(node, 1); % number of nodes
numelem = numel(element);

sdof = 2 * numnode;
K = sparse(sdof, sdof); % stiffness matrix

for iel = 1:numelem% start of element loop
    sctr = element{iel}(:)';
    nnel = length(sctr);
    
    sctrR = zeros(1, ndof * nnel);
    sctrR(1:ndof:ndof * nnel - 1) = ndof .* sctr - 1;
    sctrR(2:ndof:ndof * nnel) = ndof .* sctr;
    
    Connect = [(nnel + 1) * ones(nnel, 1), (1:nnel)', [2:nnel, 1]'];
    CoE = node(sctr, :);
    if strcmp(cenDOF, 'yes')
        Coord = [CoE; polygonCentroid(CoE)];
    else
        Coord = [CoE; mean(CoE)];
    end
    
    if strcmp(MethodLAB, 'PCEn')
        Ke = computePCEnElementStiffnessMatrix(Coord, Connect, stressState, Material.Dm, thickness, gamma, LAB, cenDOF);
    elseif strcmp(MethodLAB, 'Classic')
        Ke = computePEnElementStiffnessMatrix(Coord, Connect, Material.Dm, thickness, LAB);
    else
        error('This method is not implemented yet!')
    end
    K(sctrR, sctrR) = K(sctrR, sctrR) + Ke;
end
end % of element loop