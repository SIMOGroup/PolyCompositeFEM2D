function [xd,yd]=create_node_platehole(nx,ny,R,A)

%R=1;           % Inner radius       
%A=5;           % side length
%dd=0.25;%0.25;       % concentration weight! =0: even distribution!
dd=0.25;        % concentration weight!
air=0.0;

if (mod(nx,2)==1)
   'NX must be even ...!'
   pause
end

ang=pi/(2*nx);
nk=ny+ny*(ny-1)*dd/2;

nn=0;
for ip=1:nx+1   
   angi=pi/2-(ip-1)*ang;
   xi=R*cos(angi);  yi=R*sin(angi);
   if (ip<=nx/2+1)
      ye=A;  xe=ye/tan(angi);
   else
      xe=A;  ye=xe*tan(angi);
   end   
   for iq=1:ny+1
      nn=nn+1;      
      if (iq==1)
         dx=0; dy=0;
      else
       dx=(1+(ny-iq+1)*dd)*(xe-xi)/nk+dx;
       dy=(1+(ny-iq+1)*dd)*(ye-yi)/nk+dy;
      end
       xd(nn)=xe-dx;
       yd(nn)=ye-dy;    
   end
end
      