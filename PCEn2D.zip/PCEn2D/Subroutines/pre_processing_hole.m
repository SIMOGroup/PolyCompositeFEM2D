function [node,element,kin_bound_cond,sta_bound_cond]=pre_processing_hole(numx,numy,R,A,choice)  

kin_bound_cond=[];
sta_bound_cond=[];
[xd,yd]=formnode_pla(numx,numy,R,A);
     node=[xd' yd'];
  for i=1:numx
    for j=1:numy
        elem=numx*(j-1)+i;
        if i<=numx/2 % with numx mod 2=0
                
        element(2*elem-1,1)=(numy+1)*(i-1)+j;
        element(2*elem-1,2)=(numy+1)*i+j+1;
        element(2*elem-1,3)=(numy+1)*i+j;
               
        element(2*elem,1)=(numy+1)*(i-1)+j;
        element(2*elem,2)=(numy+1)*(i-1)+j+1;
        element(2*elem,3)=(numy+1)*i+j+1;
        else
          element(2*elem-1,1)=(numy+1)*(i-1)+j+1;
          element(2*elem-1,2)=(numy+1)*i+j+1;
          element(2*elem-1,3)=(numy+1)*i+j;
        
          element(2*elem,1)=(numy+1)*(i-1)+j+1;
          element(2*elem,2)=(numy+1)*i+j;
          element(2*elem,3)=(numy+1)*(i-1)+j;
        end
    end
  end
 switch choice
     case '1'   
        sta_bound_cond=[sta_bound_cond;[numy/2 0 0 0];]% note that numy is even 
        for i=1:numx+1
         kin_bound_cond=[kin_bound_cond; [(numy+1)*numx+i 0 1];];
        end
        for i=1:numx+1
         kin_bound_cond=[kin_bound_cond; [i 1 0];];
        end
        for i=1:numy/2
         sta_bound_cond=[sta_bound_cond;[(numy+1)*numx/2+1+(numx+1)*(i-1) (numy+1)*numx/2+1+(numx+1)*i 1 0]];        
        end
     case '2'   
        kin_bound_cond=[kin_bound_cond; [(numy+1)*numx+1:(numx+1) 0 1]];
        kin_bound_cond=[kin_bound_cond; [1:numx+1 1 0]];
  end
 
     
     