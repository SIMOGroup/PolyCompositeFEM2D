function [gcoord,nodes,bcdof,bcval,ff]=init_data_platehole(nx,ny,nnel,R,A)

%--------------------------------------------
%input data for nodal coordinate values
%gcoord(i,j) where i->node no.  and j->x or y
%--------------------------------------------

[gcoord(:,1),gcoord(:,2)]=create_node_platehole(nx,ny,R,A);

%-----------------------------------------------------
%input data for nodal connectivity for each element
%nodes(i,j) where i->element no. and j->connected nodes
%------------------------------------------------------

nodes=[];
if nnel==4
    for i=1:nx
        for j=1:ny
            nodes=[nodes; (ny+1)*(i-1)+j+1 (ny+1)*i+j+1 (ny+1)*i+j (ny+1)*(i-1)+j;];
        end
    end
elseif nnel==3
    for i=1:nx/2
        for j=1:ny
            nodes=[nodes; (ny+1)*(i-1)+j+1 (ny+1)*i+j+1 (ny+1)*i+j; (ny+1)*(i-1)+j+1 (ny+1)*i+j (ny+1)*(i-1)+j;];
        end   
    end
    for i=nx/2+1:nx
        for j=1:ny        
            nodes=[nodes; (ny+1)*(i-1)+j+1 (ny+1)*i+j+1 (ny+1)*(i-1)+j; (ny+1)*i+j+1 (ny+1)*i+j (ny+1)*(i-1)+j;];
        end
    end
end

%---------------------------------------------------------------------
%  input data for boundary conditions for displacement and potential
%---------------------------------------------------------------------
for i=1:ny+1
    bcdof(1,i)=i*2-1;                    % left edge: in x direction
    bcdof(1,ny+1+i)=((ny+1)*nx+i)*2;     % bottom edge: in y direction  
end

bcval=zeros(1,length(bcdof));        % whose described values are 0

[ff]=get_force_platehole(nx,ny,R,gcoord(:,1),gcoord(:,2));