function [ed_abs,ed_sq]=plot_ed_abs(U_analysis,U_num)
errabs=0.0;
err1=0.0;
err2=0.0;
errsq=0.0;
for i=1:size(U_num,1)
    errabs=errabs+abs(U_analysis(i)-U_num(i));
    errsq=errsq+(U_analysis(i)-U_num(i))^2;
    err1=err1+abs(U_analysis(i));
    err2=err2+U_analysis(i)^2;
end
ed_abs=errabs/err1*100;
ed_sq=sqrt(errsq/err2)*100;
    
    
    