function [vol_node, vol_element] = integral_node(gcoord,nodes,elemType)
%This is to compute the area of integration domain for each node
%  Detailed explanation goes here
nel = size(nodes,1);
nnode = max(size(gcoord));

if (strcmp(elemType,'T3'))
    
for i = 1:nel
    x0 = gcoord(nodes(i,1),1);
    y0 = gcoord(nodes(i,1),2);
    x1 = gcoord(nodes(i,2),1);
    y1 = gcoord(nodes(i,2),2);
    x2 = gcoord(nodes(i,3),1);
    y2 = gcoord(nodes(i,3),2);
    la=sqrt((x0-x1)*(x0-x1)+(y0-y1)*(y0-y1));      % side length
    lb=sqrt((x0-x2)*(x0-x2)+(y0-y2)*(y0-y2));
    lc=sqrt((x2-x1)*(x2-x1)+(y2-y1)*(y2-y1)); 
    p=(la+lb+lc)/2;
    S=sqrt(p*(p-la)*(p-lb)*(p-lc));
    vol_element(i) = S;
end

%Compute the integration domain of each node
vol_node = zeros(nnode,1);
for inode=1:nnode
    for jel = 1:nel
        if find(inode==nodes(jel,:))> 0.5
            vol_node(inode) = vol_node(inode)+vol_element(jel)/3;
        end
    end
end

elseif (strcmp(elemType,'T4'))
    
for i = 1:nel
    x0 = gcoord(nodes(i,1),1);
    y0 = gcoord(nodes(i,1),2);
    x1 = gcoord(nodes(i,2),1);
    y1 = gcoord(nodes(i,2),2);
    x2 = gcoord(nodes(i,3),1);
    y2 = gcoord(nodes(i,3),2);
    
    la=sqrt((x0-x1)*(x0-x1)+(y0-y1)*(y0-y1));      % side length
    lb=sqrt((x0-x2)*(x0-x2)+(y0-y2)*(y0-y2));
    lc=sqrt((x2-x1)*(x2-x1)+(y2-y1)*(y2-y1)); 
    p=(la+lb+lc)/2;
    S=sqrt(p*(p-la)*(p-lb)*(p-lc));
    vol_element(i) = S;
end

%Compute the integration domain of each node
vol_node = zeros(nnode,1);
for inode=1:nnode
    for jel = 1:nel
        if find(inode==nodes(jel,:))> 0.5
            vol_node(inode) = vol_node(inode)+vol_element(jel)/4;
        end
    end
end

elseif (strcmp(elemType,'T6'))
for i = 1:nel
    x0 = gcoord(nodes(i,1),1);
    y0 = gcoord(nodes(i,1),2);
    x1 = gcoord(nodes(i,2),1);
    y1 = gcoord(nodes(i,2),2);
    x2 = gcoord(nodes(i,3),1);
    y2 = gcoord(nodes(i,3),2);
    la=sqrt((x0-x1)*(x0-x1)+(y0-y1)*(y0-y1));      % side length
    lb=sqrt((x0-x2)*(x0-x2)+(y0-y2)*(y0-y2));
    lc=sqrt((x2-x1)*(x2-x1)+(y2-y1)*(y2-y1)); 
    p=(la+lb+lc)/2;
    S=sqrt(p*(p-la)*(p-lb)*(p-lc));
    vol_element(i) = S;
end

%Compute the integration domain of each node
vol_node = zeros(nnode,1);
for inode=1:nnode
    for jel = 1:nel
        if find(inode==nodes(jel,1:3))> 0.5
            vol_node(inode) = vol_node(inode)+vol_element(jel)/12;
        end
        if find(inode==nodes(jel,4:6))> 0.5
            vol_node(inode) = vol_node(inode)+vol_element(jel)/4;
        end
    end
end

elseif (strcmp(elemType,'Q4'))
 
%Compute the area of each quadrilateral
for i = 1:nel    
    x(1) = gcoord(nodes(i,1),1);
    y(1) = gcoord(nodes(i,1),2);
    x(2) = gcoord(nodes(i,2),1);
    y(2) = gcoord(nodes(i,2),2);
    x(3) = gcoord(nodes(i,3),1);
    y(3) = gcoord(nodes(i,3),2);
    x(4) = gcoord(nodes(i,4),1);
    y(4) = gcoord(nodes(i,4),2);    
    S=cal_area(x,y);
    vol_element(i)=S;    
    xcent(i)=sum(x)/4;
    ycent(i)=sum(y)/4;
end

%Compute the integration domain of each node
vol_node = zeros(nnode,1);
for inode=1:nnode
    for j = 1:nel
        k=1;
        while k<=4
            if find(inode==nodes(j,k))> 0.5
                x(1) = gcoord(inode,1);
                y(1) = gcoord(inode,2);
                if k==4 
                    x(2) = 1/2*(gcoord(nodes(j,k),1)+gcoord(nodes(j,1),1));
                    y(2) = 1/2*(gcoord(nodes(j,k),2)+gcoord(nodes(j,1),2));
                    x(3) = xcent(j);
                    y(3) = ycent(j);
                    x(4) = 1/2*(gcoord(nodes(j,k),1)+gcoord(nodes(j,3),1));
                    y(4) = 1/2*(gcoord(nodes(j,k),2)+gcoord(nodes(j,3),2));
                elseif k==1
                    x(2) = 1/2*(gcoord(nodes(j,k),1)+gcoord(nodes(j,2),1));
                    y(2) = 1/2*(gcoord(nodes(j,k),2)+gcoord(nodes(j,2),2));
                    x(3) = xcent(j);
                    y(3) = ycent(j);
                    x(4) = 1/2*(gcoord(nodes(j,k),1)+gcoord(nodes(j,4),1));
                    y(4) = 1/2*(gcoord(nodes(j,k),2)+gcoord(nodes(j,4),2));
                else
                    x(2) = 1/2*(gcoord(nodes(j,k),1)+gcoord(nodes(j,k+1),1));
                    y(2) = 1/2*(gcoord(nodes(j,k),2)+gcoord(nodes(j,k+1),2));
                    x(3) = xcent(j);
                    y(3) = ycent(j);
                    x(4) = 1/2*(gcoord(nodes(j,k),1)+gcoord(nodes(j,k-1),1));
                    y(4) = 1/2*(gcoord(nodes(j,k),2)+gcoord(nodes(j,k-1),2));
                end
                vol_node(inode) = vol_node(inode)+cal_area(x,y);  
                break;
            else  
                k=k+1;            
            end
        end % end while
    end % end for element
end
elseif (strcmp(elemType,'T43D'))
for i = 1:nel
    x1 = gcoord(nodes(i,1),1);y1 = gcoord(nodes(i,1),2);z1 = gcoord(nodes(i,1),3);
    x2 = gcoord(nodes(i,2),1);y2 = gcoord(nodes(i,2),2);z2 = gcoord(nodes(i,2),3);
    x3 = gcoord(nodes(i,3),1);y3 = gcoord(nodes(i,3),2);z3 = gcoord(nodes(i,3),3);
    x4 = gcoord(nodes(i,4),1);y4 = gcoord(nodes(i,4),2);z4 = gcoord(nodes(i,4),3);
    xbar= [ 1  x1  y1  z1;
            1  x2  y2  z2;
            1  x3  y3  z3;
            1  x4  y4  z4 ];
    vol_element(i)= (1/6)*det(xbar);   % compute volume of tetrahedral
end
%Compute the integration domain of each node
vol_node = zeros(nnode,1);
for inode=1:nnode
    for jel = 1:nel
        if find(inode==nodes(jel,:))> 0.5
            vol_node(inode) = vol_node(inode)+vol_element(jel)/4;
        end
    end
end
else
 disp('integral cell type is not implemented');
 return
end  