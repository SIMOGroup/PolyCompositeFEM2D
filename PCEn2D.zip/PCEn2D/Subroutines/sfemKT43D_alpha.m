function K= sfemKT43D_alpha(ivo,elemType,neighbour,area,supp,enrich_node,D,ng,al)
                          
global node element K 
nc = length(neighbour); %number of neighbouring cells corresponding to index of element (No of element)
if (strcmp(elemType,'H4'))
  for i = 1:nc % num of element
    kcc = neighbour(i);% index of element
    sctr = element(kcc,:);
    nodes = node(sctr,:);
    
    for inode=1:4
        n(inode) = element(kcc,inode);
        x(inode) = node(n(inode),1);
        y(inode) = node(n(inode),2); 
        z(inode) = node(n(inode),3); 
    end    

    xsupp = supp{neighbour(i)}; % support node numbering
    nsf = length(xsupp);
    bx=zeros(nsf,1);
    by=zeros(nsf,1);
    
   [W,Q]=quadrature(1,'TRIANGULAR',3);     % 1 point triangural quadrature, sdim=3 for T4    
    for q=1:size(W,1)                        % quadrature loop
      pt=Q(q,:);                             % quadrature point
      wt=W(q);                               % quadrature weight
      [N,dNdxi]=lagrange_basis(elemType,pt); % element shape functions
      J0=node(sctr,:)'*dNdxi;                % element Jacobian matrix        
      invJ0=inv(J0);
      dNdx=dNdxi*invJ0;
    
%     %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
      B_fem=zeros(6,3*nsf);
      B_fem(1,1:3:3*nsf) = dNdx(:,1)';
      B_fem(2,2:3:3*nsf) = dNdx(:,2)';
      B_fem(3,3:3:3*nsf) = dNdx(:,3)';
      B_fem(4,1:3:3*nsf-2) = dNdx(:,2)';
      B_fem(4,2:3:3*nsf-1) = dNdx(:,1)';
      B_fem(5,2:3:3*nsf-1)   = dNdx(:,3)';
      B_fem(5,3:3:3*nsf) = dNdx(:,2)';
      B_fem(6,1:3:3*nsf-1)   = dNdx(:,3)';
      B_fem(6,3:3:3*nsf)   = dNdx(:,1)';
     end
  if (ivo == n(2))
     for icel=1:2
       xx=gcoord(node_sc2(icel,:),1);
       yy=gcoord(node_sc2(icel,:),2);
       side=cal_side(xx,yy);
       [nx,ny]=cal_nx_ny(xx,yy,side);
       ns=length(xx); % number side of sub element. T3 ==>ns=3
       for is=1:ns % loop ns-sides of sub cell element-two gauss points per side
            [W,Q]=quadrature(ng,'GAUSS',1);
            for ig=1:ng
                %Bs_enr=[];
                N_g=lagrange_basis('L2',Q(ig));
                [xi1,eta1]=xi_eta4xy('T3',is,N_g);
                N_xy=lagrange_basis('T3',[xi1 eta1]);
                xy_g=N_xy'*[xx yy];
                xieta=cal_xieta('T3',xy_g,nodes);
                N_T=lagrange_basis(elemType,xieta);

%               plot_g=[plot_g;xy_g];
                J2=side(is)/2; % Jacobian matrix for L2 
                
                bx=bx + nx(is)*N_T*J2*W(ig);
                by=by + ny(is)*N_T*J2*W(ig);
            end % end loop of gauss points on side
       end %end of side
     end
    clear W Q;
   [W,Q]=quadrature(1, 'TRIANGULAR', 2 ); % 1 point triangural quadrature    
    for q=1:size(W,1)                        % quadrature loop
     pt=Q(q,:);                             % quadrature point
     wt=W(q);                               % quadrature weight
     [N,dNdxi]=lagrange_basis(elemType,pt); % element shape functions
     J0=node(sctr,:)'*dNdxi;                % element Jacobian matrix        
     invJ0=inv(J0);
     dNdx=dNdxi*invJ0;
     B_fem=zeros(3,2*nsf);
     B_fem(1,1:2:2*nsf-1) = dNdx(:,1)';
     B_fem(2,2:2:2*nsf)   = dNdx(:,2)';
     B_fem(3,1:2:2*nsf-1) = dNdx(:,2)';
     B_fem(3,2:2:2*nsf)  = dNdx(:,1)';
     end 
  end
   if (ivo == n(3))
      for icel=1:2
       xx=gcoord(node_sc3(icel,:),1);
       yy=gcoord(node_sc3(icel,:),2);
       side=cal_side(xx,yy);
       [nx,ny]=cal_nx_ny(xx,yy,side);
       ns=length(xx); % number side of sub element. T3 ==>ns=3
       for is=1:ns % loop ns-sides of sub cell element-two gauss points per side
            [W,Q]=quadrature(ng,'GAUSS',1);
            for ig=1:ng
                %Bs_enr=[];
                N_g=lagrange_basis('L2',Q(ig));
                [xi1,eta1]=xi_eta4xy('T3',is,N_g);
                N_xy=lagrange_basis('T3',[xi1 eta1]);
                xy_g=N_xy'*[xx yy];

                xieta=cal_xieta('T3',xy_g,nodes);
                N_T=lagrange_basis(elemType,xieta);

%               plot_g=[plot_g;xy_g];
                J2=side(is)/2; % Jacobian matrix for L2 
                
                bx=bx + nx(is)*N_T*J2*W(ig);
                by=by + ny(is)*N_T*J2*W(ig);
            end % end loop of gauss points on side
       end %end of side
      end
      clear W Q;
      [W,Q]=quadrature(1, 'TRIANGULAR', 2 ); % 1 point triangural quadrature    
    for q=1:size(W,1)                        % quadrature loop
     pt=Q(q,:);                             % quadrature point
     wt=W(q);                               % quadrature weight
     [N,dNdxi]=lagrange_basis(elemType,pt); % element shape functions
     J0=node(sctr,:)'*dNdxi;                % element Jacobian matrix        
     invJ0=inv(J0);
     dNdx=dNdxi*invJ0;
      B_fem=zeros(3,2*nsf);
      B_fem(1,1:2:2*nsf-1) = dNdx(:,1)';
      B_fem(2,2:2:2*nsf)   = dNdx(:,2)';
      B_fem(3,1:2:2*nsf-1) = dNdx(:,2)';
      B_fem(3,2:2:2*nsf)  = dNdx(:,1)';
     end 
   end
     bx=bx/area;
     by=by/area;
     Bfem{i}=B_fem;
     clear B_fem
     if i==1
           nodL=element(neighbour(i),:);%supp{neighbour(i)};
           nn=nsf;% num of node of each element
           for jj=1:nn
            B_sfem(1,2*jj-1)=bx(jj);
            B_sfem(2,2*jj)=by(jj);
            B_sfem(3,2*jj-1)=by(jj);
            B_sfem(3,2*jj)=bx(jj);
           end
     else  
          i0=0;
          for jj=1:nsf
                nod=element(neighbour(i),jj);%supp{neighbour(i)}(jj);
                flag=0;
              for j=1:nn
                  if nodL(j)==nod
                      B_sfem(1,2*j-1)=B_sfem(1,2*j-1)+bx(jj);
                      B_sfem(2,2*j)=B_sfem(2,2*j)+ by(jj);
                      B_sfem(3,2*j-1)=B_sfem(3,2*j-1)+by(jj);
                      B_sfem(3,2*j)=B_sfem(3,2*j)+bx(jj);
                      flag=1;  break
                  end
              end
                if flag==0
                    i0=i0+1;
                    nodL(nn+i0)=nod;
                    B_sfem(1,2*(nn+i0)-1)=bx(jj);
                    B_sfem(2,2*(nn+i0))=by(jj);
                    B_sfem(3,2*(nn+i0)-1)=by(jj);
                    B_sfem(3,2*(nn+i0))=bx(jj);
                end
           end 
             nn=nn+i0;             
     end  %end else
 end %number of neighbouring cells
 % nodL   
  if ( any(enrich_node(sctr)) == 0 ) % Non-enriched elements
                B_sm=B_sfem;
  else
                B_sm=[B_sfem B_enr];
  end
  %%%% store B_FEM----------------
  %Ke_sc = B_sm'*D*B_sm*area;
  Ke_sc=zeros(2*size(nodL,2));
  for i = 1:nc % num of element
    xsupp = supp{neighbour(i)}; % support node numbering
    nsf = length(xsupp);
    nodes = node(xsupp,:);
    Ac=cal_area(nodes(:,1),nodes(:,2));
    %a=size(nodL,2)
    % b=size(B,2)
    Bf{i}=zeros(3,2*size(nodL,2));  
    if i==1
           nodLl=element(neighbour(i),:);%supp{neighbour(i)};
           nn=nsf;% num of node of each element
           Bf{i}(1,1:2:2*nn-1) = Bfem{i}(1,1:2:2*nn-1);
           Bf{i}(2,2:2:2*nn)   = Bfem{i}(2,2:2:2*nn);
           Bf{i}(3,1:2:2*nn-1) = Bfem{i}(3,1:2:2*nn-1);
           Bf{i}(3,2:2:2*nn)  =  Bfem{i}(3,2:2:2*nn);
    else  
          i0=0;
          for jj=1:nsf
                nod=element(neighbour(i),jj);
                flag=0;
              for j=1:nn
                  if nodLl(j)==nod
                      Bf{i}(1,2*j-1) = Bfem{i}(1,2*jj-1);
                      Bf{i}(2,2*j)   = Bfem{i}(2,2*jj);
                      Bf{i}(3,2*j-1) = Bfem{i}(3,2*jj-1);
                      Bf{i}(3,2*j)  =  Bfem{i}(3,2*jj);
                      flag=1;  break
                  end
              end
                if flag==0
                    i0=i0+1;
                    nodLl(nn+i0)=nod;
                    Bf{i}(1,2*(nn+i0)-1) = Bfem{i}(1,2*jj-1);
                    Bf{i}(2,2*(nn+i0))   = Bfem{i}(2,2*jj);
                    Bf{i}(3,2*(nn+i0)-1) = Bfem{i}(3,2*jj-1);
                    Bf{i}(3,2*(nn+i0))  =  Bfem{i}(3,2*jj);
                end
           end 
             nn=nn+i0;              
     end  %end else
     B=Bf{i};
    % Ke_sc=Ke_sc+(B'*D*B/3-al^2*(B_sm-B)'*D*(B_sm-B)/3)*Ac;
    Ke_sc=Ke_sc+(B'*D*B/3-al^2*(B_sm-B)'*D*(B_sm-B)/9)*Ac;
     %Ke_sc=Ke_sc+B_sm'*D*B_sm*Ac/3;
 end %number of neighbouring cells
 
  clear B_sfem xx yy x y nn nodL1 B;
  %Ke_sc=zeros(2*nn+dof_enr,2*nn+dof_enr);
  %Ke_sc = B_sm'*D*B_sm*area;
  numnod = length(nodL);
  sctrB(1:2:2*numnod) = 2.*nodL-1 ;
  sctrB(2:2:2*numnod) = 2.*nodL   ;
    
  K(sctrB,sctrB) = K(sctrB,sctrB) + Ke_sc;
      %rank(Ke_sc)
  clear B_sm Ke_sc nodL sctrB;
else
   disp('Number smoothing cells of element are not implemented');
   return
end



   

